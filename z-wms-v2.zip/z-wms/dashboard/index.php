<?php
session_start();
require '../inc/db.php';

if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    header("Location: ../");
    exit();
}

// Get the latest snapshot date
$latest_date_query = "SELECT MAX(snapshot_date) as latest_date FROM inventory_snapshot";
$date_result = $conn->query($latest_date_query);
$latest_date = $date_result->fetch_assoc()['latest_date'];

$snapshot_data = [];
if ($latest_date) {
    // Fetch the data for the latest snapshot date
    $data_query = "SELECT * FROM inventory_snapshot WHERE snapshot_date = '{$latest_date}' ORDER BY sku_code, compcode, wh_code LIMIT 100";
    $data_result = $conn->query($data_query);
    while ($row = $data_result->fetch_assoc()) {
        $snapshot_data[] = $row;
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Zynex WMS | Dashboard</title>

    <link rel="stylesheet" href="../inc/global.css">
</head>

<body>

    <?php require '../parts/nav.php'; ?>

    <div id="main" class="main">
        <h1 style="text-align: center;">Z-WMS</h1>
        <h2 style="text-align: center;">Zynex Warehouse Management System</h2>

        <?php
        echo '<p>UserName: <b>' . $_SESSION['username'] . '</b></p>';
        echo "<p>Company Code: <b>{$_SESSION['compcode']} | {$_SESSION['company_comp_name']}</b></p>";
        ?>

        <p>More details and Widgets will come soon</p>
    </div>

    

</body>

</html>