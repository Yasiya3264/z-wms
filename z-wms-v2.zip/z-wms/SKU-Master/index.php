<?php
session_start();
require '../inc/db.php';

if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    header("Location: ../");
    exit();
}

$error_message = '';
$success_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sku_code']) && !isset($_POST['export_csv'])) {
    $compcode = $_SESSION['compcode'];

    $small_cbm_val = round(
        (($_POST['smallL'] ?? 0) * ($_POST['smallW'] ?? 0) * ($_POST['smallH'] ?? 0)), // M * M * M = m^3
        5 // Kept high precision for CBM column
    );
    $big_cbm_val = round(
        (($_POST['bigL'] ?? 0) * ($_POST['bigW'] ?? 0) * ($_POST['bigH'] ?? 0)), // M * M * M = m^3
        5
    );
    $pellet_cbm_val = round(
        (($_POST['pelletL'] ?? 0) * ($_POST['pelletW'] ?? 0) * ($_POST['pelletH'] ?? 0)), // M * M * M = m^3
        5
    );

    $stmt = $conn->prepare("INSERT INTO sku_master (
        compcode, sku_code, sku_description, picking_strategy,
        net_weight, gross_weight,
        smallest_uom, smallest_length, smallest_width, smallest_height, smallest_cbm,
        biggest_uom, biggest_length, biggest_width, biggest_height, biggest_cbm, epl, lpp, epp,
        pellet_length, pellet_width, pellet_height, pellet_cbm
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    $stmt->bind_param(
        "ssssddddddddddddssssddd",
        $compcode,
        $_POST['sku_code'],
        $_POST['sku_description'],
        $_POST['picking_strategy'],
        $_POST['net_weight'],
        $_POST['gross_weight'],
        $_POST['smallest_uom'],
        $_POST['smallL'],
        $_POST['smallW'],
        $_POST['smallH'],
        $small_cbm_val,
        $_POST['biggest_uom'],
        $_POST['bigL'],
        $_POST['bigW'],
        $_POST['bigH'],
        $big_cbm_val,
        $_POST['epl'],
        $_POST['lpp'],
        $_POST['epp'],
        $_POST['pelletL'],
        $_POST['pelletW'],
        $_POST['pelletH'],
        $pellet_cbm_val
    );

    if ($stmt->execute()) {
        $success_message = "SKU '" . htmlspecialchars($_POST['sku_code']) . "' saved successfully.";
    } else {
        $error_message = "Error saving SKU: " . $stmt->error;
    }
    $stmt->close();
}

$compcode = $_SESSION['compcode'];
$sql = "SELECT * FROM sku_master WHERE compcode = '" . $conn->real_escape_string($compcode) . "' ORDER BY created_at DESC";
$result = $conn->query($sql);
$skus = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];


if (isset($_POST['export_csv'])) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="sku_full_export.csv"');

    $output = fopen('php://output', 'w');

    fputcsv($output, [
        'SKU Code',
        'SKU Description',
        'Picking Strategy',
        'Net Weight (KG)',
        'Gross Weight (KG)',
        'Smallest UOM',
        'Smallest Length (M)',
        'Smallest Width (M)',
        'Smallest Height (M)',
        'Smallest CBM',
        'Biggest UOM',
        'Biggest Length (M)',
        'Biggest Width (M)',
        'Biggest Height (M)',
        'Biggest CBM',
        'Each Per Layer',
        'Layer Per Pellet',
        'Each Per Pellet',
        'Pellet Length (M)',
        'Pellet Width (M)',
        'Pellet Height (M)',
        'Pellet CBM',
        'Created At'
    ]);

    $res = $conn->query($sql); // Reuse the query
    while ($row = $res->fetch_assoc()) {
        fputcsv($output, [
            $row['sku_code'],
            $row['sku_description'],
            $row['picking_strategy'],
            $row['net_weight'],
            $row['gross_weight'],
            $row['smallest_uom'],
            $row['smallest_length'],
            $row['smallest_width'],
            $row['smallest_height'],
            $row['smallest_cbm'],
            $row['biggest_uom'],
            $row['biggest_length'],
            $row['biggest_width'],
            $row['biggest_height'],
            $row['biggest_cbm'],
            $row['epl'],
            $row['lpp'],
            $row['epp'],
            $row['pellet_length'],
            $row['pellet_width'],
            $row['pellet_height'],
            $row['pellet_cbm'],
            $row['created_at']
        ]);
    }
    fclose($output);
    exit;
}

?>

<!DOCTYPE html>
<html>

<head>
    <title>Zynex WMS | SKU Master</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../inc/global.css">

    <style>
        .main {
            width: 85%;
            overflow: visible;
        }
        
        .row {
            display: flex;
            flex-wrap: wrap;
            margin: 0 -10px;
        }

        .col-md-2,
        .col-md-3,
        .col-md-4,
        .col-md-8 {
            padding: 0 10px;
            margin-bottom: 10px;
        }

        .col-md-2,
        .col-md-3,
        .col-md-4,
        .col-md-8 {
            width: 100%;
        }

        @media (min-width: 768px) {
            .col-md-2 {
                width: 16.666%;
            }

            .col-md-3 {
                width: 25%;
            }

            .col-md-4 {
                width: 33.333%;
            }

            .col-md-8 {
                width: 66.666%;
            }
        }

        .form-section-title {
            font-weight: 600;
            font-size: 1.1em;
            margin-top: 15px;
            margin-bottom: 10px;
            padding-bottom: 5px;
            border-bottom: 1px solid var(--color-border);
            color: var(--color-accent-blue);
        }

        .cbm-display {
            display: flex;
            flex-direction: column;
            justify-content: flex-end;
        }

        .cbm-value {
            padding: 8px 12px;
            border: 1px solid var(--color-border);
            border-radius: 6px;
            background-color: var(--color-bg-primary);
            color: var(--color-text-primary);
            font-family: monospace;
            font-size: 1.1em;
            text-align: right;
            min-height: 38px;
            display: flex;
            align-items: center;
            justify-content: flex-end;
        }

        .table-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
            font-weight: 500;
        }

        .save-button {
            margin-top: 15px;
            width: auto;
            padding: 10px 20px;
        }
    </style>

</head>

<body>

    <?php require '../parts/nav.php'; ?>

    <div id="main" class="main">
        <h1>SKU Master</h1>

        <?php if ($success_message): ?>
            <div class="message alert-success">
                <?= htmlspecialchars($success_message) ?>
            </div>
        <?php endif; ?>

        <?php if ($error_message): ?>
            <div class="message alert-danger">
                <?= htmlspecialchars($error_message) ?>
            </div>
        <?php endif; ?>

        <div class="card">
            <h2>New SKU Creation</h2>
            <form method="POST">

                <div class="form-section-title">Item Details</div>
                <div class="row">
                    <div class="col-md-4 input-group">
                        <label for="sku_code">SKU Code</label>
                        <input type="text" name="sku_code" id="sku_code" required autofocus>
                    </div>
                    <div class="col-md-8 input-group">
                        <label for="sku_description">SKU Description</label>
                        <input type="text" name="sku_description" id="sku_description" required>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-4 input-group">
                        <label for="picking_strategy">Picking Strategy</label>
                        <select name="picking_strategy" id="picking_strategy" required>
                            <option value="">Select Strategy</option>
                            <option value="First In First Out">First In First Out</option>
                            <option value="First Expiry First Out">First Expiry First Out</option>
                            <option value="Last In First Out">Last In First Out</option>
                            <option value="First Manufacture First Out">First Manufacture First Out</option>
                        </select>
                    </div>
                    <div class="col-md-4 input-group">
                        <label for="net_weight">Net Weight (kg)</label>
                        <input type="number" name="net_weight" id="net_weight" step="0.001">
                    </div>
                    <div class="col-md-4 input-group">
                        <label for="gross_weight">Gross Weight (kg)</label>
                        <input type="number" name="gross_weight" id="gross_weight" step="0.001">
                    </div>
                </div>

                <div class="form-section-title">Smallest UOM</div>
                <div class="row">
                    <div class="col-md-3 input-group">
                        <label for="smallest_uom">Smallest UOM</label>
                        <select name="smallest_uom" id="smallest_uom">
                            <option value="EACH">EACH</option>
                            <option value="CASE">CASE</option>
                            <option value="PELLET">PALLET</option>
                        </select>
                    </div>
                    <div class="col-md-2 input-group">
                        <label for="smallL">Length (L)</label>
                        <input type="number" name="smallL" id="smallL" step="0.001">
                    </div>
                    <div class="col-md-2 input-group">
                        <label for="smallW">Width (W)</label>
                        <input type="number" name="smallW" id="smallW" step="0.001">
                    </div>
                    <div class="col-md-2 input-group">
                        <label for="smallH">Height (H)</label>
                        <input type="number" name="smallH" id="smallH" step="0.001">
                    </div>
                    <div class="col-md-3 cbm-display">
                        <label>Smallest CBM</label>
                        <span id="smallCBM" class="cbm-value">0.000</span>
                        <input type="hidden" name="small_cbm" id="inputSmallCBM">
                    </div>
                </div>

                <div class="form-section-title">Biggest UOM</div>
                <div class="row">
                    <div class="col-md-3 input-group">
                        <label for="biggest_uom">Biggest UOM</label>
                        <select name="biggest_uom" id="biggest_uom">
                            <option value="EACH">EACH</option>
                            <option value="CASE" selected>CASE</option>
                            <option value="PELLET">PALLET</option>
                        </select>
                    </div>
                    <div class="col-md-2 input-group">
                        <label for="bigL">Length (L)</label>
                        <input type="number" name="bigL" id="bigL" step="0.001">
                    </div>
                    <div class="col-md-2 input-group">
                        <label for="bigW">Width (W)</label>
                        <input type="number" name="bigW" id="bigW" step="0.001">
                    </div>
                    <div class="col-md-2 input-group">
                        <label for="bigH">Height (H)</label>
                        <input type="number" name="bigH" id="bigH" step="0.001">
                    </div>
                    <div class="col-md-3 cbm-display">
                        <label>Biggest CBM</label>
                        <span id="bigCBM" class="cbm-value">0.000</span>
                        <input type="hidden" name="big_cbm" id="inputBigCBM">
                    </div>
                </div>

                <div class="form-section-title">Pallet Configuration</div>
                <div class="row">
                    <div class="col-md-4 input-group">
                        <label for="epl">Each Per Layer (EPL)</label>
                        <input type="number" name="epl" id="epl">
                    </div>
                    <div class="col-md-4 input-group">
                        <label for="lpp">Layer Per Pallet (LPP)</label>
                        <input type="number" name="lpp" id="lpp">
                    </div>
                    <div class="col-md-4 input-group">
                        <label for="epp">Each Per Pallet (EPP)</label>
                        <input type="number" name="epp" id="epp">
                    </div>
                </div>

                <div class="form-section-title">Pallet Dimensions</div>
                <div class="row">
                    <div class="col-md-3 input-group">
                        <label for="pelletL">Length (L)</label>
                        <input type="number" name="pelletL" id="pelletL" step="0.001">
                    </div>
                    <div class="col-md-3 input-group">
                        <label for="pelletW">Width (W)</label>
                        <input type="number" name="pelletW" id="pelletW" step="0.001">
                    </div>
                    <div class="col-md-3 input-group">
                        <label for="pelletH">Height (H)</label>
                        <input type="number" name="pelletH" id="pelletH" step="0.001">
                    </div>
                    <div class="col-md-3 cbm-display">
                        <label>Pallet CBM</label>
                        <span id="pelletCBM" class="cbm-value">0.000</span>
                        <input type="hidden" name="pellet_cbm" id="inputPelletCBM">
                    </div>
                </div>

                <button type="submit" class="action-button save-button">Save SKU</button>
            </form>
        </div>

        <div class="card" style="margin-top: 20px;">
            <h2>SKU Records</h2>
            <div class="table-actions">
                <p>Total Records: <?= count($skus) ?></p>
                <form method="post" style="margin-left: auto;">
                    <button type="submit" name="export_csv" class="action-button" style="background-color: var(--color-success); border-color: var(--color-success);">Export as CSV</button>
                </form>
            </div>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>SKU Code</th>
                        <th>Description</th>
                        <th>Strategy</th>
                        <th>Net (kg)</th>
                        <th>Gross (kg)</th>
                        <th>Small CBM</th>
                        <th>Big CBM</th>
                        <th>Pallet CBM</th>
                    </tr>
                    <tr class="filter-row">
                        <th><input type="text" class="filter" data-index="0" placeholder="Filter SKU Code"></th>
                        <th><input type="text" class="filter" data-index="1" placeholder="Filter Description"></th>
                        <th><input type="text" class="filter" data-index="2" placeholder="Filter Strategy"></th>
                        <th><input type="text" class="filter" data-index="3" placeholder="Filter Net"></th>
                        <th><input type="text" class="filter" data-index="4" placeholder="Filter Gross"></th>
                        <th><input type="text" class="filter" data-index="5" placeholder="Filter Small CBM"></th>
                        <th><input type="text" class="filter" data-index="6" placeholder="Filter Big CBM"></th>
                        <th><input type="text" class="filter" data-index="7" placeholder="Filter Pallet CBM"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($skus)): ?>
                        <tr>
                            <td colspan="8" style="text-align: center; color: var(--color-text-secondary);">No SKU records found for this company code.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($skus as $sku): ?>
                            <tr>
                                <td><?= htmlspecialchars($sku['sku_code']) ?></td>
                                <td><?= htmlspecialchars($sku['sku_description']) ?></td>
                                <td><?= htmlspecialchars($sku['picking_strategy']) ?></td>
                                <td><?= number_format((float)$sku['net_weight'], 3) ?></td>
                                <td><?= number_format((float)$sku['gross_weight'], 3) ?></td>
                                <td><?= number_format((float)$sku['smallest_cbm'], 3) ?></td>
                                <td><?= number_format((float)$sku['biggest_cbm'], 3) ?></td>
                                <td><?= number_format((float)$sku['pellet_cbm'], 3) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div>

    <script>
        function cbm(l, w, h) {
            const volume_m3 = parseFloat(l) * parseFloat(w) * parseFloat(h);
            if (isNaN(volume_m3) || volume_m3 <= 0) return 0.000;
            return volume_m3.toFixed(3);
        }

        function updateCBM() {
            // Smallest UOM
            const sL = document.getElementById('smallL').value || 0;
            const sW = document.getElementById('smallW').value || 0;
            const sH = document.getElementById('smallH').value || 0;
            const smallCBM = cbm(sL, sW, sH);

            document.getElementById('smallCBM').innerText = smallCBM;

            // Biggest UOM
            const bL = document.getElementById('bigL').value || 0;
            const bW = document.getElementById('bigW').value || 0;
            const bH = document.getElementById('bigH').value || 0;
            const bigCBM = cbm(bL, bW, bH);

            document.getElementById('bigCBM').innerText = bigCBM;

            // Pallet Data
            const pL = document.getElementById('pelletL').value || 0;
            const pW = document.getElementById('pelletW').value || 0;
            const pH = document.getElementById('pelletH').value || 0;
            const pelletCBM = cbm(pL, pW, pH);

            document.getElementById('pelletCBM').innerText = pelletCBM;
        }

        document.querySelectorAll('#smallL, #smallW, #smallH, #bigL, #bigW, #bigH, #pelletL, #pelletW, #pelletH').forEach(input => {
            input.setAttribute('step', '0.001');
            input.addEventListener('input', updateCBM);
        });

        updateCBM();
    </script>

    <script>
        document.querySelectorAll(".filter").forEach(input => {
            input.addEventListener("input", function() {
                const table = input.closest("table");
                const rows = table.querySelectorAll("tbody tr");

                const filters = Array.from(table.querySelectorAll(".filter")).map(i => i.value.toLowerCase());

                rows.forEach(row => {
                    if (row.querySelector('td[colspan="8"]')) {
                        return;
                    }

                    const cells = Array.from(row.children);
                    let visible = true;

                    for (let i = 0; i < filters.length; i++) {
                        const filter = filters[i];
                        if (filter.length > 0) {
                            if (!cells[i] || !cells[i].textContent.toLowerCase().includes(filter)) {
                                visible = false;
                                break;
                            }
                        }
                    }
                    row.style.display = visible ? "" : "none";
                });
            });
        });
    </script>

</body>

</html>