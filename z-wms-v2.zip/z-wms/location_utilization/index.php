<?php
session_start();
require '../inc/db.php'; //

if (empty($_SESSION['username']) || empty($_SESSION['compcode']) || empty($_SESSION['wh_code'])) {
    header("Location: ../");
    exit();
}

$compcode = $_SESSION['compcode'];
$wh_code = $_SESSION['wh_code'];

// --- PHP IS NOW MUCH SIMPLER ---
// It only gets the initial filter values from the URL to populate the fields.
// The actual data fetching is now done by fetch_utilization_data.php
$filters = [
    'loc' => $_GET['loc'] ?? '',
    'zone' => $_GET['zone'] ?? '',
    'comp' => $_GET['comp'] ?? '',
    'sku' => $_GET['sku'] ?? '',
    'batch' => $_GET['batch'] ?? '',
    'mfd' => $_GET['mfd'] ?? '',
    'exd' => $_GET['exd'] ?? '',
    'inhand' => $_GET['inhand'] ?? '',
    'alloc' => $_GET['alloc'] ?? '',
    'net' => $_GET['net'] ?? '',
    'draft' => $_GET['draft'] ?? ''
];

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zynex WMS | Location Utilization</title>
    <link rel="stylesheet" href="../inc/global.css">
    <style>
        .main {
            width: 85%;
            overflow: visible;
        }

        .empty-row td {
            color: var(--color-text-secondary);
            font-style: italic;
        }

        .filter-row input {
            width: 100%;
            padding: 5px;
            box-sizing: border-box;
            border: 1px solid var(--color-border);
            border-radius: 4px;
            font-size: 0.9em;
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .card-header h3 {
            margin: 0;
        }

        .action-button.export {
            background-color: var(--color-success);
            border-color: var(--color-success);
            color: white;
            text-decoration: none;
            padding: 6px 12px;
            font-size: 0.9em;
        }

        .action-button.export:hover {
            background-color: #22863a;
            border-color: #22863a;
        }

        /* Style for the loading row */
        .loading-row td {
            text-align: center;
            padding: 20px;
            font-style: italic;
            color: var(--color-text-secondary);
        }
    </style>
</head>

<body>

    <?php require '../parts/nav.php'; ?>

    <div id="main" class="main">
        <div class="module-container">
            <h2>Location Utilization Report (Warehouse: <?= htmlspecialchars($wh_code) ?>)</h2>

            <?php if (!empty($message)) echo $message; ?>

            <div class="card">

                <div class="card-header">
                    <h3>All Locations</h3>
                    <a href="export_utilization.php?<?= http_build_query($filters) ?>" class="action-button export" id="exportButton">
                        Export to Excel
                    </a>
                </div>

                <table class="data-table" id="utilizationTable">
                    <thead>
                        <tr>
                            <th>Location</th>
                            <th>Zone</th>
                            <th>Company</th>
                            <th>SKU Code</th>
                            <th>Batch</th>
                            <th>MFD</th>
                            <th>EXD</th>
                            <th>In Hand</th>
                            <th>Allocated</th>
                            <th>Net Qty</th>
                            <th>Draft Allocations (Issue#)</th>
                        </tr>
                        <tr class="filter-row">
                            <th><input type="text" id="filter_loc" onkeyup="debouncedFilter()" value="<?= htmlspecialchars($filters['loc']) ?>" placeholder="Filter Location..."></th>
                            <th><input type="text" id="filter_zone" onkeyup="debouncedFilter()" value="<?= htmlspecialchars($filters['zone']) ?>" placeholder="Filter Zone..."></th>
                            <th><input type="text" id="filter_comp" onkeyup="debouncedFilter()" value="<?= htmlspecialchars($filters['comp']) ?>" placeholder="Filter Company..."></th>
                            <th><input type="text" id="filter_sku" onkeyup="debouncedFilter()" value="<?= htmlspecialchars($filters['sku']) ?>" placeholder="Filter SKU..."></th>
                            <th><input type="text" id="filter_batch" onkeyup="debouncedFilter()" value="<?= htmlspecialchars($filters['batch']) ?>" placeholder="Filter Batch..."></th>
                            <th><input type="text" id="filter_mfd" onkeyup="debouncedFilter()" value="<?= htmlspecialchars($filters['mfd']) ?>" placeholder="Filter MFD..."></th>
                            <th><input type="text" id="filter_exd" onkeyup="debouncedFilter()" value="<?= htmlspecialchars($filters['exd']) ?>" placeholder="Filter EXD..."></th>
                            <th><input type="text" id="filter_inhand" onkeyup="debouncedFilter()" value="<?= htmlspecialchars($filters['inhand']) ?>" placeholder="Filter In Hand..."></th>
                            <th><input type="text" id="filter_alloc" onkeyup="debouncedFilter()" value="<?= htmlspecialchars($filters['alloc']) ?>" placeholder="Filter Alloc..."></th>
                            <th><input type="text" id="filter_net" onkeyup="debouncedFilter()" value="<?= htmlspecialchars($filters['net']) ?>" placeholder="Filter Net..."></th>
                            <th><input type="text" id="filter_draft" onkeyup="debouncedFilter()" value="<?= htmlspecialchars($filters['draft']) ?>" placeholder="Filter Drafts..."></th>
                        </tr>
                    </thead>
                    <tbody id="reportTableBody">
                    </tbody>
                </table>
                <div style="text-align: right; margin-top: 20px;">
                    <a href="index.php" class="action-button-link" style="margin-right: 10px;">Clear Filters</a>
                </div>
            </div>
        </div>
    </div>

    <script>
        let filterTimeout; // Timer for debouncing

        // 1. Debounce function: Waits 500ms after user stops typing
        function debouncedFilter() {
            clearTimeout(filterTimeout);
            filterTimeout = setTimeout(filterReportLive, 500);
        }

        // 2. Main function to fetch and update data
        async function filterReportLive() {
            const tableBody = document.getElementById("reportTableBody");
            tableBody.innerHTML = '<tr class="loading-row"><td colspan="11">Loading...</td></tr>';

            // 3. Build URL parameters from all filters
            const params = new URLSearchParams();
            const filters = {
                loc: document.getElementById('filter_loc').value,
                zone: document.getElementById('filter_zone').value,
                comp: document.getElementById('filter_comp').value,
                sku: document.getElementById('filter_sku').value,
                batch: document.getElementById('filter_batch').value,
                mfd: document.getElementById('filter_mfd').value,
                exd: document.getElementById('filter_exd').value,
                inhand: document.getElementById('filter_inhand').value,
                alloc: document.getElementById('filter_alloc').value,
                net: document.getElementById('filter_net').value,
                draft: document.getElementById('filter_draft').value
            };

            for (const [key, value] of Object.entries(filters)) {
                if (value) {
                    params.append(key, value);
                }
            }

            const queryString = params.toString();

            // 4. Update Export link and browser URL
            document.getElementById('exportButton').href = `export_utilization.php?${queryString}`;
            const newUrl = window.location.pathname + '?' + queryString;
            window.history.replaceState({}, '', newUrl); // Updates URL without reload

            try {
                // 5. Fetch new table data from the AJAX handler
                const response = await fetch(`fetch_utilization_data.php?${queryString}`);
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                const html = await response.text();

                // 6. Inject new data into the table
                tableBody.innerHTML = html;
            } catch (error) {
                console.error('Error fetching filtered data:', error);
                tableBody.innerHTML = '<tr class="loading-row"><td colspan="11" style="color: red;">Error loading data.</td></tr>';
            }
        }

        // 7. Load data on initial page load
        document.addEventListener("DOMContentLoaded", filterReportLive);
    </script>

</body>

</html>