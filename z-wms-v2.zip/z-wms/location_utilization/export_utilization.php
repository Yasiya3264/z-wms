<?php
session_start();
require '../inc/db.php'; //

if (empty($_SESSION['username']) || empty($_SESSION['compcode']) || empty($_SESSION['wh_code'])) {
    die("Unauthorized access.");
}

$compcode = $_SESSION['compcode'];
$wh_code = $_SESSION['wh_code'];
$report_data = [];

try {
    // Base SQL
    $sql = "
        SELECT
            wl.location_code,
            wl.zone_code,
            i.compcode,
            i.sku_code,
            i.batch_number,
            i.mfd,
            i.exd,
            i.in_hand_qty,
            i.allocated_qty,
            (COALESCE(i.in_hand_qty, 0) - COALESCE(i.allocated_qty, 0)) AS net_qty,
            GROUP_CONCAT(DISTINCT oi.issue_number SEPARATOR ', ') AS draft_issue_numbers
        FROM
            warehouse_locations wl
        LEFT JOIN
            inventory i ON wl.location_code = i.location_code
        LEFT JOIN
            outbound_issues oi ON i.location_code = oi.location_code
                               AND i.sku_code = oi.sku_code
                               AND i.batch_number = oi.batch_number
                               AND i.compcode = oi.compcode
                               AND oi.status = 'draft'
    ";

    // --- Dynamic WHERE and HAVING clause generation ---
    $where_conditions = [];
    $having_conditions = [];
    $params = [];
    $types = "";

    // Always filter by warehouse code
    $where_conditions[] = "wl.wh_code = ?";
    $params[] = $wh_code;
    $types .= "s";

    // --- Check each filter from $_GET ---
    
    if (!empty($_GET['loc'])) {
        $where_conditions[] = "wl.location_code LIKE ?";
        $params[] = "%" . $_GET['loc'] . "%";
        $types .= "s";
    }
    if (!empty($_GET['zone'])) {
        $where_conditions[] = "wl.zone_code LIKE ?";
        $params[] = "%" . $_GET['zone'] . "%";
        $types .= "s";
    }
    if (!empty($_GET['comp'])) {
        // Handle 'N/A' for empty locations
        if (strtoupper($_GET['comp']) == 'N/A') {
            $where_conditions[] = "i.compcode IS NULL";
        } else {
            $where_conditions[] = "i.compcode LIKE ?";
            $params[] = "%" . $_GET['comp'] . "%";
            $types .= "s";
        }
    }
    if (!empty($_GET['sku'])) {
        if (strtoupper($_GET['sku']) == 'N/A') {
            $where_conditions[] = "i.sku_code IS NULL";
        } else {
            $where_conditions[] = "i.sku_code LIKE ?";
            $params[] = "%" . $_GET['sku'] . "%";
            $types .= "s";
        }
    }
    if (!empty($_GET['batch'])) {
         if (strtoupper($_GET['batch']) == 'N/A') {
            $where_conditions[] = "i.batch_number IS NULL";
        } else {
            $where_conditions[] = "i.batch_number LIKE ?";
            $params[] = "%" . $_GET['batch'] . "%";
            $types .= "s";
        }
    }
    if (!empty($_GET['mfd'])) {
        $where_conditions[] = "i.mfd LIKE ?";
        $params[] = "%" . $_GET['mfd'] . "%";
        $types .= "s";
    }
    if (!empty($_GET['exd'])) {
        $where_conditions[] = "i.exd LIKE ?";
        $params[] = "%" . $_GET['exd'] . "%";
        $types .= "s";
    }
    if (isset($_GET['inhand']) && $_GET['inhand'] !== '') {
        $where_conditions[] = "COALESCE(i.in_hand_qty, 0) = ?";
        $params[] = $_GET['inhand'];
        $types .= "i";
    }
    if (isset($_GET['alloc']) && $_GET['alloc'] !== '') {
        $where_conditions[] = "COALESCE(i.allocated_qty, 0) = ?";
        $params[] = $_GET['alloc'];
        $types .= "i";
    }
    
    // --- HAVING conditions (for calculated/aggregated fields) ---
    
    if (isset($_GET['net']) && $_GET['net'] !== '') {
        $having_conditions[] = "net_qty = ?";
        $params[] = $_GET['net'];
        $types .= "i";
    }
    if (!empty($_GET['draft'])) {
        if (strtoupper($_GET['draft']) == 'N/A') {
            $having_conditions[] = "draft_issue_numbers IS NULL";
        } else {
            $having_conditions[] = "draft_issue_numbers LIKE ?";
            $params[] = "%" . $_GET['draft'] . "%";
            $types .= "s";
        }
    }

    // --- Assemble the final query ---
    if (count($where_conditions) > 0) {
        $sql .= " WHERE " . implode(" AND ", $where_conditions);
    }
    
    $sql .= "
        GROUP BY
            wl.location_code,
            wl.zone_code,
            i.compcode,
            i.sku_code,
            i.batch_number,
            i.mfd,
            i.exd,
            i.in_hand_qty,
            i.allocated_qty
    ";

    if (count($having_conditions) > 0) {
        $sql .= " HAVING " . implode(" AND ", $having_conditions);
    }

    $sql .= " ORDER BY wl.location_code ASC, i.sku_code ASC";

    // --- Prepare and execute the dynamic query ---
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception("Error preparing dynamic SQL: " . $conn->error);
    }

    if (count($params) > 0) {
        $stmt->bind_param($types, ...$params);
    }

    $stmt->execute();
    $result = $stmt->get_result();

    // --- Set HTTP headers for CSV download ---
    $filename = "Location_Utilization_Filtered_" . $wh_code . "_" . date('Y-m-d') . ".csv";
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=' . $filename);

    $output = fopen('php://output', 'w');

    // Write the header row
    fputcsv($output, [
        'Location',
        'Zone',
        'Company',
        'SKU Code',
        'Batch',
        'MFD',
        'EXD',
        'In Hand',
        'Allocated',
        'Net Qty',
        'Draft Allocations (Issue#)'
    ]);

    // Write data rows
    while ($row = $result->fetch_assoc()) {
        fputcsv($output, [
            $row['location_code'],
            $row['zone_code'],
            $row['compcode'] ?: 'N/A',
            $row['sku_code'] ?: 'N/A',
            $row['batch_number'] ?: 'N/A',
            $row['mfd'] ?: 'N/A',
            $row['exd'] ?: 'N/A',
            (int)$row['in_hand_qty'],
            (int)$row['allocated_qty'],
            (int)$row['net_qty'],
            $row['draft_issue_numbers'] ?: 'N/A'
        ]);
    }

    $stmt->close();
    $conn->close();
    fclose($output);
    exit();

} catch (Exception $e) {
    die("Error generating report: " . $e->getMessage());
}
?>