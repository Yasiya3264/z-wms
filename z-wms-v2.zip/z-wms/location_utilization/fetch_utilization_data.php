<?php
session_start();
require '../inc/db.php'; //

if (empty($_SESSION['username']) || empty($_SESSION['compcode']) || empty($_SESSION['wh_code'])) {
    http_response_code(401); // Unauthorized
    echo '<tr><td colspan="11">Error: Unauthorized access.</td></tr>';
    exit();
}

$compcode = $_SESSION['compcode'];
$wh_code = $_SESSION['wh_code'];

try {
    // Base SQL
    $sql = "
        SELECT
            wl.location_code,
            wl.zone_code,
            i.compcode,
            i.sku_code,
            i.batch_number,
            i.mfd,
            i.exd,
            i.in_hand_qty,
            i.allocated_qty,
            (COALESCE(i.in_hand_qty, 0) - COALESCE(i.allocated_qty, 0)) AS net_qty,
            GROUP_CONCAT(DISTINCT oi.issue_number SEPARATOR ', ') AS draft_issue_numbers
        FROM
            warehouse_locations wl
        LEFT JOIN
            inventory i ON wl.location_code = i.location_code
        LEFT JOIN
            outbound_issues oi ON i.location_code = oi.location_code
                               AND i.sku_code = oi.sku_code
                               AND i.batch_number = oi.batch_number
                               AND i.compcode = oi.compcode
                               AND oi.status = 'draft'
    ";

    // --- Dynamic WHERE and HAVING clause generation (Same as export) ---
    $where_conditions = [];
    $having_conditions = [];
    $params = [];
    $types = "";

    $where_conditions[] = "wl.wh_code = ?";
    $params[] = $wh_code;
    $types .= "s";

    if (!empty($_GET['loc'])) {
        $where_conditions[] = "wl.location_code LIKE ?";
        $params[] = "%" . $_GET['loc'] . "%";
        $types .= "s";
    }
    if (!empty($_GET['zone'])) {
        $where_conditions[] = "wl.zone_code LIKE ?";
        $params[] = "%" . $_GET['zone'] . "%";
        $types .= "s";
    }
    if (!empty($_GET['comp'])) {
        if (strtoupper($_GET['comp']) == 'N/A') {
            $where_conditions[] = "i.compcode IS NULL";
        } else {
            $where_conditions[] = "i.compcode LIKE ?";
            $params[] = "%" . $_GET['comp'] . "%";
            $types .= "s";
        }
    }
    if (!empty($_GET['sku'])) {
        if (strtoupper($_GET['sku']) == 'N/A') {
            $where_conditions[] = "i.sku_code IS NULL";
        } else {
            $where_conditions[] = "i.sku_code LIKE ?";
            $params[] = "%" . $_GET['sku'] . "%";
            $types .= "s";
        }
    }
    if (!empty($_GET['batch'])) {
         if (strtoupper($_GET['batch']) == 'N/A') {
            $where_conditions[] = "i.batch_number IS NULL";
        } else {
            $where_conditions[] = "i.batch_number LIKE ?";
            $params[] = "%" . $_GET['batch'] . "%";
            $types .= "s";
        }
    }
    if (!empty($_GET['mfd'])) {
        $where_conditions[] = "i.mfd LIKE ?";
        $params[] = "%" . $_GET['mfd'] . "%";
        $types .= "s";
    }
    if (!empty($_GET['exd'])) {
        $where_conditions[] = "i.exd LIKE ?";
        $params[] = "%" . $_GET['exd'] . "%";
        $types .= "s";
    }
    if (isset($_GET['inhand']) && $_GET['inhand'] !== '') {
        $where_conditions[] = "COALESCE(i.in_hand_qty, 0) = ?";
        $params[] = $_GET['inhand'];
        $types .= "i";
    }
    if (isset($_GET['alloc']) && $_GET['alloc'] !== '') {
        $where_conditions[] = "COALESCE(i.allocated_qty, 0) = ?";
        $params[] = $_GET['alloc'];
        $types .= "i";
    }
    
    if (isset($_GET['net']) && $_GET['net'] !== '') {
        $having_conditions[] = "net_qty = ?";
        $params[] = $_GET['net'];
        $types .= "i";
    }
    if (!empty($_GET['draft'])) {
        if (strtoupper($_GET['draft']) == 'N/A') {
            $having_conditions[] = "draft_issue_numbers IS NULL";
        } else {
            $having_conditions[] = "draft_issue_numbers LIKE ?";
            $params[] = "%" . $_GET['draft'] . "%";
            $types .= "s";
        }
    }

    if (count($where_conditions) > 0) {
        $sql .= " WHERE " . implode(" AND ", $where_conditions);
    }
    
    $sql .= "
        GROUP BY
            wl.location_code,
            wl.zone_code,
            i.compcode,
            i.sku_code,
            i.batch_number,
            i.mfd,
            i.exd,
            i.in_hand_qty,
            i.allocated_qty
    ";

    if (count($having_conditions) > 0) {
        $sql .= " HAVING " . implode(" AND ", $having_conditions);
    }

    $sql .= " ORDER BY wl.location_code ASC, i.sku_code ASC";

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception("Error preparing dynamic SQL: " . $conn->error);
    }

    if (count($params) > 0) {
        $stmt->bind_param($types, ...$params);
    }

    $stmt->execute();
    $result = $stmt->get_result();
    
    // --- Build HTML string instead of CSV ---
    $html_output = "";
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $is_empty = empty($row['sku_code']);
            $row_class = $is_empty ? 'class="empty-row"' : '';

            $html_output .= "<tr {$row_class}>";
            $html_output .= "<td data-label='Location'>" . htmlspecialchars($row['location_code']) . "</td>";
            $html_output .= "<td data-label='Zone'>" . htmlspecialchars($row['zone_code']) . "</td>";
            $html_output .= "<td data-label='Company'>" . htmlspecialchars($row['compcode'] ?: 'N/A') . "</td>";
            $html_output .= "<td data-label='SKU Code'>" . htmlspecialchars($row['sku_code'] ?: 'N/A') . "</td>";
            $html_output .= "<td data-label='Batch'>" . htmlspecialchars($row['batch_number'] ?: 'N/A') . "</td>";
            $html_output .= "<td data-label='MFD'>" . htmlspecialchars($row['mfd'] ?: 'N/A') . "</td>";
            $html_output .= "<td data-label='EXD'>" . htmlspecialchars($row['exd'] ?: 'N/A') . "</td>";
            $html_output .= "<td data-label='In Hand'>" . (int)$row['in_hand_qty'] . "</td>";
            $html_output .= "<td data-label='Allocated'>" . (int)$row['allocated_qty'] . "</td>";
            $html_output .= "<td data-label='Net Qty'><strong>" . (int)$row['net_qty'] . "</strong></td>";
            $html_output .= "<td data-label='Draft Allocations'>" . htmlspecialchars($row['draft_issue_numbers'] ?: 'N/A') . "</td>";
            $html_output .= "</tr>";
        }
    } else {
        $html_output = '<tr><td colspan="11" style="text-align: center;">No locations found matching your filter criteria.</td></tr>';
    }

    echo $html_output; // Send back the HTML
    
    $stmt->close();
    $conn->close();
    exit();

} catch (Exception $e) {
    http_response_code(500); // Internal Server Error
    echo '<tr><td colspan="11">Error generating report: ' . htmlspecialchars($e->getMessage()) . '</td></tr>';
    exit();
}
?>