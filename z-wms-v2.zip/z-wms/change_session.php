<?php
session_start();
// Use require_once to be safe, in case db.php was already included
require 'inc/db.php'; // Adjust path as needed

// 1. Check if user is logged in
if (empty($_SESSION['username']) || empty($_SESSION['wh_code'])) {
    header("Location: login/"); // Redirect to login if not logged in
    exit();
}

// 2. Get the new company code
if (empty($_GET['new_compcode'])) {
    header("Location: ."); // Redirect to dashboard if no new code is provided
    exit();
}

$username = $_SESSION['username'];
$wh_code = $_SESSION['wh_code'];
$new_compcode = trim($_GET['new_compcode']);

try {
    // 3. SECURITY CHECK: Verify user has access to this new compcode
    // This query checks the users_db table for the specific combination
    $check_sql = "SELECT COUNT(*) as count FROM users_db 
                  WHERE username = ? AND wh_code = ? AND compcode = ?";
    $check_stmt = $conn->prepare($check_sql);
    
    if ($check_stmt) {
        $check_stmt->bind_param("sss", $username, $wh_code, $new_compcode);
        $check_stmt->execute();
        $result = $check_stmt->get_result();
        $row = $result->fetch_assoc();
        $check_stmt->close();

        // 4. If valid, update session
        if ($row && $row['count'] > 0) {
            $_SESSION['compcode'] = $new_compcode;
        } else {
            // Optional: set an error message for debugging
            $_SESSION['error_message'] = "Unauthorized company code switch attempted.";
        }
    } else {
         throw new Exception("Database error preparing check: " . $conn->error);
    }

} catch (Exception $e) {
    $_SESSION['error_message'] = "An error occurred: " . $e->getMessage();
}

// 5. Redirect back to the main dashboard/homepage
// This ensures all pages reload with the new session company.
header("Location: ."); 
exit();
?>