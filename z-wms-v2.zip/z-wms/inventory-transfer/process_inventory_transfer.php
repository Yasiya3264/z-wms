<?php
session_start();
require '../inc/db.php';

header('Content-Type: application/json');

if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit();
}

$compcode = $_SESSION['compcode'];
$action = $_POST['action'] ?? '';
$current_user = $_SESSION['username']; // Get the current logged-in user

$conn->begin_transaction(); // Start transaction for atomicity

try {
    switch ($action) {
        case 'check_location':
            $location_code = trim($_POST['location_code'] ?? '');

            if (empty($location_code)) {
                echo json_encode(['status' => 'error', 'message' => 'Location code cannot be empty.']);
                exit(); // Exit early for invalid input
            }

            // Query to check if location exists in warehouse_locations for the current company
            $check_sql = "SELECT COUNT(*) FROM warehouse_locations WHERE location_code = ?";
            $check_stmt = $conn->prepare($check_sql);

            if (!$check_stmt) {
                throw new Exception("Database error preparing location check statement: " . $conn->error);
            }

            $check_stmt->bind_param("s", $location_code);
            $check_stmt->execute();
            $check_stmt->bind_result($count);
            $check_stmt->fetch();
            $check_stmt->close();

            if ($count > 0) {
                echo json_encode(['status' => 'success', 'message' => 'Location is valid.']);
            } else {
                echo json_encode(['status' => 'error', 'message' => ">> " . $location_code . ' ->> Location not found Please check with location master.']);
            }
            exit(); // Exit after responding to check_location action

        case 'add_draft':
            $from_inventory_id = (int)$_POST['from_inventory_id'];
            $transfer_quantity = (int)$_POST['transfer_quantity'];
            $to_location_code = trim($_POST['to_location_code']);
            $to_batch_number = trim($_POST['to_batch_number']);
            $to_mfd = trim($_POST['to_mfd']);
            $to_exd = trim($_POST['to_exd']);

            if ($from_inventory_id <= 0 || $transfer_quantity <= 0 || empty($to_location_code)) {
                throw new Exception("Invalid input for adding draft transfer. Missing required fields or invalid quantities.");
            }

            // Server-side validation for to_location_code (MANDATORY for security)
            $check_to_location_sql = "SELECT COUNT(*) FROM warehouse_locations WHERE location_code = ?";
            $check_to_location_stmt = $conn->prepare($check_to_location_sql);
            if (!$check_to_location_stmt) {
                throw new Exception("Database error preparing 'to_location_code' validation: " . $conn->error);
            }
            $check_to_location_stmt->bind_param("s", $to_location_code);
            $check_to_location_stmt->execute();
            $check_to_location_stmt->bind_result($location_count);
            $check_to_location_stmt->fetch();
            $check_to_location_stmt->close();

            if ($location_count === 0) {
                throw new Exception("The specified destination location ('" . htmlspecialchars($to_location_code) . "') is invalid or not found for your company.");
            }

            // 1. Fetch 'from' inventory details and check quantity
            $from_inv_sql = "SELECT sku_code, location_code, batch_number, mfd, exd, in_hand_qty
                             FROM inventory
                             WHERE id = ? AND compcode = ? AND in_hand_qty >= ?";
            $from_inv_stmt = $conn->prepare($from_inv_sql);
            if (!$from_inv_stmt) {
                throw new Exception("Database error preparing 'from' inventory fetch: " . $conn->error);
            }
            $from_inv_stmt->bind_param("isi", $from_inventory_id, $compcode, $transfer_quantity);
            $from_inv_stmt->execute();
            $from_inv_result = $from_inv_stmt->get_result();
            $from_item = $from_inv_result->fetch_assoc();
            $from_inv_stmt->close();

            if (!$from_item) {
                throw new Exception("Source inventory item not found or insufficient quantity for transfer.");
            }

            // Auto-generate Transfer Number (e.g., COMPCODE-TR-YYYYMMDD-00001)
            $transfer_prefix = $compcode . '-TR-' . date('Ymd') . '-';
            $max_transfer_sql = "SELECT transfer_number FROM inventory_transfers
                                 WHERE compcode = ? AND transfer_number LIKE ?
                                 ORDER BY transfer_number DESC LIMIT 1";
            $max_transfer_stmt = $conn->prepare($max_transfer_sql);
            if (!$max_transfer_stmt) {
                throw new Exception("Database error preparing transfer number query: " . $conn->error);
            }
            $transfer_like_param = $transfer_prefix . '%';
            $max_transfer_stmt->bind_param("ss", $compcode, $transfer_like_param);
            $max_transfer_stmt->execute();
            $max_transfer_result = $max_transfer_stmt->get_result();
            $last_transfer_number = '';
            if ($max_transfer_row = $max_transfer_result->fetch_assoc()) {
                $last_transfer_number = $max_transfer_row['transfer_number'];
            }
            $max_transfer_stmt->close();

            $next_sequence = 1;
            if (!empty($last_transfer_number)) {
                $parts = explode('-', $last_transfer_number);
                if (count($parts) > 0 && is_numeric($parts[count($parts) - 1])) {
                    $next_sequence = (int)$parts[count($parts) - 1] + 1;
                }
            }
            $system_transfer_number = $transfer_prefix . sprintf('%05d', $next_sequence);

            // Use 'from' values if 'to' values are empty for optional fields
            $final_to_batch = empty($to_batch_number) ? $from_item['batch_number'] : $to_batch_number;
            $final_to_mfd = empty($to_mfd) ? $from_item['mfd'] : $to_mfd;
            $final_to_exd = empty($to_exd) ? $from_item['exd'] : $to_exd;

            // 2. Insert into inventory_transfers as draft
            $insert_sql = "INSERT INTO inventory_transfers
                           (compcode, transfer_number, from_sku_code, from_location_code, from_batch_number, from_mfd, from_exd,
                            transfer_quantity, to_location_code, to_batch_number, to_mfd, to_exd, created_by, status)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'draft')";
            $insert_stmt = $conn->prepare($insert_sql);
            if (!$insert_stmt) {
                throw new Exception("Database error preparing insert statement for draft transfer: " . $conn->error);
            }
            $insert_stmt->bind_param(
                "sssssssisssss",
                $compcode,
                $system_transfer_number,
                $from_item['sku_code'],
                $from_item['location_code'],
                $from_item['batch_number'],
                $from_item['mfd'],
                $from_item['exd'],
                $transfer_quantity,
                $to_location_code,
                $final_to_batch,
                $final_to_mfd,
                $final_to_exd,
                $current_user
            );

            if (!$insert_stmt->execute()) {
                throw new Exception("Error adding draft transfer: " . $insert_stmt->error);
            }
            $insert_stmt->close();

            $conn->commit(); // Commit transaction if all operations succeed
            echo json_encode(['status' => 'success', 'message' => 'Draft transfer added successfully.']);
            break;

        case 'confirm_transfer':
            $transfer_id = (int)$_POST['transfer_id'];

            // 1. Fetch transfer details
            $transfer_sql = "SELECT transfer_number, from_sku_code, from_location_code, from_batch_number, from_mfd, from_exd,
                                    transfer_quantity, to_location_code, to_batch_number, to_mfd, to_exd, status
                             FROM inventory_transfers
                             WHERE id = ? AND compcode = ? AND status = 'draft'";
            $transfer_stmt = $conn->prepare($transfer_sql);
            if (!$transfer_stmt) {
                throw new Exception("Database error preparing transfer fetch: " . $conn->error);
            }
            $transfer_stmt->bind_param("is", $transfer_id, $compcode);
            $transfer_stmt->execute();
            $transfer_result = $transfer_stmt->get_result();
            $transfer_details = $transfer_result->fetch_assoc();
            $transfer_stmt->close();

            if (!$transfer_details) {
                throw new Exception("Transfer record not found or already confirmed.");
            }

            // 2. Decrement quantity from 'from' location in inventory
            $update_from_inv_sql = "UPDATE inventory SET in_hand_qty = in_hand_qty - ?
                                    WHERE sku_code = ? AND location_code = ? AND batch_number = ? AND compcode = ?";
            $update_from_inv_stmt = $conn->prepare($update_from_inv_sql);
            if (!$update_from_inv_stmt) {
                throw new Exception("Database error preparing 'from' inventory update: " . $conn->error);
            }
            $update_from_inv_stmt->bind_param(
                "issss",
                $transfer_details['transfer_quantity'],
                $transfer_details['from_sku_code'],
                $transfer_details['from_location_code'],
                $transfer_details['from_batch_number'],
                $compcode
            );
            if (!$update_from_inv_stmt->execute()) {
                throw new Exception("Error updating 'from' inventory: " . $update_from_inv_stmt->error);
            }
            if ($update_from_inv_stmt->affected_rows === 0) {
                throw new Exception("Failed to update 'from' inventory. Check quantity or existence. (Possible concurrent update)");
            }
            $update_from_inv_stmt->close();

            // 3. Increment quantity for 'to' location in inventory (or insert new record)
            $check_to_inv_sql = "SELECT id FROM inventory
                                 WHERE sku_code = ? AND location_code = ? AND batch_number = ? AND compcode = ?";
            $check_to_inv_stmt = $conn->prepare($check_to_inv_sql);
            if (!$check_to_inv_stmt) {
                throw new Exception("Database error preparing 'to' inventory check: " . $conn->error);
            }
            $check_to_inv_stmt->bind_param(
                "ssss",
                $transfer_details['from_sku_code'], // SKU remains the same
                $transfer_details['to_location_code'],
                $transfer_details['to_batch_number'],
                $compcode
            );
            $check_to_inv_stmt->execute();
            $to_inv_exists_result = $check_to_inv_stmt->get_result();
            $check_to_inv_stmt->close();

            if ($to_inv_exists_result->num_rows > 0) {
                // Update existing 'to' inventory record
                $update_to_inv_sql = "UPDATE inventory SET in_hand_qty = in_hand_qty + ?, mfd = ?, exd = ?, grn_number = ?
                                      WHERE sku_code = ? AND location_code = ? AND batch_number = ? AND compcode = ?";
                $update_to_inv_stmt = $conn->prepare($update_to_inv_sql);
                if (!$update_to_inv_stmt) {
                    throw new Exception("Database error preparing 'to' inventory update: " . $conn->error);
                }
                $update_to_inv_stmt->bind_param(
                    "isssssss",
                    $transfer_details['transfer_quantity'],
                    $transfer_details['to_mfd'],
                    $transfer_details['to_exd'],
                    $transfer_details['transfer_number'], // Set grn_number to transfer_number
                    $transfer_details['from_sku_code'],
                    $transfer_details['to_location_code'],
                    $transfer_details['to_batch_number'],
                    $compcode
                );
                if (!$update_to_inv_stmt->execute()) {
                    throw new Exception("Error updating 'to' inventory: " . $update_to_inv_stmt->error);
                }
                $update_to_inv_stmt->close();
            } else {
                // Insert new 'to' inventory record
                $insert_to_inv_sql = "INSERT INTO inventory (compcode, sku_code, location_code, batch_number, mfd, exd, in_hand_qty, allocated_qty, grn_number, received_date)
                                      VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, CURDATE())"; // Using ? for grn_number
                $insert_to_inv_stmt = $conn->prepare($insert_to_inv_sql);
                if (!$insert_to_inv_stmt) {
                    throw new Exception("Database error preparing 'to' inventory insert: " . $conn->error);
                }
                $insert_to_inv_stmt->bind_param(
                    "ssssssis",
                    $compcode,
                    $transfer_details['from_sku_code'],
                    $transfer_details['to_location_code'],
                    $transfer_details['to_batch_number'],
                    $transfer_details['to_mfd'],
                    $transfer_details['to_exd'],
                    $transfer_details['transfer_quantity'],
                    $transfer_details['transfer_number'] // Set grn_number to transfer_number
                );
                if (!$insert_to_inv_stmt->execute()) {
                    throw new Exception("Error inserting new 'to' inventory: " . $insert_to_inv_stmt->error);
                }
                $insert_to_inv_stmt->close();

                // Update warehouse_locations.is_used if it's currently 0 or NULL for this new 'to' location
                $update_location_used_sql = "UPDATE warehouse_locations SET is_used = 1 WHERE location_code = ? AND (is_used = 0 OR is_used IS NULL)";
                $update_location_used_stmt = $conn->prepare($update_location_used_sql);
                if (!$update_location_used_stmt) {
                    // --- THIS IS THE CORRECTED LINE ---
                    throw new Exception("Error preparing location update: " . $conn->error);
                }
                $update_location_used_stmt->bind_param("s", $transfer_details['to_location_code']);
                $update_location_used_stmt->execute();
                $update_location_used_stmt->close();
            }

            // 4. Update transfer status to 'confirmed'
            $update_transfer_sql = "UPDATE inventory_transfers SET status = 'confirmed' WHERE id = ? AND compcode = ?";
            $update_transfer_stmt = $conn->prepare($update_transfer_sql);
            if (!$update_transfer_stmt) {
                throw new Exception("Database error preparing transfer status update: " . $conn->error);
            }
            $update_transfer_stmt->bind_param("is", $transfer_id, $compcode);
            if (!$update_transfer_stmt->execute()) {
                throw new Exception("Error confirming transfer: " . $update_transfer_stmt->error);
            }
            $update_transfer_stmt->close();

            $conn->commit(); // Commit transaction if all operations succeed
            echo json_encode(['status' => 'success', 'message' => 'Inventory transfer confirmed successfully.']);
            break;

        case 'delete_draft':
            $transfer_id = (int)$_POST['transfer_id'];

            $delete_sql = "DELETE FROM inventory_transfers WHERE id = ? AND compcode = ? AND status = 'draft'";
            $delete_stmt = $conn->prepare($delete_sql);
            if (!$delete_stmt) {
                throw new Exception("Database error preparing delete statement: " . $conn->error);
            }
            $delete_stmt->bind_param("is", $transfer_id, $compcode);
            if (!$delete_stmt->execute()) {
                throw new Exception("Error deleting draft transfer: " . $delete_stmt->error);
            }
            if ($delete_stmt->affected_rows === 0) {
                throw new Exception("Draft transfer not found or already confirmed/deleted.");
            }
            $delete_stmt->close();

            $conn->commit(); // Commit transaction
            echo json_encode(['status' => 'success', 'message' => 'Draft transfer deleted successfully.']);
            break;

        default:
            throw new Exception("Invalid action specified.");
    }
} catch (Exception $e) {
    $conn->rollback(); // Rollback transaction on any error
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
} finally {
    // Ensure connection is closed even if an error occurs outside try/catch or after exit()
    if ($conn && $conn->ping()) {
        $conn->close();
    }
}
