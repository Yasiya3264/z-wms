<?php
session_start();
require '../inc/db.php';

header('Content-Type: application/json');

if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit();
}

$compcode = $_SESSION['compcode'];
$search_term = isset($_GET['search_term']) ? trim($_GET['search_term']) : '';

if (empty($search_term)) {
    echo json_encode(['status' => 'error', 'message' => 'Search term is required.']);
    exit();
}

// Fetch inventory records that have in_hand_qty > 0
$sql = "SELECT id, sku_code, location_code, batch_number, mfd, exd, in_hand_qty
        FROM inventory
        WHERE compcode = ? AND in_hand_qty > 0
        AND (sku_code LIKE ? OR location_code LIKE ? OR batch_number LIKE ?)
        ORDER BY sku_code ASC, location_code ASC
        LIMIT 20";

$stmt = $conn->prepare($sql);
if ($stmt) {
    $param = '%' . $search_term . '%';
    $stmt->bind_param("ssss", $compcode, $param, $param, $param);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    $stmt->close();
    echo json_encode(['status' => 'success', 'data' => $data]);
} else {
    error_log("Database error in fetch_inventory_for_transfer.php: " . $conn->error);
    echo json_encode(['status' => 'error', 'message' => 'Database error. Please try again later.']);
}
?>
