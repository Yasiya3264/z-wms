<?php
session_start();
require '../inc/db.php'; //

if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    header("Location: ../");
    exit();
}

$compcode = $_SESSION['compcode'];
$username = $_SESSION['username'];
$message = '';
$receipt_id = isset($_GET['receipt_id']) ? (int)$_GET['receipt_id'] : 0;
$receipt_details = null;
$receipt_items = []; // Items already added to this receipt

if ($receipt_id <= 0) {
    header("Location: index.php"); // Redirect if no valid receipt_id
    exit();
}

// Function to display messages (used by PHP and AJAX response on reload)
function displayMessage($type, $content)
{
    $class = ($type === 'success') ? 'alert-success' : 'alert-danger';
    echo '<div class="message ' . $class . '">' . htmlspecialchars($content) . '</div>';
}


// Fetch Receipt Header Details
$header_sql = "SELECT id, record_number, grn_number, grn_type, receiving_number, vehicle_number, receiving_date, grn_date, status, created_at, wh_code
               FROM inbound_receipts
               WHERE id = ? AND compcode = ? AND sku_code IS NULL"; // Crucial: Fetch the header record
$header_stmt = $conn->prepare($header_sql);
if ($header_stmt) {
    $header_stmt->bind_param("is", $receipt_id, $compcode);
    $header_stmt->execute();
    $header_result = $header_stmt->get_result();
    if ($header_result->num_rows > 0) {
        $receipt_details = $header_result->fetch_assoc();
        $wh_code_for_items = $receipt_details['wh_code']; // Store the retrieved wh_code
    } else {
        $message = 'Receipt not found or unauthorized. It might already be confirmed.';
        $message_type = 'error';
        $receipt_id = 0; // Invalidate receipt_id to prevent further processing
    }
    $header_stmt->close();
} else {
    $message = 'Database error fetching receipt header: ' . htmlspecialchars($conn->error);
    $message_type = 'error';
}

if ($receipt_id > 0 && $receipt_details) { // Only proceed if receipt header details are successfully loaded
    $record_number_for_items = $receipt_details['record_number'];
    $wh_code_for_items = $receipt_details['wh_code']; // Ensure wh_code is available

    // Fetch current items for this receipt from inbound_receipts table
    $items_sql = "SELECT ir.id as item_id, ir.sku_code, sm.sku_description, ir.batch_number, ir.mfd, ir.exd, ir.location_code, ir.quantity
                  FROM inbound_receipts ir
                  LEFT JOIN sku_master sm ON ir.sku_code = sm.sku_code AND ir.compcode = sm.compcode
                  WHERE ir.record_number = ? AND ir.compcode = ? AND ir.sku_code IS NOT NULL
                  ORDER BY ir.created_at ASC";
    $items_stmt = $conn->prepare($items_sql);
    if ($items_stmt) {
        $items_stmt->bind_param("ss", $record_number_for_items, $compcode);
        $items_stmt->execute();
        $items_result = $items_stmt->get_result();
        while ($row = $items_result->fetch_assoc()) {
            $receipt_items[] = $row;
        }
        $items_stmt->close();
    } else {
        $message = 'Database error fetching receipt items: ' . htmlspecialchars($conn->error);
        $message_type = 'error';
    }

    // Handle AJAX POST requests for adding/deleting items or confirming receipt
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
        // Prevent modifications if already confirmed using the 'status' column
        if ($receipt_details['status'] === 'confirmed') {
            echo json_encode(['status' => 'error', 'message' => 'This receipt has already been confirmed and cannot be modified.']);
            exit();
        }

        // Ensure wh_code is available before transactions starts
        if (empty($wh_code_for_items)) {
            echo json_encode(['status' => 'error', 'message' => 'Warehouse Code is missing from the receipt header. Cannot add items.']);
            exit();
        }

        if ($_POST['action'] === 'add_sku_item') {
            $sku_code = trim($_POST['sku_code']);
            $batch_number = trim($_POST['batch_number']);
            $mfd = trim($_POST['mfd']);
            $exd = trim($_POST['exd']);
            $full_amount_received = (int)$_POST['full_amount_received']; // Changed to full_amount_received

            if (empty($sku_code) || empty($batch_number) || empty($mfd) || empty($exd) || $full_amount_received <= 0) {
                echo json_encode(['status' => 'error', 'message' => 'All SKU details (Code, Batch, MFD, EXD, Full Amount Received) are required.']);
                exit();
            }

            // Basic date validation
            if (!strtotime($mfd) || !strtotime($exd)) {
                echo json_encode(['status' => 'error', 'message' => 'Invalid MFD or EXD date format.']);
                exit();
            }

            $conn->begin_transaction();
            try {
                // 1. Fetch EPP for the SKU
                $epp_sql = "SELECT epp FROM sku_master WHERE compcode = ? AND sku_code = ?";
                $epp_stmt = $conn->prepare($epp_sql);
                if (!$epp_stmt) {
                    throw new Exception("Error preparing EPP fetch: " . $conn->error);
                }
                $epp_stmt->bind_param("ss", $compcode, $sku_code);
                $epp_stmt->execute();
                $epp_result = $epp_stmt->get_result();
                $sku_epp = 0;
                if ($row = $epp_result->fetch_assoc()) {
                    $sku_epp = (int)$row['epp'];
                }
                $epp_stmt->close();

                if ($sku_epp <= 0) {
                    throw new Exception("SKU EPP (Each Per Pallet) not found or is invalid for " . htmlspecialchars($sku_code) . ". Cannot allocate locations.");
                }

                // 2. Calculate quantities per pallet and number of allocations needed
                $remaining_quantity = $full_amount_received;
                $allocated_items_count = 0;

                $locations_used_in_this_run = [];

                while ($remaining_quantity > 0) {
                    $quantity_for_this_allocation = min($remaining_quantity, $sku_epp);

                    // Build a dynamic exclusion string for locations already used in this run.
                    $location_exclusion_sql = "";
                    if (!empty($locations_used_in_this_run)) {
                        $escaped_locations = array_map(function ($loc) use ($conn) {
                            return "'" . $conn->real_escape_string($loc) . "'";
                        }, $locations_used_in_this_run);
                        $location_exclusion_sql = " AND wl.location_code NOT IN (" . implode(',', $escaped_locations) . ") ";
                    }


                    // 3. Find an available location
                    // --- UPDATED SQL (Exclusion 2 is now stricter) ---
                    $location_sql = "
                        SELECT
                            wl.location_code,
                            ps.priority AS strategy_priority,
                            CASE
                                WHEN i_consolidation.in_hand_qty IS NULL OR i_consolidation.in_hand_qty = 0 THEN 0 
                                WHEN i_consolidation.sku_code = ?       -- PARAMETER 1 (SKU code)
                                     AND i_consolidation.in_hand_qty > 0
                                     AND i_consolidation.batch_number = ? -- PARAMETER 2 (Batch)
                                     AND i_consolidation.mfd = ?          -- PARAMETER 3 (MFD)
                                     AND i_consolidation.exd = ?          -- PARAMETER 4 (EXD)
                                     THEN 1
                                ELSE 2 
                            END AS putaway_type_priority
                        FROM warehouse_locations wl
                        
                        INNER JOIN putaway_strategy ps ON 
                            wl.wh_code = ps.wh_code AND 
                            wl.zone_code = ps.zone_code AND 
                            ps.compcode = ? -- PARAMETER 5
                            
                        LEFT JOIN inventory i_consolidation ON 
                            i_consolidation.location_code = wl.location_code
                            AND i_consolidation.compcode = ? -- PARAMETER 6
                            AND i_consolidation.sku_code = ? -- PARAMETER 7
                            
                        WHERE
                            wl.status = 1 
                            AND wl.wh_code = ? -- PARAMETER 8
                            
                            -- This is the new dynamic exclusion list from PHP
                            $location_exclusion_sql 
                            
                            -- This is the exclusion for OTHER draft receipts
                            AND NOT EXISTS (
                                SELECT 1
                                FROM inbound_receipts ir
                                WHERE ir.status = 'draft'
                                AND ir.location_code IS NOT NULL
                                AND ir.location_code = wl.location_code
                                AND ir.record_number != ? -- PARAMETER 9 (Current Record Number)
                            )
                            
                            -- 4. EXCLUSION 2 (FIXED): Must NOT have confirmed stock of ANY item
                            -- that does not match the target SKU, Batch, MFD, and EXD.
                            AND NOT EXISTS (
                                SELECT 1 
                                FROM inventory i_occupied
                                WHERE i_occupied.location_code = wl.location_code 
                                AND i_occupied.compcode = ?       -- PARAMETER 10
                                AND i_occupied.in_hand_qty > 0
                                AND (
                                    i_occupied.sku_code != ?      -- PARAMETER 11
                                    OR i_occupied.batch_number != ? -- PARAMETER 12
                                    OR i_occupied.mfd != ?          -- PARAMETER 13
                                    OR i_occupied.exd != ?          -- PARAMETER 14
                                )
                            )
                            
                        ORDER BY
                            strategy_priority ASC,
                            putaway_type_priority ASC,
                            wl.location_code ASC
                        LIMIT 1
                    ";
                    // --- END UPDATED SQL ---

                    $location_stmt = $conn->prepare($location_sql);
                    if (!$location_stmt) {
                        throw new Exception("Error preparing location fetch (SQL: ... $location_exclusion_sql ...): " . $conn->error);
                    }

                    // --- CRITICAL BIND_PARAM UPDATE (14 parameters) ---
                    $location_stmt->bind_param(
                        "ssssssssssssss", // 14 strings 's'

                        // P1-P4: Consolidation Logic (CASE)
                        $sku_code,
                        $batch_number,
                        $mfd,
                        $exd,

                        // P5: Putaway Strategy
                        $compcode,

                        // P6-P7: Consolidation Join (LEFT JOIN)
                        $compcode,
                        $sku_code,

                        // P8: Warehouse Filter
                        $wh_code_for_items,

                        // P9: Exclusion 1 (Draft Receipts)
                        $record_number_for_items,

                        // P10-P14: Exclusion 2 (Occupied Stock)
                        $compcode,
                        $sku_code,
                        $batch_number,
                        $mfd,
                        $exd
                    );
                    // --- END BIND PARAM ---

                    $location_stmt->execute();
                    $location_result = $location_stmt->get_result();

                    $allocated_location_code = null;
                    if ($row = $location_result->fetch_assoc()) {
                        $allocated_location_code = $row['location_code'];
                    }
                    $location_stmt->close();

                    if (empty($allocated_location_code)) {
                        throw new Exception("No suitable warehouse location found for allocation. Please ensure rack zones are configured in 'putaway_strategy' for this Compcode/Warehouse and there are available locations in those zones.");
                    }

                    $locations_used_in_this_run[] = $allocated_location_code;

                    // 4. Insert into inbound_receipts as a line item for this allocation
                    $insert_item_sql = "INSERT INTO inbound_receipts (wh_code, compcode, record_number, grn_type, receiving_number, vehicle_number, receiving_date, status, sku_code, batch_number, mfd, exd, quantity, location_code)
                                       VALUES (?, ?, ?, ?, ?, ?, CURDATE(), 'draft', ?, ?, ?, ?, ?, ?)";
                    $insert_item_stmt = $conn->prepare($insert_item_sql);
                    if (!$insert_item_stmt) {
                        throw new Exception("Error preparing inbound item insert: " . $conn->error);
                    }

                    $insert_item_stmt->bind_param(
                        "ssssssssssis",
                        $wh_code_for_items,
                        $compcode,
                        $record_number_for_items,
                        $receipt_details['grn_type'],
                        $receipt_details['receiving_number'],
                        $receipt_details['vehicle_number'],
                        $sku_code,
                        $batch_number,
                        $mfd,
                        $exd,
                        $quantity_for_this_allocation,
                        $allocated_location_code
                    );
                    if (!$insert_item_stmt->execute()) {
                        throw new Exception("Error inserting inbound item for SKU " . htmlspecialchars($sku_code) . " at location " . htmlspecialchars($allocated_location_code) . ": " . $insert_item_stmt->error);
                    }
                    $insert_item_stmt->close();

                    $remaining_quantity -= $quantity_for_this_allocation;
                    $allocated_items_count++;
                }

                $conn->commit();
                echo json_encode(['status' => 'success', 'message' => 'SKU item(s) added and allocated across ' . $allocated_items_count . ' locations successfully.']);
            } catch (Exception $e) {
                $conn->rollback();
                echo json_encode(['status' => 'error', 'message' => 'Transaction failed: ' . $e->getMessage()]);
            }
            exit();
        } elseif ($_POST['action'] === 'manual_add_sku_item') {
            // New logic for manual putaway
            $sku_code = trim($_POST['sku_code']);
            $batch_number = trim($_POST['batch_number']);
            $mfd = trim($_POST['mfd']);
            $exd = trim($_POST['exd']);
            $quantity = (int)$_POST['quantity'];
            $location_code = trim($_POST['location_code']);

            if (empty($sku_code) || empty($batch_number) || empty($mfd) || empty($exd) || $quantity <= 0 || empty($location_code)) {
                echo json_encode(['status' => 'error', 'message' => 'All details are required.']);
                exit();
            }

            $conn->begin_transaction();
            try {
                // Check if the selected location is valid (no need to check for empty)
                $check_location_sql = "
                    SELECT location_code
                    FROM warehouse_locations
                    WHERE location_code = ? AND status = 1
                ";
                $check_location_stmt = $conn->prepare($check_location_sql);
                $check_location_stmt->bind_param("s", $location_code);
                $check_location_stmt->execute();
                $check_location_result = $check_location_stmt->get_result();

                if ($check_location_result->num_rows === 0) {
                    throw new Exception("The selected location is not valid or is inactive.");
                }
                $check_location_stmt->close();

                // Insert into inbound_receipts as a line item for this allocation
                $insert_item_sql = "INSERT INTO inbound_receipts (wh_code, compcode, record_number, grn_type, receiving_number, vehicle_number, receiving_date, status, sku_code, batch_number, mfd, exd, quantity, location_code)
                                   VALUES (?, ?, ?, ?, ?, ?, CURDATE(), 'draft', ?, ?, ?, ?, ?, ?)";
                $insert_item_stmt = $conn->prepare($insert_item_sql);

                $insert_item_stmt->bind_param(
                    "ssssssssssis",
                    $wh_code_for_items, // The missing wh_code
                    $compcode,
                    $record_number_for_items,
                    $receipt_details['grn_type'],
                    $receipt_details['receiving_number'],
                    $receipt_details['vehicle_number'],
                    $sku_code,
                    $batch_number,
                    $mfd,
                    $exd,
                    $quantity,
                    $location_code
                );
                if (!$insert_item_stmt->execute()) {
                    throw new Exception("Error inserting inbound item for SKU " . htmlspecialchars($sku_code) . ": " . $insert_item_stmt->error);
                }
                $insert_item_stmt->close();

                $conn->commit();
                echo json_encode(['status' => 'success', 'message' => 'SKU item added to location ' . $location_code . ' successfully.']);
            } catch (Exception $e) {
                $conn->rollback();
                echo json_encode(['status' => 'error', 'message' => 'Transaction failed: ' . $e->getMessage()]);
            }
            exit();
        } elseif ($_POST['action'] === 'delete_item') {
            $item_id_to_delete = (int)$_POST['item_id'];

            $conn->begin_transaction();
            try {
                // Delete the item from inbound_receipts
                $delete_item_sql = "DELETE FROM inbound_receipts WHERE id = ? AND compcode = ? AND record_number = ? AND sku_code IS NOT NULL";
                $delete_item_stmt = $conn->prepare($delete_item_sql);
                if (!$delete_item_stmt) {
                    throw new Exception("Error preparing item deletion statement: " . $conn->error);
                }
                $delete_item_stmt->bind_param("iss", $item_id_to_delete, $compcode, $record_number_for_items);
                if (!$delete_item_stmt->execute()) {
                    throw new Exception("Error deleting inbound item: " . $delete_item_stmt->error);
                }

                if ($delete_item_stmt->affected_rows === 0) {
                    throw new Exception("Item not found or already deleted.");
                }
                $delete_item_stmt->close();

                $conn->commit();
                echo json_encode(['status' => 'success', 'message' => 'SKU item removed successfully.']);
            } catch (Exception $e) {
                $conn->rollback();
                echo json_encode(['status' => 'error', 'message' => 'Deletion failed: ' . $e->getMessage()]);
            }
            exit();
        } elseif ($_POST['action'] === 'confirm_receiving') {
            $conn->begin_transaction();
            try {
                // Get all items associated with this record_number
                $confirm_items_sql = "SELECT sku_code, batch_number, mfd, exd, location_code, quantity
                                      FROM inbound_receipts
                                      WHERE record_number = ? AND compcode = ? AND sku_code IS NOT NULL AND quantity > 0";
                $confirm_items_stmt = $conn->prepare($confirm_items_sql);
                if (!$confirm_items_stmt) {
                    throw new Exception("Error preparing confirmation item fetch: " . $conn->error);
                }
                $confirm_items_stmt->bind_param("ss", $record_number_for_items, $compcode);
                $confirm_items_stmt->execute();
                $confirm_result = $confirm_items_stmt->get_result();

                if ($confirm_result->num_rows === 0) {
                    throw new Exception("No items found with quantity > 0 to confirm for this receipt.");
                }

                // --- New GRN Number Generation Logic ---
                $grn_prefix = $compcode . '-' . $receipt_details['grn_type'] . '-';

                $max_grn_sql = "SELECT grn_number FROM inbound_receipts
                               WHERE compcode = ? AND grn_number LIKE ? AND sku_code IS NULL AND status = 'confirmed'
                               ORDER BY grn_number DESC LIMIT 1";
                $max_grn_stmt = $conn->prepare($max_grn_sql);
                if (!$max_grn_stmt) {
                    throw new Exception("Error preparing max GRN query: " . $conn->error);
                }
                $grn_like_param = $grn_prefix . '_____'; // 5 underscores for 5 digits
                $max_grn_stmt->bind_param("ss", $compcode, $grn_like_param);
                $max_grn_stmt->execute();
                $max_grn_result = $max_grn_stmt->get_result();
                $last_grn_number = '';
                if ($max_grn_row = $max_grn_result->fetch_assoc()) {
                    $last_grn_number = $max_grn_row['grn_number'];
                }
                $max_grn_stmt->close();

                $next_grn_sequence = 1;
                if (!empty($last_grn_number)) {
                    if (preg_match('/-(\d{5})$/', $last_grn_number, $matches)) {
                        $next_grn_sequence = (int)$matches[1] + 1;
                    }
                }

                $final_grn_number = $grn_prefix . sprintf('%05d', $next_grn_sequence); // 5 digits, padded

                while ($item = $confirm_result->fetch_assoc()) {
                    // 1. Update/Insert into Inventory
                    $check_inv_sql = "SELECT id FROM inventory WHERE compcode = ? AND sku_code = ? AND batch_number = ? AND location_code = ?";
                    $check_inv_stmt = $conn->prepare($check_inv_sql);
                    if (!$check_inv_stmt) {
                        throw new Exception("Error preparing inventory check: " . $conn->error);
                    }
                    $check_inv_stmt->bind_param("ssss", $compcode, $item['sku_code'], $item['batch_number'], $item['location_code']);
                    $check_inv_stmt->execute();
                    $inv_exists_result = $check_inv_stmt->get_result();
                    $check_inv_stmt->close();

                    if ($inv_exists_result->num_rows > 0) {
                        // Update existing inventory record
                        $update_inv_sql = "UPDATE inventory SET in_hand_qty = in_hand_qty + ?, exd = ?, mfd = ? WHERE compcode = ? AND sku_code = ? AND batch_number = ? AND location_code = ?";
                        $update_inv_stmt = $conn->prepare($update_inv_sql);
                        if (!$update_inv_stmt) {
                            throw new Exception("Error preparing inventory update: " . $conn->error);
                        }
                        $update_inv_stmt->bind_param("issssss", $item['quantity'], $item['exd'], $item['mfd'], $compcode, $item['sku_code'], $item['batch_number'], $item['location_code']);
                        if (!$update_inv_stmt->execute()) {
                            throw new Exception("Error updating inventory for SKU " . htmlspecialchars($item['sku_code']) . ": " . $update_inv_stmt->error);
                        }
                        $update_inv_stmt->close();
                    } else {
                        // Insert new inventory record
                        $insert_inv_sql = "INSERT INTO inventory (compcode, sku_code, location_code, batch_number, mfd, exd, grn_number, received_date, in_hand_qty, allocated_qty)
                                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0)";
                        $insert_inv_stmt = $conn->prepare($insert_inv_sql);
                        if (!$insert_inv_stmt) {
                            throw new Exception("Error preparing inventory insert: " . $conn->error);
                        }
                        $insert_inv_stmt->bind_param("ssssssssi", $compcode, $item['sku_code'], $item['location_code'], $item['batch_number'], $item['mfd'], $item['exd'], $final_grn_number, $receipt_details['receiving_date'], $item['quantity']);
                        if (!$insert_inv_stmt->execute()) {
                            throw new Exception("Error inserting new inventory for SKU " . htmlspecialchars($item['sku_code']) . ": " . $insert_inv_stmt->error);
                        }
                        $insert_inv_stmt->close();

                        // Update warehouse_locations.is_used if it's currently 0 or NULL for this location
                        $update_location_used_sql = "UPDATE warehouse_locations SET is_used = 1 WHERE location_code = ? AND (is_used = 0 OR is_used IS NULL)";
                        $update_location_used_stmt = $conn->prepare($update_location_used_sql);
                        if (!$update_location_used_stmt) {
                            throw new Exception("Error preparing location update: " . $conn->error);
                        }
                        $update_location_used_stmt->bind_param("s", $item['location_code']);
                        $update_location_used_stmt->execute();
                        $update_location_used_stmt->close();
                    }

                    // 2. Insert into Inbound History
                    $insert_history_sql = "INSERT INTO inbound_history (
                           compcode, record_number, grn_number, 
                           receiving_type, receiving_number, receiving_date, 
                           sku_code, batch_number, mfd, exd, location_code, 
                           quantity, created_by
                       )
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    $insert_history_stmt = $conn->prepare($insert_history_sql);
                    if (!$insert_history_stmt) {
                        throw new Exception("Error preparing history insert: " . $conn->error);
                    }

                    $insert_history_stmt->bind_param(
                        "sssssssssssis",
                        $compcode,
                        $record_number_for_items,
                        $final_grn_number,
                        $receipt_details['grn_type'],
                        $receipt_details['receiving_number'],
                        $receipt_details['receiving_date'],
                        $item['sku_code'],
                        $item['batch_number'],
                        $item['mfd'],
                        $item['exd'],
                        $item['location_code'],
                        $item['quantity'],
                        $_SESSION['username']
                    );
                    if (!$insert_history_stmt->execute()) {
                        throw new Exception("Error inserting history record: " . $insert_history_stmt->error);
                    }
                    $insert_history_stmt->close();
                }


                // 3. Update the main receipt header record
                $update_header_sql = "UPDATE inbound_receipts 
                                      SET grn_number = ?, status = 'confirmed', grn_date = CURDATE()
                                      WHERE id = ? AND compcode = ? AND sku_code IS NULL";
                $update_header_stmt = $conn->prepare($update_header_sql);

                if (!$update_header_stmt) {
                    throw new Exception("Error preparing header update: " . $conn->error);
                }

                $update_header_stmt->bind_param("sis", $final_grn_number, $receipt_id, $compcode);
                if (!$update_header_stmt->execute()) {
                    throw new Exception("Error confirming receipt header update: " . $update_header_stmt->error);
                }
                $update_header_stmt->close();

                // 4. Update the line items to confirmed status (optional but good practice)
                $update_items_sql = "UPDATE inbound_receipts SET status = 'confirmed', grn_number = ? WHERE record_number = ? AND compcode = ? AND sku_code IS NOT NULL";
                $update_items_stmt = $conn->prepare($update_items_sql);
                $update_items_stmt->bind_param("sss", $final_grn_number, $record_number_for_items, $compcode);
                $update_items_stmt->execute();
                $update_items_stmt->close();


                $conn->commit();
                echo json_encode(['status' => 'success', 'message' => 'Receiving confirmed successfully! GRN: ' . $final_grn_number, 'is_confirmed' => true, 'grn_number' => $final_grn_number]);
            } catch (Exception $e) {
                $conn->rollback();
                echo json_encode(['status' => 'error', 'message' => 'Confirmation failed: ' . $e->getMessage()]);
            }
            exit();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Zynex WMS | Manage Inbound Receipt</title>

    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="../inc/global.css">

    <style>
        .content-card {
            background: var(--color-bg-secondary);
            border: 1px solid var(--color-border);
            border-radius: 8px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        }

        .message {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 6px;
            font-weight: 500;
            border: 1px solid transparent;
        }

        .alert-success {
            background-color: #e6ffed;
            color: #2c6f4e;
            border-color: #b7e4c7;
        }

        .alert-danger {
            background-color: #fcebeb;
            color: #d73a49;
            border-color: #fbbbbd;
        }

        h3 {
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
            margin-bottom: 20px;
            font-size: 1.2em;
        }

        .receipt-header-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 10px 20px;
        }

        .detail-item {
            display: flex;
            flex-direction: column;
            padding: 5px 0;
        }

        .detail-item strong {
            font-weight: 600;
            color: var(--color-text-primary);
            margin-bottom: 3px;
            font-size: 0.9em;
        }

        .detail-item span {
            font-size: 1em;
            color: var(--color-text-secondary);
        }

        .form-group-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group label {
            font-weight: 500;
            color: var(--color-text-primary);
            margin-bottom: 5px;
        }

        input,
        select {
            width: 100%;
            padding: 8px 12px;
            box-sizing: border-box;
            border: 1px solid var(--color-border);
            border-radius: 6px;
            background-color: var(--color-bg-secondary);
            color: var(--color-text-primary);
            transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
            appearance: none;
        }

        input:focus,
        select:focus,
        textarea:focus {
            border-color: var(--color-accent-blue);
            outline: none;
            box-shadow: 0 0 0 3px var(--color-focus-shadow);
        }

        .btn {
            padding: 10px 18px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            transition: background-color 0.2s, box-shadow 0.2s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin: 5px 5px 5px 0;
            white-space: nowrap;
        }

        .btn-primary {
            background-color: var(--color-accent-blue);
            color: white;
        }

        .btn-primary:hover {
            background-color: #0c4a96;
        }

        .btn-secondary {
            background-color: var(--color-bg-primary);
            color: var(--color-text-primary);
            border: 1px solid var(--color-border);
        }

        .btn-secondary:hover {
            background-color: #eff1f3;
        }

        .btn-danger {
            background-color: #d73a49;
            /* Red */
            color: white;
            padding: 6px 10px;
            /* Smaller for inline table action */
            font-size: 0.85em;
        }

        .btn-danger:hover {
            background-color: #c92c3a;
        }

        /* SKU Search/Autocomplete specific styles */
        .ui-autocomplete {
            max-height: 200px;
            overflow-y: auto;
            /* prevent horizontal scrollbar */
            overflow-x: hidden;
            z-index: 1000;
            /* Ensure it is above other elements */
            border: 1px solid var(--color-border);
            background-color: var(--color-bg-secondary);
            border-radius: 4px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .ui-menu-item {
            padding: 8px 12px;
            font-size: 0.95em;
            cursor: pointer;
            color: var(--color-text-primary);
        }

        .ui-menu-item:hover,
        .ui-state-focus {
            background-color: var(--color-accent-blue);
            color: white !important;
            border: none;
            /* Override jQuery UI default border */
        }

        /* Table Styling - Use existing global.css, but add specific tweaks */
        .data-table th:last-child,
        .data-table td:last-child {
            width: 120px;
            /* Give Action column a fixed width */
            text-align: center;
        }

        /* Toggle Buttons Container */
        .toggle-container {
            display: flex;
            justify-content: flex-end;
            margin-top: 20px;
        }
    </style>
</head>

<body>
    <?php require '../parts/nav.php'; ?>
    <div class="main">
        <div class="container">
            <h2 class="page-title">Manage Inbound Receipt: <?= htmlspecialchars($receipt_details['record_number'] ?? 'N/A') ?></h2>

            <div id="message_container">
                <?php if (!empty($message)) displayMessage($message_type ?? 'info', $message); ?>
            </div>

            <?php if ($receipt_details): ?>
                <div class="content-card">
                    <h3>Receipt Header Details</h3>
                    <div class="receipt-header-details">
                        <div class="detail-item"><strong>Status:</strong> <span class="status-badge status-<?= $receipt_details['status'] ?>"><?= ucfirst($receipt_details['status']) ?></span></div>
                        <div class="detail-item"><strong>Warehouse:</strong> <span><?= htmlspecialchars($receipt_details['wh_code']) ?></span></div>
                        <div class="detail-item"><strong>GRN Type:</strong> <span><?= htmlspecialchars($receipt_details['grn_type']) ?></span></div>
                        <div class="detail-item"><strong>Source Document No:</strong> <span><?= htmlspecialchars($receipt_details['receiving_number']) ?></span></div>
                        <div class="detail-item"><strong>Vehicle No:</strong> <span><?= htmlspecialchars($receipt_details['vehicle_number'] ?: 'N/A') ?></span></div>
                        <div class="detail-item"><strong>Receiving Date:</strong> <span><?= htmlspecialchars($receipt_details['receiving_date']) ?></span></div>
                        <div class="detail-item"><strong>GRN Date:</strong> <span><?= htmlspecialchars($receipt_details['grn_date'] ?: 'N/A') ?></span></div>
                    </div>
                    <div class="action-buttons-group" style="text-align: right; margin-top: 10px;">
                        <button id="confirmReceivingBtn" class="btn btn-primary" <?= ($receipt_details['status'] === 'confirmed') ? 'style="display:none;"' : '' ?>>
                            Confirm Receiving
                        </button>
                        <button id="printLpnBtn" class="btn btn-secondary">Print LPNs</button>
                        <button id="printGrnBtn" class="btn btn-secondary" style="display:none;" data-grn-number="<?= htmlspecialchars($receipt_details['grn_number'] ?? '') ?>">Print GRN</button>
                    </div>
                </div>
            <?php endif; ?>

            <div class="toggle-container">
                <button id="togglePutawayModeBtn" class="btn btn-secondary">Switch to Manual Putaway</button>
            </div>

            <div id="add_sku_form_container" class="content-card">
                <h3>Auto Putaway - Add SKU Item</h3>
                <form id="add_sku_form">
                    <input type="hidden" name="action" value="add_sku_item">

                    <div class="form-group-grid">
                        <div class="form-group">
                            <label for="sku_code">SKU Code (Search):</label>
                            <input type="text" id="sku_code" name="sku_code" placeholder="Start typing SKU code or name" required>
                        </div>
                        <div class="form-group">
                            <label for="full_amount_received">Quantity Received (Full Amount):</label>
                            <input type="number" id="full_amount_received" name="full_amount_received" min="1" required>
                        </div>
                        <div class="form-group">
                            <label for="batch_number">Batch/Lot No:</label>
                            <input type="text" id="batch_number" name="batch_number" required>
                        </div>
                        <div class="form-group">
                            <label for="mfd">Manufacturing Date (MFD):</label>
                            <input type="date" id="mfd" name="mfd" required>
                        </div>
                        <div class="form-group">
                            <label for="exd">Expiry Date (EXD):</label>
                            <input type="date" id="exd" name="exd" required>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary" style="margin-top: 15px;">Add SKU Item & Auto-Allocate</button>
                </form>
            </div>

            <div id="manual_putaway_form_container" class="content-card" style="display:none;">
                <h3>Manual Putaway - Add SKU Item</h3>
                <form id="manual_putaway_form">
                    <input type="hidden" name="action" value="manual_add_sku_item">

                    <div class="form-group-grid">
                        <div class="form-group">
                            <label for="manual_sku_code">SKU Code (Search):</label>
                            <input type="text" id="manual_sku_code" name="sku_code" placeholder="Scan or type SKU code" required>
                        </div>
                        <div class="form-group">
                            <label for="manual_location_code">Target Location Code:</label>
                            <input type="text" id="manual_location_code" name="location_code" placeholder="Scan or type location" required>
                        </div>
                        <div class="form-group">
                            <label for="manual_quantity">Quantity:</label>
                            <input type="number" id="manual_quantity" name="quantity" min="1" required>
                        </div>
                        <div class="form-group">
                            <label for="manual_batch_number">Batch/Lot No:</label>
                            <input type="text" id="manual_batch_number" name="batch_number" required>
                        </div>
                        <div class="form-group">
                            <label for="manual_mfd">Manufacturing Date (MFD):</label>
                            <input type="date" id="manual_mfd" name="mfd" required>
                        </div>
                        <div class="form-group">
                            <label for="manual_exd">Expiry Date (EXD):</label>
                            <input type="date" id="manual_exd" name="exd" required>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary" style="margin-top: 15px;">Add SKU Item & Manual Putaway</button>
                </form>
            </div>

            <div class="content-card">
                <h3>Receipt Items</h3>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>SKU Code</th>
                            <th>Description</th>
                            <th>Batch No</th>
                            <th>MFD</th>
                            <th>EXD</th>
                            <th>Location</th>
                            <th>Qty</th>
                            <th id="action_header">Action</th>
                        </tr>
                    </thead>
                    <tbody id="receiptItemsTableBody">
                        <?php if (!empty($receipt_items)): ?>
                            <?php foreach ($receipt_items as $item): ?>
                                <tr>
                                    <td><?= htmlspecialchars($item['sku_code']) ?></td>
                                    <td><?= htmlspecialchars($item['sku_description'] ?: 'N/A') ?></td>
                                    <td><?= htmlspecialchars($item['batch_number']) ?></td>
                                    <td><?= htmlspecialchars($item['mfd']) ?></td>
                                    <td><?= htmlspecialchars($item['exd']) ?></td>
                                    <td><?= htmlspecialchars($item['location_code']) ?></td>
                                    <td><?= (int)$item['quantity'] ?></td>
                                    <td>
                                        <button class="btn btn-danger delete-item-btn" data-item-id="<?= (int)$item['item_id'] ?>">
                                            Remove
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr id="no_items_row">
                                <td colspan="8" style="text-align: center;">No items added to this receipt yet.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>

    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

    <script>
        $(document).ready(function() {
            const receiptId = <?= (int)$receipt_id ?>;
            const isConfirmed = <?= ($receipt_details['status'] === 'confirmed') ? 'true' : 'false' ?>;

            function displayMessage(type, message) {
                const class_name = (type === 'success') ? 'alert-success' : 'alert-danger';
                const html = `<div class="message ${class_name}">${message}</div>`;
                $('#message_container').html(html).show().delay(5000).slideUp(300, function() {
                    $(this).empty().show(); // Clear and show the container again for the next message
                });
            }

            function reloadPage() {
                // Reloads the page after a short delay to fetch new item list and status
                setTimeout(() => window.location.reload(), 500);
            }

            // --- SKU & Location Autocomplete Logic ---

            function setupAutocomplete($skuInput) {
                $skuInput.autocomplete({
                    source: function(request, response) {
                        $.ajax({
                            url: 'fetch_skus_for_inbound.php',
                            dataType: 'json',
                            data: {
                                term: request.term,
                                compcode: '<?= htmlspecialchars($compcode) ?>'
                            },
                            success: function(data) {
                                response(data);
                            },
                            error: function(xhr, status, error) {
                                console.error("SKU Autocomplete Error:", status, error);
                            }
                        });
                    },
                    minLength: 2,
                    select: function(event, ui) {
                        $skuInput.val(ui.item.value); // Use the SKU code
                        return false;
                    }
                }).autocomplete("instance")._renderItem = function(ul, item) {
                    return $("<li>")
                        .append(`<div><strong>${item.value}</strong><br><small>${item.label}</small></div>`)
                        .appendTo(ul);
                };
            }
            setupAutocomplete($('#sku_code'));
            setupAutocomplete($('#manual_sku_code'));

            $('#manual_location_code').autocomplete({
                source: function(request, response) {
                    $.ajax({
                        url: 'fetch_all_locations.php',
                        dataType: 'json',
                        data: {
                            term: request.term,
                            wh_code: '<?= htmlspecialchars($wh_code_for_items ?? '') ?>',
                            compcode: '<?= htmlspecialchars($compcode) ?>'
                        },
                        success: function(data) {
                            response(data);
                        },
                        error: function(xhr, status, error) {
                            console.error("Location Autocomplete Error:", status, error);
                        }
                    });
                },
                minLength: 1,
            });

            // --- Putaway Mode Toggle Logic ---

            $('#togglePutawayModeBtn').on('click', function() {
                const isAutoModeVisible = $('#add_sku_form_container').is(':visible');
                if (isAutoModeVisible) {
                    $('#add_sku_form_container').slideUp(300);
                    $('#manual_putaway_form_container').slideDown(300);
                    $(this).text('Switch to Auto Putaway');
                } else {
                    $('#add_sku_form_container').slideDown(300);
                    $('#manual_putaway_form_container').slideUp(300);
                    $(this).text('Switch to Manual Putaway');
                }
            });


            // --- Form Submission Logic ---

            // Auto Putaway Form Submission
            $('#add_sku_form').on('submit', function(e) {
                e.preventDefault();
                $.ajax({
                    url: window.location.href,
                    type: 'POST',
                    data: $(this).serialize(),
                    dataType: 'json',
                    success: function(response) {
                        displayMessage(response.status, response.message);
                        if (response.status === 'success') {
                            $('#add_sku_form')[0].reset();
                            reloadPage();
                        }
                    },
                    error: function() {
                        displayMessage('error', 'An unexpected error occurred during item submission.');
                    }
                });
            });

            // Manual Putaway Form Submission
            $('#manual_putaway_form').on('submit', function(e) {
                e.preventDefault();
                $.ajax({
                    url: window.location.href,
                    type: 'POST',
                    data: $(this).serialize(),
                    dataType: 'json',
                    success: function(response) {
                        displayMessage(response.status, response.message);
                        if (response.status === 'success') {
                            $('#manual_putaway_form')[0].reset();
                            reloadPage();
                        }
                    },
                    error: function() {
                        displayMessage('error', 'An unexpected error occurred during item submission.');
                    }
                });
            });


            // --- Delete Item Logic ---

            $(document).on('click', '.delete-item-btn', function() {
                const item_id = $(this).data('item-id');
                if (confirm('Are you sure you want to remove this item? This action cannot be undone.')) {
                    $.ajax({
                        url: window.location.href,
                        type: 'POST',
                        data: {
                            action: 'delete_item',
                            item_id: item_id
                        },
                        dataType: 'json',
                        success: function(response) {
                            displayMessage(response.status, response.message);
                            if (response.status === 'success') {
                                reloadPage();
                            }
                        },
                        error: function() {
                            displayMessage('error', 'An unexpected error occurred during deletion.');
                        }
                    });
                }
            });

            // --- Confirm Receiving Logic ---

            $('#confirmReceivingBtn').on('click', function() {
                if ($('#receiptItemsTableBody tr').length === 0 || $('#receiptItemsTableBody tr#no_items_row').length > 0) {
                    displayMessage('error', 'Cannot confirm receiving. No items have been added to this receipt.');
                    return;
                }
                if (confirm('WARNING: Confirming receiving will finalize all allocations, generate a GRN number, and update inventory. This action cannot be reversed. Proceed?')) {
                    $.ajax({
                        url: window.location.href,
                        type: 'POST',
                        data: {
                            action: 'confirm_receiving'
                        },
                        dataType: 'json',
                        success: function(response) {
                            displayMessage(response.status, response.message);
                            if (response.status === 'success') {
                                $('#confirmReceivingBtn').hide();
                                $('#printGrnBtn').show().data('grn-number', response.grn_number);
                                $('#add_sku_form_container, #manual_putaway_form_container, .toggle-container').hide();
                                $('.delete-item-btn').prop('disabled', true).hide();
                                reloadPage();
                            }
                        },
                        error: function() {
                            displayMessage('error', 'An unexpected error occurred during confirmation.');
                        }
                    });
                }
            });

            // --- Print LPNs Button ---

            $('#printLpnBtn').on('click', function() {
                if ($('#receiptItemsTableBody tr').length === 0 || $('#receiptItemsTableBody tr#no_items_row').length > 0) {
                    displayMessage('error', 'No items to print LPNs for.');
                    return;
                }
                window.open('print_lpn.php?receipt_id=' + receiptId, '_blank');
            });

            // --- Print GRN Button ---

            $('#printGrnBtn').on('click', function() {
                const grnNumber = $(this).data('grn-number');
                window.open('print_grn.php?receipt_id=' + receiptId + '&grn_number=' + grnNumber, '_blank');
            });

            // --- Initial State Adjustments ---
            if (isConfirmed) {
                $('#add_sku_form_container, #manual_putaway_form_container, .toggle-container').hide();
                $('#confirmReceivingBtn').hide();
                $('#printGrnBtn').show();

                const $actionHeader = $('#action_header');
                if ($actionHeader.length) {
                    const columnIndex = $actionHeader.index();
                    $actionHeader.remove();
                    $('#receiptItemsTableBody tr').each(function() {
                        $(this).find('td').eq(columnIndex).remove();
                    });
                }
            }
        });
    </script>
</body>

</html>