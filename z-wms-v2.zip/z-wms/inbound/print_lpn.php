<?php
session_start();
require '../inc/db.php';

if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    die("Unauthorized access.");
}

$compcode = $_SESSION['compcode'];
$receipt_id = isset($_GET['receipt_id']) ? (int)$_GET['receipt_id'] : 0;

if ($receipt_id <= 0) {
    die("Invalid Receipt ID.");
}

// Fetch header details to get the confirmed GRN number if available
$header_sql = "SELECT record_number, grn_number, status FROM inbound_receipts WHERE id = ? AND compcode = ? AND sku_code IS NULL";
$header_stmt = $conn->prepare($header_sql);
$header_details = null;
if ($header_stmt) {
    $header_stmt->bind_param("is", $receipt_id, $compcode);
    $header_stmt->execute();
    $header_result = $header_stmt->get_result();
    if ($header_result->num_rows > 0) {
        $header_details = $header_result->fetch_assoc();
    }
    $header_stmt->close();
}

if (!$header_details) {
    die("Receipt header not found or unauthorized.");
}

$record_number_for_lpn = $header_details['record_number'];
$display_grn_number = $header_details['grn_number'] ?? $record_number_for_lpn; // Use GRN if confirmed, else record_number

// Fetch items for LPN generation
$items_sql = "SELECT sku_code, batch_number, exd, location_code, quantity FROM inbound_receipts 
              WHERE record_number = ? AND compcode = ? AND sku_code IS NOT NULL AND quantity > 0";
$items_stmt = $conn->prepare($items_sql);
$receipt_items = [];
if ($items_stmt) {
    $items_stmt->bind_param("ss", $record_number_for_lpn, $compcode);
    $items_stmt->execute();
    $items_result = $items_stmt->get_result();

    $count = mysqli_num_rows($items_result);
    while ($row = $items_result->fetch_assoc()) {
        $receipt_items[] = $row;
    }
    $items_stmt->close();
} else {
    die("Error fetching receipt items: " . htmlspecialchars($conn->error));
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="stylesheet" href="../inc/global.css"> -->
    <title>Print LPNs</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        @page {
            size: 4in 2in;
            /* Width x Height */
            margin: 0;
        }

        body {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            background-color:rgb(49, 49, 49);
            /* For screen view */
            font-family: 'Inter', sans-serif;
        }

        .lpn-container {
            width: 4in;
            height: 2in;
            border: 1px solid #333;
            box-sizing: border-box;
            padding: 5px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            page-break-after: always;
            /* Ensure each label prints on a new "page" */
            background-color: #fff;
            margin-bottom: 5px;
            /* Spacing between labels in screen view */
        }

        .lpn-header,
        .lpn-body,
        .lpn-footer {
            width: 100%;
        }

        .lpn-header {
            text-align: center;
            font-size: 10px;
            font-weight: bold;
            margin-bottom: 2px;
        }

        .lpn-body {
            display: grid;
            grid-template-columns: 1fr 1fr;
            /* Two columns for details */
            gap: 2px 5px;
            font-size: 14px;
            line-height: 1.2;
            flex-grow: 1;
            /* Allow content to grow */
            align-items: center;
            /* Vertically align content */
        }

        .lpn-body div {
            border: solid 1px #000;
            padding: 2px 2px;
        }

        .lpn-body div strong {
            display: inline-block;
            width: 50px;
            /* Adjust for label alignment */
        }

        .lpn-footer {
            text-align: center;
            font-size: 8px;
            margin-top: 2px;
            color: #666;
        }

        .location-code {
            font-size: 35px;
            /* Big font */
            font-weight: bold;
            color: #000;
            text-align: center;
            grid-column: span 2;
            /* Span across both columns */
            margin-top: 5px;
            margin-bottom: 5px;
            line-height: 1;
            /* Reduce line height for large text */
        }

        .text-center {
            text-align: center;
        }

        .text-right {
            text-align: right;
        }

        @media print {
            body {
                background-color: #fff;
            }

            .lpn-container {
                border: 1px solid #000;
                /* Ensure black border on print */
                margin-bottom: 0;
            }

            .no-print {
                display: none;
            }
        }

        .no-print {
            position: fixed;
            bottom: 20px;
            right: 20px;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            z-index: 1000;
        }

        .no-print:hover {
            background-color: #45a049;
        }
    </style>
</head>

<body>

    <?php if (!empty($receipt_items)): ?>
        <?php foreach ($receipt_items as $item): ?>
            <div class="lpn-container">
                <div class="lpn-header">
                    LPN - <?= htmlspecialchars($display_grn_number) ?>
                </div>
                <div class="lpn-body">
                    <div><strong>SKU:</strong> <?= htmlspecialchars($item['sku_code']) ?></div>
                    <div><strong>Batch:</strong> <?= htmlspecialchars($item['batch_number']) ?></div>
                    <div><strong>EXD:</strong> <?= htmlspecialchars($item['exd']) ?></div>
                    <div><strong>QTY:</strong> <?= htmlspecialchars($item['quantity']) ?></div>
                    <div class="location-code"><?= htmlspecialchars($item['location_code']) ?></div>
                </div>
                <div class="lpn-footer">
                    Print Date: <?= date('Y-m-d H:i') ?>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p style="text-align: center; margin-top: 50px;">No items found to generate LPNs.</p>
    <?php endif; ?>

    <button class="no-print" onclick="window.print()">Print All LPNs</button>

</body>

</html>