<?php
session_start();
require '../inc/db.php';

header('Content-Type: application/json');

$wh_code = $_SESSION['wh_code']; // Get warehouse code from session

// PHP expects the search term in 'location_code'
$location_code_search = isset($_GET['location_code']) ? trim($_GET['location_code']) : (isset($_GET['q']) ? trim($_GET['q']) : '');

if (empty($location_code_search)) {
    echo json_encode(['status' => 'error', 'message' => 'Location code search term is required.']);
    exit();
}
// ... query uses $location_code_search ...


if (empty($location_code_search)) {
    echo json_encode(['status' => 'error', 'message' => 'Location code search term is required.']);
    exit();
}

// FIX: Filtered by wh_code to ensure warehouse-specific locations are fetched.
$sql = "SELECT location_code, status 
        FROM warehouse_locations 
        WHERE wh_code = ? AND location_code LIKE ? 
        ORDER BY location_code ASC LIMIT 20";

$stmt = $conn->prepare($sql);
if ($stmt) {
    $search_param = '%' . $location_code_search . '%';
    // Bind wh_code and search term
    $stmt->bind_param("ss", $wh_code, $search_param);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    $stmt->close();
    echo json_encode(['status' => 'success', 'data' => $data]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $conn->error]);
}
