<?php
session_start();
require '../inc/db.php';

if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    header("Location: ../");
    exit();
}

$compcode = $_SESSION['compcode'];
$receipt_id = isset($_GET['receipt_id']) ? (int)$_GET['receipt_id'] : 0;
$grn_number_param = isset($_GET['grn_number']) ? $_GET['grn_number'] : ''; // Passed after confirmation

if ($receipt_id <= 0 || empty($grn_number_param)) {
    die("Invalid request: Missing Receipt ID or GRN Number.");
}

// Fetch Receipt Header Details (including wh_code)
$header_sql = "SELECT id, record_number, grn_number, grn_type, receiving_number, vehicle_number, receiving_date, grn_date, status, created_at, wh_code
               FROM inbound_receipts
               WHERE id = ? AND compcode = ? AND sku_code IS NULL";
$header_stmt = $conn->prepare($header_sql);
$receipt_details = null;
if ($header_stmt) {
    $header_stmt->bind_param("is", $receipt_id, $compcode);
    $header_stmt->execute();
    $header_result = $header_stmt->get_result();
    if ($header_result->num_rows > 0) {
        $receipt_details = $header_result->fetch_assoc();
    }
    $header_stmt->close();
} else {
    die("Database error fetching receipt header: " . htmlspecialchars($conn->error));
}

if (!$receipt_details) {
    die("GRN not found, not confirmed, or unauthorized access.");
}

// === CORRECTED LOGIC: Fetch Warehouse Details (Removed 'AND compcode = ?') ===
$wh_code = $receipt_details['wh_code'];
$warehouse_details = null;
if (!empty($wh_code)) {
    // Corrected SQL: Removed `AND compcode = ?`
    $wh_sql = "SELECT wh_name, wh_address1, wh_address2 FROM warehouse_master WHERE wh_code = ?";
    $wh_stmt = $conn->prepare($wh_sql);
    if ($wh_stmt) {
        // Corrected bind_param: Only binds $wh_code
        $wh_stmt->bind_param("s", $wh_code);
        $wh_stmt->execute();
        $wh_result = $wh_stmt->get_result();
        $warehouse_details = $wh_result->fetch_assoc();
        $wh_stmt->close();
    }
}
// ============================================================================


// Fetch confirmed items for this GRN
$items_sql = "SELECT ir.sku_code, sm.sku_description, ir.batch_number, ir.mfd, ir.exd, SUM(ir.quantity) AS quantity 
              FROM inbound_receipts ir
              JOIN sku_master sm ON ir.sku_code = sm.sku_code AND ir.compcode = sm.compcode
              WHERE ir.grn_number = ? AND ir.compcode = ? AND ir.sku_code IS NOT NULL AND ir.status = 'confirmed'
              GROUP BY ir.sku_code, sm.sku_description, ir.batch_number, ir.mfd, ir.exd
              ORDER BY ir.sku_code ASC, ir.batch_number ASC, ir.exd ASC";

$items_stmt = $conn->prepare($items_sql);
$receipt_items = [];
$total_received_qty = 0;
if ($items_stmt) {
    $items_stmt->bind_param("ss", $grn_number_param, $compcode);
    $items_stmt->execute();
    $items_result = $items_stmt->get_result();
    while ($row = $items_result->fetch_assoc()) {
        $receipt_items[] = $row;
        $total_received_qty += $row['quantity'];
    }
    $items_stmt->close();
} else {
    die("Error fetching receipt items for GRN: " . htmlspecialchars($conn->error));
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Goods Receiving Note (GRN) - <?= htmlspecialchars($receipt_details['grn_number']) ?></title>
    <style>
        /* Import Inter font - Required to fulfill user request while using internal CSS */
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');

        /* Print-specific settings */
        @page {
            size: A4;
            margin: 10mm;
        }

        body {
            font-family: 'Inter', Arial, sans-serif;
            font-size: 8pt;
            margin: 0;
            padding: 0;
            background-color: #fff;
        }

        .container {
            width: 190mm;
            margin: 0 auto;
            padding: 5mm;
        }

        /* 1. Warehouse Header (New Block) */
        .warehouse-header {
            text-align: center;
            padding-bottom: 10px;
            margin-bottom: 20px;
            border-bottom: 1px solid #ccc;
        }

        .warehouse-header .wh-name {
            font-size: 14pt;
            font-weight: 700;
            margin-bottom: 2px;
        }

        .warehouse-header .wh-address,
        .warehouse-header .wh-comp {
            font-size: 9pt;
            color: #555;
        }


        /* 2. Document Header */
        .document-header {
            text-align: center;
            border-bottom: 3px solid #000;
            padding-bottom: 5px;
            margin-bottom: 20px;
        }

        .document-header h1 {
            font-size: 18pt;
            margin: 0;
        }

        .document-header h2 {
            font-size: 11pt;
            margin: 5px 0 0 0;
            font-weight: 400;
            color: #333;
        }

        /* 3. Info Blocks (Professional Grid Style) */
        .info-grid {
            border: 1px solid #ddd;
            width: 100%;
            margin-bottom: 20px;
            box-sizing: border-box;
            display: table;
            /* Use table display for reliable print layout */
        }

        .info-row {
            display: table-row;
        }

        .info-label,
        .info-value {
            display: table-cell;
            padding: 8px 12px;
            vertical-align: top;
            border-bottom: 1px solid #eee;
        }

        .info-label {
            width: 20%;
            /* Adjust width for labels */
            font-weight: 600;
            background-color: #f9f9f9;
            border-right: 1px solid #ddd;
        }

        .info-value {
            width: 30%;
            border-right: 1px solid #ddd;
        }

        /* Remove borders for print neatness */
        .info-row:last-child .info-label,
        .info-row:last-child .info-value {
            border-bottom: none;
        }

        .info-row .info-value:nth-child(4) {
            border-right: none;
        }

        /* 4. Item Table Styles */
        .item-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 40px;
        }

        .item-table th,
        .item-table td {
            border: 1px solid #000;
            padding: 8px 10px;
            text-align: left;
        }

        .item-table th {
            background-color: #e6e6e6;
            font-weight: 600;
        }

        .item-table tfoot td {
            background-color: #f0f0f0;
            font-size: 11pt;
            font-weight: 700;
            border-top: 2px solid #000;
        }

        .text-right {
            text-align: right;
        }

        .text-center {
            text-align: center;
        }

        /* 5. Signature Block */
        .signature-block {
            width: 100%;
            margin-top: 50px;
            display: flex;
            justify-content: space-around;
            text-align: center;
        }

        .signature-block div {
            width: 90%;
            margin: 1vh;
        }

        .signature-line {
            border-top: 1px solid #000;
            height: 1px;
            width: 100%;
            margin: 50px 0 5px 0;
        }

        .signature-text {
            font-size: 9pt;
            margin: 0;
            /* font-weight: 600; */
        }

        /* 6. Footer (Fixed for printing) */
        .document-footer {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            width: 100%;
            text-align: center;
            font-size: 8pt;
            color: #555;
            padding: 5px 0;
            border-top: 1px solid #ddd;
            background-color: #fff;
        }

        /* 7. Non-Printable Elements */
        .no-print {
            position: fixed;
            bottom: 20px;
            right: 20px;
            padding: 10px 20px;
            background-color: #0969da;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            z-index: 999;
        }

        @media print {
            .no-print {
                display: none;
            }
        }
    </style>
</head>

<body>
    <div class="container">

        <div class="warehouse-header">
            <div class="wh-name"><?= htmlspecialchars($warehouse_details['wh_name'] ?? 'Warehouse Name Not Found') ?></div>
            <div class="wh-address">
                <?= htmlspecialchars($warehouse_details['wh_address1'] ?? 'Address Line 1 Not Found') ?>
                <?= !empty($warehouse_details['wh_address2']) ? ', ' . htmlspecialchars($warehouse_details['wh_address2']) : '' ?>
            </div>
            <div class="wh-comp">Company Code: <?= htmlspecialchars($compcode) ?> | Warehouse Code: <?= htmlspecialchars($wh_code) ?></div>
        </div>

        <div class="document-header">
            <h1>Goods Receiving Note (GRN)</h1>
            <h2>GRN Status: <?= strtoupper(htmlspecialchars($receipt_details['status'])) ?> | Warehouse: <?= htmlspecialchars($receipt_details['wh_code']) ?></h2>
        </div>

        <div class="info-grid">
            <div class="info-row">
                <div class="info-label">GRN No:</div>
                <div class="info-value"><strong><?= htmlspecialchars($receipt_details['grn_number']) ?></strong></div>
                <div class="info-label">GRN Date:</div>
                <div class="info-value"><?= htmlspecialchars($receipt_details['grn_date']) ?></div>
            </div>
            <div class="info-row">
                <div class="info-label">Receiving No:</div>
                <div class="info-value"><?= htmlspecialchars($receipt_details['receiving_number']) ?></div>
                <div class="info-label">Receiving Date:</div>
                <div class="info-value"><?= htmlspecialchars($receipt_details['receiving_date']) ?></div>
            </div>
            <div class="info-row">
                <div class="info-label">GRN Type:</div>
                <div class="info-value"><?= htmlspecialchars($receipt_details['grn_type']) ?></div>
                <div class="info-label">Vehicle No:</div>
                <div class="info-value"><?= htmlspecialchars($receipt_details['vehicle_number']) ?></div>
            </div>
            <div class="info-row">
                <div class="info-label">Unloading Start:</div>
                <div class="info-value"></div>
                <div class="info-label">Unloading End</div>
                <div class="info-value"></div>
            </div>
        </div>

        <table class="item-table">
            <thead>
                <tr>
                    <th style="width: 15%;">SKU Code</th>
                    <th>Description</th>
                    <th style="width: 15%;">Batch/LOT No</th>
                    <th style="width: 15%;">MFD</th>
                    <th style="width: 15%;">EXD</th>
                    <th style="width: 15%;" class="text-right">Qty Received</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($receipt_items)): ?>
                    <?php foreach ($receipt_items as $item): ?>
                        <tr>
                            <td><?= htmlspecialchars($item['sku_code']) ?></td>
                            <td><?= htmlspecialchars($item['sku_description']) ?></td>
                            <td><?= htmlspecialchars($item['batch_number']) ?></td>
                            <td><?= htmlspecialchars($item['mfd']) ?></td>
                            <td><?= htmlspecialchars($item['exd']) ?></td>
                            <td class="text-right"><?= (int)$item['quantity'] ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="text-center">No items found for this GRN.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="5" class="text-right"><strong>Total Quantity Received:</strong></td>
                    <td class="text-right"><strong><?= (int)$total_received_qty ?></strong></td>
                </tr>
            </tfoot>
        </table>

        <div class="signature-block">
            <div>
                <div class="signature-line"></div>
                <p class="signature-text">Prepared By: (<i><?= htmlspecialchars($_SESSION['username']) ?></i>)</p>
            </div>
            <div>
                <div class="signature-line"></div>
                <p class="signature-text">Putaway By (Warehouse)</p>
            </div>
            <div>
                <div class="signature-line"></div>
                <p class="signature-text">Approved By</p>
            </div>
        </div>
    </div>

    <div class="document-footer">
        Document generated by Zynex WMS. Designed and developed by Zynex Solutions 2019-2025.
    </div>

    <button class="no-print" onclick="window.print()">Print GRN</button>
</body>

</html>