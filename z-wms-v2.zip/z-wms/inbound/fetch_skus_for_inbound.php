<?php
session_start();
require '../inc/db.php';

header('Content-Type: application/json');

$compcode = $_SESSION['compcode'];
// PHP expects the search term in 'sku_code'
$sku_code_search = isset($_GET['sku_code']) ? trim($_GET['sku_code']) : (isset($_GET['q']) ? trim($_GET['q']) : '');

if (empty($sku_code_search)) {
    echo json_encode(['status' => 'error', 'message' => 'SKU code search term is required.']);
    exit();
}
// ... query uses $sku_code_search ...

// SQL is correct: Filters by compcode and the search term.
$sql = "SELECT sku_code, sku_description, epp 
        FROM sku_master 
        WHERE compcode = ? AND sku_code LIKE ? 
        ORDER BY sku_code ASC LIMIT 10";

$stmt = $conn->prepare($sql);
if ($stmt) {
    $search_param = '%' . $sku_code_search . '%';
    $stmt->bind_param("ss", $compcode, $search_param);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    $stmt->close();
    echo json_encode(['status' => 'success', 'data' => $data]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $conn->error]);
}
