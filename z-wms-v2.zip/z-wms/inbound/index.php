<?php
session_start();
require '../inc/db.php'; // Adjust path if necessary

if (empty($_SESSION['username']) || empty($_SESSION['compcode']) || empty($_SESSION['wh_code'])) {
    // Ensure all necessary session variables are set before proceeding
    header("Location: ../");
    exit();
}

$compcode = $_SESSION['compcode'];
$wh_code = $_SESSION['wh_code']; // Get warehouse code from session
$message = '';

// Handle Create New Receipt Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_receipt'])) {
    $receiving_type = trim($_POST['receiving_type']);
    $receiving_number = trim($_POST['receiving_number']); // Manual input
    $vehicle_details = trim($_POST['vehicle_details']); // Optional
    $receiving_date = trim($_POST['receiving_date']);
    $grn_date = trim($_POST['grn_date']);

    // Update validation to include the new date fields
    if (empty($receiving_type) || empty($receiving_number) || empty($receiving_date) || empty($grn_date)) {
        $message = '<div class="message alert-danger">Receiving Type, Source Document No, Receive Date, and GRN Date are required.</div>';
    } else {

        $is_duplicate = false;
        try {
            // --- NEW: Check for duplicate receiving_number ---
            // We check if this receiving_number already exists for this compcode as a header record.
            $check_sql = "SELECT id FROM inbound_receipts WHERE receiving_number = ? AND compcode = ? AND sku_code IS NULL";
            $check_stmt = $conn->prepare($check_sql);
            if (!$check_stmt) {
                throw new Exception("Error preparing duplicate check: " . $conn->error);
            }
            $check_stmt->bind_param("ss", $receiving_number, $compcode);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            if ($check_result->num_rows > 0) {
                $is_duplicate = true;
                $message = '<div class="message alert-danger">Duplicate Entry: A receipt with Source Document No "' . htmlspecialchars($receiving_number) . '" already exists in the system.</div>';
            }
            $check_stmt->close();
            // --- END DUPLICATE CHECK ---

            if (!$is_duplicate) {
                $conn->begin_transaction();

                // Auto-generate Record Number (e.g., COMPCODE-IN-YYYYMMDD-00001)
                $record_prefix = $compcode . '-IN-' . date('Ymd') . '-';

                // Find the highest existing record number for today for this compcode
                $max_record_sql = "SELECT record_number FROM inbound_receipts
                                   WHERE compcode = ? AND record_number LIKE ?
                                   ORDER BY record_number DESC LIMIT 1";
                $max_record_stmt = $conn->prepare($max_record_sql);
                if (!$max_record_stmt) {
                    throw new Exception("Error preparing max record query: " . $conn->error);
                }
                $record_like_param = $record_prefix . '_____';
                $max_record_stmt->bind_param("ss", $compcode, $record_like_param);
                $max_record_stmt->execute();
                $max_record_result = $max_record_stmt->get_result();
                $last_record_number = '';
                if ($row = $max_record_result->fetch_assoc()) {
                    $last_record_number = $row['record_number'];
                }
                $max_record_stmt->close();

                $next_sequence = 1;
                if (!empty($last_record_number)) {
                    if (preg_match('/-(\d{5})$/', $last_record_number, $matches)) {
                        $next_sequence = (int)$matches[1] + 1;
                    }
                }
                $final_record_number = $record_prefix . sprintf('%05d', $next_sequence);


                // Insert the header record for the new receipt
                $insert_sql = "INSERT INTO inbound_receipts (compcode, wh_code, record_number, grn_type, receiving_number, vehicle_number, receiving_date, grn_date, created_by, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'draft', NOW())";
                $insert_stmt = $conn->prepare($insert_sql);
                if (!$insert_stmt) {
                    throw new Exception("Error preparing statement: " . $conn->error);
                }
                $insert_stmt->bind_param("sssssssss", $compcode, $wh_code, $final_record_number, $receiving_type, $receiving_number, $vehicle_details, $receiving_date, $grn_date, $_SESSION['username']);

                if (!$insert_stmt->execute()) {
                    throw new Exception("Error creating inbound receipt header: " . $insert_stmt->error);
                }

                $new_receipt_id = $conn->insert_id;
                $insert_stmt->close();
                $conn->commit();

                // Redirect to the details page of the newly created receipt
                header("Location: receipt_details.php?receipt_id=" . $new_receipt_id);
                exit();
            }
        } catch (Exception $e) {
            if ($conn->errno) { // Check if a transaction was started
                $conn->rollback();
            }
            $message = '<div class="message alert-danger">Error creating receipt: ' . htmlspecialchars($e->getMessage()) . '</div>';
        }
    }
}

// Fetch all DRAFT receipt headers (sku_code IS NULL means it's a header record)
$draft_receipts = [];
$draft_sql = "SELECT id, record_number, grn_type, receiving_number, receiving_date, vehicle_number, wh_code
              FROM inbound_receipts
              WHERE compcode = ? AND wh_code = ? AND status = 'draft' AND sku_code IS NULL
              ORDER BY created_at DESC";

$draft_stmt = $conn->prepare($draft_sql);
if ($draft_stmt) {
    // Filter drafts by both company code and the active session warehouse code
    $draft_stmt->bind_param("ss", $compcode, $wh_code);
    $draft_stmt->execute();
    $draft_result = $draft_stmt->get_result();
    while ($row = $draft_result->fetch_assoc()) {
        $draft_receipts[] = $row;
    }
    $draft_stmt->close();
} else {
    $message .= '<div class="message alert-danger">Database error fetching drafts: ' . htmlspecialchars($conn->error) . '</div>';
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zynex WMS | Inbound Receipts</title>
    <link rel="stylesheet" href="../inc/global.css">
    <style>
        .main {
            width: 85%;
            overflow: visible;
        }

        /* Responsive Grid for Create Receipt Form */
        .receipt-form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px 20px;
        }

        .action-link {
            text-decoration: none;
            font-weight: 600;
        }

        /* Style for the new Edit link */
        .action-link-edit {
            color: #f0ad4e;
            /* A warning/edit color */
            text-decoration: none;
            font-weight: 600;
            margin-right: 15px;
        }

        .action-link-manage {
            color: var(--color-accent-blue);
        }

        /* Mobile Table Styles (Card View) */
        @media (max-width: 768px) {
            .data-table {
                border: none;
                margin-top: 0;
            }

            .data-table thead {
                display: none;
            }

            .data-table tbody tr {
                display: block;
                margin-bottom: 15px;
                padding: 10px;
                border: 1px solid var(--color-border);
                border-radius: 6px;
                background-color: var(--color-bg-secondary);
            }

            .data-table th,
            .data-table td {
                display: block;
                text-align: right;
                padding: 5px 10px;
                border-bottom: none !important;
                border-right: none;
            }

            .data-table td::before {
                content: attr(data-label);
                font-weight: 600;
                color: var(--color-text-secondary);
                float: left;
                padding-right: 10px;
            }

            .data-table tbody tr:nth-child(even),
            .data-table tbody tr:nth-child(odd) {
                background-color: var(--color-bg-secondary);
            }
        }
    </style>
</head>

<body>
    <?php require '../parts/nav.php'; ?>

    <div id="main" class="main">
        <div class="module-container">
            <h2>Inbound Receipts - Warehouse: <?= htmlspecialchars($wh_code) ?></h2>

            <?php echo $message; // Display messages 
            ?>

            <div class="card">
                <h3>Create New Receipt</h3>
                <form action="" method="POST" class="receipt-form">
                    <div class="input-group">
                        <label for="receiving_type">Receiving Type *</label>
                        <select id="receiving_type" name="receiving_type" required>
                            <option value="">-- Select Type --</option>
                            <option value="PO">Purchase Order</option>
                            <option value="TRF">Transfer In</option>
                            <option value="RET">Customer Return</option>
                        </select>
                    </div>
                    <div class="input-group">
                        <label for="receiving_number">Source Document No *</label>
                        <input type="text" id="receiving_number" name="receiving_number" placeholder="PO/Transfer/Return Ref" required>
                    </div>
                    <div class="input-group">
                        <label for="receiving_date">Receive Date:</label>
                        <input type="date" id="receiving_date" name="receiving_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                    </div>

                    <div class="input-group">
                        <label for="grn_date">GRN Date:</label>
                        <input type="date" id="grn_date" name="grn_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                    </div>

                    <div class="input-group">
                        <label for="vehicle_details">Vehicle Number (Optional):</label>
                        <input type="text" id="vehicle_details" name="vehicle_details" class="form-control">
                    </div>

                    <div class="input-group" style="grid-column: 1 / -1; text-align: right;">
                        <button type="submit" name="create_receipt" class="action-button">Create New Receipt</button>
                    </div>
                </form>
            </div>

            <div class="card">
                <h3>Draft Inbound Receipts</h3>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Record Number</th>
                            <th>Type</th>
                            <th>Source Doc No</th>
                            <th>Warehouse</th>
                            <th>Date</th>
                            <th>Vehicle</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($draft_receipts)): ?>
                            <?php foreach ($draft_receipts as $receipt): ?>
                                <tr>
                                    <td data-label="Record Number"><?= htmlspecialchars($receipt['record_number']) ?></td>
                                    <td data-label="Type"><?= htmlspecialchars($receipt['grn_type']) ?></td>
                                    <td data-label="Source Doc No"><?= htmlspecialchars($receipt['receiving_number']) ?></td>
                                    <td data-label="Warehouse"><?= htmlspecialchars($receipt['wh_code']) ?></td>
                                    <td data-label="Date"><?= htmlspecialchars($receipt['receiving_date']) ?></td>
                                    <td data-label="Vehicle"><?= htmlspecialchars($receipt['vehicle_number'] ?: 'N/A') ?></td>

                                    <td data-label="Action">
                                        <a href="edit_receipt.php?receipt_id=<?= (int)$receipt['id'] ?>" class="action-link action-link-edit">Edit</a>
                                        <a href="receipt_details.php?receipt_id=<?= (int)$receipt['id'] ?>" class="action-link action-link-manage">Manage Items</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7">No draft inbound records found for **<?= htmlspecialchars($wh_code) ?>**.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>

</html>