<?php
session_start();
require '../inc/db.php'; // Adjust path if necessary

if (empty($_SESSION['username']) || empty($_SESSION['compcode']) || empty($_SESSION['wh_code'])) {
    header("Location: ../");
    exit();
}

$compcode = $_SESSION['compcode'];
$wh_code = $_SESSION['wh_code'];
$message = '';
$receipt_id = isset($_GET['receipt_id']) ? (int)$_GET['receipt_id'] : 0;
$receipt_data = null;

if ($receipt_id <= 0) {
    header("Location: index.php");
    exit();
}

// Handle Update Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_receipt'])) {
    $receiving_type = trim($_POST['receiving_type']);
    $receiving_number = trim($_POST['receiving_number']);
    $vehicle_details = trim($_POST['vehicle_details']);
    $receiving_date = trim($_POST['receiving_date']);
    $grn_date = trim($_POST['grn_date']);

    if (empty($receiving_type) || empty($receiving_number) || empty($receiving_date) || empty($grn_date)) {
        $message = '<div class="message alert-danger">All fields marked with * are required.</div>';
    } else {
        $is_duplicate = false;
        try {
            // Check for duplicates, *excluding* the current receipt ID
            $check_sql = "SELECT id FROM inbound_receipts WHERE receiving_number = ? AND compcode = ? AND sku_code IS NULL AND id != ?";
            $check_stmt = $conn->prepare($check_sql);
            if (!$check_stmt) {
                throw new Exception("Error preparing duplicate check: " . $conn->error);
            }
            $check_stmt->bind_param("ssi", $receiving_number, $compcode, $receipt_id);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            if ($check_result->num_rows > 0) {
                $is_duplicate = true;
                $message = '<div class="message alert-danger">Duplicate Entry: Another receipt with Source Document No "' . htmlspecialchars($receiving_number) . '" already exists.</div>';
            }
            $check_stmt->close();

            if (!$is_duplicate) {
                // Update the draft header record
                $update_sql = "UPDATE inbound_receipts 
                               SET grn_type = ?, receiving_number = ?, vehicle_number = ?, receiving_date = ?, grn_date = ?
                               WHERE id = ? AND compcode = ? AND status = 'draft' AND sku_code IS NULL";

                $update_stmt = $conn->prepare($update_sql);
                if (!$update_stmt) {
                    throw new Exception("Error preparing update: " . $conn->error);
                }

                $update_stmt->bind_param("sssssis", $receiving_type, $receiving_number, $vehicle_details, $receiving_date, $grn_date, $receipt_id, $compcode);

                if ($update_stmt->execute()) {
                    // Success, redirect back to index
                    header("Location: index.php?message=updated");
                    exit();
                } else {
                    throw new Exception("Error updating receipt header: " . $update_stmt->error);
                }
            }
        } catch (Exception $e) {
            $message = '<div class="message alert-danger">Error updating receipt: ' . htmlspecialchars($e->getMessage()) . '</div>';
        }
    }
}

// Fetch existing data for the form
if (!$receipt_data) {
    $fetch_sql = "SELECT record_number, grn_type, receiving_number, vehicle_number, receiving_date, grn_date 
                  FROM inbound_receipts 
                  WHERE id = ? AND compcode = ? AND status = 'draft' AND sku_code IS NULL";
    $fetch_stmt = $conn->prepare($fetch_sql);
    if ($fetch_stmt) {
        $fetch_stmt->bind_param("is", $receipt_id, $compcode);
        $fetch_stmt->execute();
        $fetch_result = $fetch_stmt->get_result();
        if ($fetch_result->num_rows > 0) {
            $receipt_data = $fetch_result->fetch_assoc();
        } else {
            // Receipt not found, not a draft, or doesn't belong to user
            header("Location: index.php?message=notfound");
            exit();
        }
        $fetch_stmt->close();
    } else {
        $message = '<div class="message alert-danger">Database error fetching receipt data: ' . htmlspecialchars($conn->error) . '</div>';
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zynex WMS | Edit Inbound Receipt</title>
    <link rel="stylesheet" href="../inc/global.css">
    <style>
        .receipt-form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px 20px;
        }

        .form-actions {
            grid-column: 1 / -1;
            text-align: right;
            display: flex;
            gap: 10px;
            justify-content: flex-end;
        }
    </style>
</head>

<body>
    <?php require '../parts/nav.php'; ?>

    <div id="main" class="main">
        <div class="module-container">
            <h2>Edit Inbound Receipt: <?= htmlspecialchars($receipt_data['record_number'] ?? 'N/A') ?></h2>

            <?php echo $message; // Display messages 
            ?>

            <div class="card">
                <h3>Edit Receipt Header</h3>
                <?php if ($receipt_data): ?>
                    <form action="" method="POST" class="receipt-form">
                        <div class="input-group">
                            <label for="receiving_type">Receiving Type *</label>
                            <select id="receiving_type" name="receiving_type" required>
                                <option value="PO" <?= ($receipt_data['grn_type'] == 'PO') ? 'selected' : '' ?>>Purchase Order</option>
                                <option value="TRF" <?= ($receipt_data['grn_type'] == 'TRF') ? 'selected' : '' ?>>Transfer In</option>
                                <option value="RET" <?= ($receipt_data['grn_type'] == 'RET') ? 'selected' : '' ?>>Customer Return</option>
                            </select>
                        </div>
                        <div class="input-group">
                            <label for="receiving_number">Source Document No *</label>
                            <input type="text" id="receiving_number" name="receiving_number" value="<?= htmlspecialchars($receipt_data['receiving_number']) ?>" required>
                        </div>
                        <div class="input-group">
                            <label for="receiving_date">Receive Date:</label>
                            <input type="date" id="receiving_date" name="receiving_date" class="form-control" value="<?= htmlspecialchars($receipt_data['receiving_date']) ?>" required>
                        </div>

                        <div class="input-group">
                            <label for="grn_date">GRN Date:</label>
                            <input type="date" id="grn_date" name="grn_date" class="form-control" value="<?= htmlspecialchars($receipt_data['grn_date']) ?>" required>
                        </div>

                        <div class="input-group">
                            <label for="vehicle_details">Vehicle Number (Optional):</label>
                            <input type="text" id="vehicle_details" name="vehicle_details" class="form-control" value="<?= htmlspecialchars($receipt_data['vehicle_number']) ?>">
                        </div>

                        <div class="form-actions">
                            <a href="index.php" class="action-button-link" style="background-color: var(--color-bg-tertiary); color: var(--color-text-primary);">Cancel</a>
                            <button type="submit" name="update_receipt" class="action-button">Update Receipt</button>
                        </div>
                    </form>
                <?php else: ?>
                    <p>Receipt data could not be loaded.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>

</html>