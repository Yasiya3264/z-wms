<?php
$current_username = $_SESSION['username'] ?? 'User';
$current_compcode = $_SESSION['compcode'] ?? 'N/A';
$current_wh_code = $_SESSION['wh_code'] ?? 'N/A';

// Fetch all companies this user can access at this warehouse
$available_compcodes = [];
// This check ensures nav.php won't crash if $conn isn't set
if (isset($conn) && isset($_SESSION['username']) && isset($_SESSION['wh_code'])) {
    $sql_compcodes = "SELECT DISTINCT compcode FROM users_db WHERE username = ? AND wh_code = ? ORDER BY compcode";
    $stmt_compcodes = $conn->prepare($sql_compcodes);
    if ($stmt_compcodes) {
        $stmt_compcodes->bind_param("ss", $_SESSION['username'], $_SESSION['wh_code']);
        $stmt_compcodes->execute();
        $result_compcodes = $stmt_compcodes->get_result();
        while ($row = $result_compcodes->fetch_assoc()) {
            $available_compcodes[] = $row['compcode'];
        }
        $stmt_compcodes->close();
    }
}
?>

<style>
    .topnav {
        background-color: var(--color-bg-secondary);
        border-bottom: 1px solid var(--color-border);
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        display: flex;
        align-items: center;
        padding: 0 15px;
        height: 55px;
        position: fixed;
        top: 0;
        z-index: 1001;
        left: 240px;
        right: 0;
    }

    .topnav button {
        font-size: 24px;
        background: none;
        border: none;
        color: var(--color-text-primary);
        cursor: pointer;
        padding: 10px 15px 10px 0;
        display: none;
    }

    .topnav .topnav-title {
        color: var(--color-text-primary);
        font-weight: 600;
        font-size: 1.1em;
    }

    .sidenav {
        display: flex;
        flex-direction: column;
        height: 100vh;
        width: 240px;
        position: fixed;
        top: 0;
        left: 0;
        z-index: 1002;
        background-color: var(--color-bg-secondary);
        border-right: 1px solid var(--color-border);
        transform: translateX(0);
        transition: transform 0.3s ease-in-out;
        box-sizing: border-box;
    }

    .sidenav-header {
        padding: 20px 15px;
        text-align: left;
        border-bottom: 1px solid var(--color-border);
        position: relative;
        /* For dropdown */
    }

    .sidenav-header h4 {
        margin: 0 0 5px 0;
        font-weight: 600;
        color: var(--color-text-primary);
    }

    .sidenav-header .logout-link {
        font-size: 0.9em;
        color: var(--color-accent-blue);
        text-decoration: none;
        font-weight: 500;
        margin-top: 10px;
        display: inline-block;
    }

    .sidenav-header .logout-link:hover {
        text-decoration: underline;
    }

    /* --- NEW Company Switcher Styles --- */
    .company-switcher {
        margin-top: 15px;
    }

    .company-switcher-trigger {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 8px 10px;
        background-color: var(--color-bg-primary);
        border: 1px solid var(--color-border);
        border-radius: 6px;
        cursor: pointer;
        transition: background-color 0.2s;
    }

    .company-switcher-trigger:hover {
        background-color: #f0f2f4;
    }

    .company-switcher-trigger span {
        display: flex;
        flex-direction: column;
        line-height: 1.3;
    }

    .company-switcher-trigger span strong {
        color: var(--color-text-primary);
    }

    .company-switcher-trigger span small {
        font-size: 0.8em;
        color: var(--color-text-secondary);
    }

    .company-switcher-trigger span small strong {
        color: var(--color-text-secondary);
        font-weight: 500;
    }

    .nav-icon-arrow {
        width: 16px;
        height: 16px;
        stroke-width: 2.5px;
        color: var(--color-text-secondary);
        transition: transform 0.2s;
        flex-shrink: 0;
    }

    .company-switcher-trigger.open .nav-icon-arrow {
        transform: rotate(180deg);
    }

    .company-dropdown {
        display: none;
        position: absolute;
        background-color: var(--color-bg-secondary);
        border: 1px solid var(--color-border);
        border-radius: 6px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        width: calc(100% - 30px);
        /* 15px padding left/right */
        left: 15px;
        top: 100%;
        /* Position below the header */
        z-index: 1003;
        /* Above sidenav content */
        margin-top: 5px;
        max-height: 200px;
        overflow-y: auto;
    }

    .company-dropdown .dropdown-header {
        padding: 8px 12px;
        font-size: 0.8em;
        font-weight: 600;
        color: var(--color-text-secondary);
        border-bottom: 1px solid var(--color-border);
    }

    .company-dropdown a,
    .company-dropdown span {
        display: block;
        padding: 10px 12px;
        font-size: 0.9em;
        color: var(--color-text-primary);
        text-decoration: none;
    }

    .company-dropdown a:hover {
        background-color: var(--color-nav-hover-bg);
    }

    .company-dropdown span.active {
        background-color: var(--color-bg-primary);
        color: var(--color-text-secondary);
        font-weight: 500;
    }

    /* --- END New Styles --- */

    .sidenav-menu-links {
        flex-grow: 1;
        overflow-y: auto;
        padding: 10px 0;
    }

    .sidenav-menu-links a,
    .sidenav-menu-links .dropdown-btn {
        padding: 12px 15px;
        text-decoration: none;
        font-size: 0.95em;
        color: var(--color-text-secondary);
        display: flex;
        align-items: center;
        gap: 12px;
        width: 100%;
        border: none;
        background: none;
        text-align: left;
        cursor: pointer;
        border-left: 3px solid transparent;
        transition: background-color 0.2s, color 0.2s, border-left-color 0.2s;
        box-sizing: border-box;
    }

    .sidenav-menu-links a:hover,
    .sidenav-menu-links .dropdown-btn:hover {
        background-color: var(--color-nav-hover-bg);
        color: var(--color-text-primary);
    }

    .sidenav-menu-links a.active {
        color: var(--color-text-primary);
        font-weight: 600;
        background-color: var(--color-nav-hover-bg);
        border-left-color: var(--color-accent-blue);
    }

    .sidenav-menu-links .nav-icon {
        width: 18px;
        height: 18px;
        stroke-width: 2px;
        flex-shrink: 0;
    }

    .dropdown-container {
        display: none;
        overflow: hidden;
        background-color: var(--color-bg-primary);
    }

    .dropdown-container a {
        padding-left: 48px;
        font-size: 0.9em;
        color: var(--color-text-secondary);
    }

    .dropdown-btn {
        position: relative;
    }

    .dropdown-btn::after {
        content: '›';
        font-size: 1.5em;
        position: absolute;
        right: 15px;
        transition: transform 0.2s ease;
        transform: rotate(0deg);
    }

    .dropdown-btn.active::after {
        transform: rotate(90deg);
    }

    .sidenav footer {
        flex-shrink: 0;
        padding: 15px;
        text-align: center;
        font-size: 0.75em;
        color: var(--color-text-secondary, #999);
        border-top: 1px solid var(--color-border, #eee);
        background-color: var(--color-bg-primary);
    }

    .sidenav footer p {
        margin: 0;
    }

    .sidenav .closebtn {
        position: absolute;
        top: 5px;
        right: 10px;
        font-size: 36px;
        color: var(--color-text-secondary);
        text-decoration: none;
        padding: 5px 0;
        z-index: 10;
        display: none;
    }

    .sidenav .closebtn:hover,
    .sidenav .closebtn:focus {
        color: var(--color-text-primary);
        background: none;
        border: none;
    }

    #nav-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.4);
        z-index: 1001;
        display: none;
    }

    .main {
        margin-left: 240px;
        padding: 20px;
        padding-top: 75px;
        box-sizing: border-box;
    }

    @media (max-width: 768px) {
        .topnav {
            left: 0;
        }

        .topnav button {
            display: block;
        }

        .sidenav {
            transform: translateX(-100%);
            padding-top: 0;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
        }

        .sidenav.open {
            transform: translateX(0);
        }

        .sidenav .closebtn {
            display: block;
        }

        .sidenav-header {
            padding-top: 50px;
        }

        .main {
            margin-left: 0;
            padding-top: 70px;
        }
    }
</style>

<div class="topnav">
    <button onclick="toggleNav()">&#9776;</button>
    <span class="topnav-title">Zynex WMS</span>
</div>

<div id="nav-overlay" onclick="toggleNav()"></div>

<div id="sidenav" class="sidenav">

    <a href="javascript:void(0)" class="closebtn" onclick="toggleNav()">&times;</a>

    <div class="sidenav-header">
        <h4>Welcome, <?php echo htmlspecialchars($current_username); ?>!</h4>

        <div class="company-switcher">
            <div class="company-switcher-trigger" onclick="toggleCompanyDropdown()">
                <span>
                    <strong><?php echo htmlspecialchars($current_compcode); ?></strong>
                    <small><strong>WH:</strong> <?php echo htmlspecialchars($current_wh_code); ?></small>
                </span>
                <svg class="nav-icon-arrow" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7"></path>
                </svg>
            </div>
            <div class="company-dropdown" id="companyDropdown">
                <div class="dropdown-header">Switch Company</div>
                <?php foreach ($available_compcodes as $comp): ?>
                    <?php if ($comp !== $current_compcode): ?>
                        <a href="/change_session.php?new_compcode=<?php echo urlencode($comp); ?>">
                            <?php echo htmlspecialchars($comp); ?>
                        </a>
                    <?php else: ?>
                        <span class="active"><?php echo htmlspecialchars($comp); ?> (Current)</span>
                    <?php endif; ?>
                <?php endforeach; ?>
                <?php if (count($available_compcodes) <= 1): ?>
                    <span class="active">No other companies available.</span>
                <?php endif; ?>
            </div>
        </div>
        <a href="/logout.php" class="logout-link">Logout</a>
    </div>
    <div class="sidenav-menu-links">

        <button class="dropdown-btn">
            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V7M3 7l9 5 9-5M3 7V5a2 2 0 012-2h14a2 2 0 012 2v2"></path>
            </svg>
            Masters
        </button>
        <div class="dropdown-container">
            <a href="../SKU-Master/">SKU Master</a>
            <a href="../zone_master">Zone Master</a>
            <a href="../putaway_strategy">Putaway Strategy</a>
            <a href="../Locations-Master/">Locations Master</a>
            <a href="../customer-master/">Customers Master</a>
        </div>

        <button class="dropdown-btn">
            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 10h16M4 14h16M4 18h16"></path>
            </svg>
            Operations
        </button>
        <div class="dropdown-container">
            <a href="../inbound/">Inbound</a>
            <a href="../outbound/">Outbound</a>
            <a href="../inventory-transfer/">Inventory Transfer</a>
        </div>

        <button class="dropdown-btn">
            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
            </svg>
            Reports
        </button>
        <div class="dropdown-container">
            <a href="../inventory/">Inventory By Locations</a>
            <a href="../inbound-history/">Inbound History</a>
            <a href="../outbound-history/">Outbound History</a>
            <a href="../transfer-history/">INT-Transfer History</a>
            <a href="../location_utilization/">Location Utilization</a>
            <a href="../inventory_snap/">Inventory Snap</a>
        </div>

    </div>

    <footer>
        <p>Designed by <b>Zynex Solutions</b> &copy; 2019-2025</p>
    </footer>
</div>

<script>
    // NEW function to toggle the company dropdown
    function toggleCompanyDropdown() {
        const dropdown = document.getElementById("companyDropdown");
        const trigger = document.querySelector(".company-switcher-trigger");

        if (dropdown.style.display === "block") {
            dropdown.style.display = "none";
            trigger.classList.remove("open");
        } else {
            dropdown.style.display = "block";
            trigger.classList.add("open");
        }
    }

    function toggleNav() {
        const sidenav = document.getElementById("sidenav");
        const overlay = document.getElementById("nav-overlay");

        sidenav.classList.toggle("open");

        if (sidenav.classList.contains("open")) {
            overlay.style.display = "block";
        } else {
            overlay.style.display = "none";

            // ADDED: Close company dropdown if open
            const companyDropdown = document.getElementById("companyDropdown");
            if (companyDropdown.style.display === "block") {
                companyDropdown.style.display = "none";
                document.querySelector(".company-switcher-trigger").classList.remove("open");
            }
        }
    }

    // UPDATED: Close company dropdown when clicking overlay
    document.getElementById('nav-overlay').addEventListener('click', function() {
        const companyDropdown = document.getElementById("companyDropdown");
        if (companyDropdown.style.display === "block") {
            companyDropdown.style.display = "none";
            document.querySelector(".company-switcher-trigger").classList.remove("open");
        }
    });

    document.addEventListener("DOMContentLoaded", function() {
        var dropdown = document.getElementsByClassName("dropdown-btn");
        for (var i = 0; i < dropdown.length; i++) {
            dropdown[i].addEventListener("click", function() {
                this.classList.toggle("active");
                var dropdownContent = this.nextElementSibling;
                if (dropdownContent.style.display === "block") {
                    dropdownContent.style.display = "none";
                } else {
                    dropdownContent.style.display = "block";

                    // Close company dropdown if open
                    const companyDropdown = document.getElementById("companyDropdown");
                    if (companyDropdown.style.display === "block") {
                        companyDropdown.style.display = "none";
                        document.querySelector(".company-switcher-trigger").classList.remove("open");
                    }
                }
            });
        }
    });
</script>