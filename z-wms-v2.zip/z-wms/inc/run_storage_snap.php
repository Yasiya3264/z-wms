<?php
// PHP CLI scripts should run without time limit
set_time_limit(0);

// Use 'require' to ensure the database connection is available
require 'db.php';

// --- Configuration ---
// Set the timezone to Asia/Colombo (GMT+5:30) to ensure correct timestamping
date_default_timezone_set('Asia/Colombo');

$snapshot_date = date('Y-m-d');
$current_timestamp = date('Y-m-d H:i:s');
// ---------------------

// Log the start of the process
error_log("INFO: Starting inventory snapshot process for $snapshot_date...");

// The complex SELECT query to calculate the required aggregates:
// SUM(in_hand_qty) and SUM(in_hand_qty * smallest_cbm)
$select_query = "
SELECT
    I.sku_code,
    I.compcode,
    C.wh_code,
    SUM(I.in_hand_qty) AS total_in_hand_qty,
    -- Calculate total CBM by multiplying in_hand_qty by the smallest_cbm from the SKU Master
    SUM(I.in_hand_qty * S.smallest_cbm) AS total_cbm
FROM
    inventory I
-- Join with sku_master to get CBM data
JOIN
    sku_master S ON I.sku_code = S.sku_code AND I.compcode = S.compcode
-- Join with company_master to get the warehouse code (wh_code)
JOIN
    company_master C ON I.compcode = C.comp_code
WHERE
    I.in_hand_qty > 0 -- Only snapshot inventory that is actually in hand
GROUP BY
    I.sku_code,
    I.compcode,
    C.wh_code
ORDER BY
    I.sku_code,
    I.compcode,
    C.wh_code
";

$result = $conn->query($select_query);

if (!$result) {
    error_log("ERROR: Snapshot generation SELECT failed: " . $conn->error);
    exit("Error generating snapshot data: " . $conn->error);
}

// Start transaction for atomicity: all inserts succeed or all fail/rollback
$conn->begin_transaction();
$insert_count = 0;

try {
    // 1. Delete any existing snapshot for today to ensure idempotency (prevent running the job twice)
    $delete_stmt = $conn->prepare("DELETE FROM inventory_snapshot WHERE snapshot_date = ?");
    $delete_stmt->bind_param("s", $snapshot_date);
    $delete_stmt->execute();
    $delete_stmt->close();

    // 2. Prepare the insert statement for efficiency
    $insert_stmt = $conn->prepare("
        INSERT INTO inventory_snapshot (
            snapshot_date, sku_code, compcode, wh_code, total_in_hand_qty, total_cbm, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
    ");

    // Loop through the aggregated results and insert into the snapshot table
    while ($row = $result->fetch_assoc()) {
        $insert_stmt->bind_param(
            "ssssids",
            $snapshot_date,
            $row['sku_code'],
            $row['compcode'],
            $row['wh_code'],
            $row['total_in_hand_qty'],
            $row['total_cbm'],
            $current_timestamp
        );
        if (!$insert_stmt->execute()) {
            // Throw an exception to trigger the rollback
            throw new Exception("Insert failed for SKU: " . $row['sku_code'] . ". Error: " . $insert_stmt->error);
        }
        $insert_count++;
    }

    $insert_stmt->close();
    $conn->commit();
    error_log("SUCCESS: Inventory snapshot successfully created for $snapshot_date. Inserted $insert_count rows.");
    echo "Snapshot completed successfully. Inserted $insert_count records.\n";
} catch (Exception $e) {
    $conn->rollback();
    error_log("ERROR: Transaction failed. Rolled back. Message: " . $e->getMessage());
    echo "Failed to create inventory snapshot. Transaction rolled back. Check server logs.\n";
}

$conn->close();
?>