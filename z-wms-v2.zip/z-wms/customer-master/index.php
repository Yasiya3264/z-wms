<?php
session_start();
require '../inc/db.php'; // Ensure db.php establishes $conn (mysqli object)

if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    header("Location: ../");
    exit();
}

$compcode = $_SESSION['compcode'];
$message = ''; // For success/error messages

// Handle Add Customer Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_customer'])) {
    $customer_code = trim($_POST['customer_code']);
    $customer_name = trim($_POST['customer_name']);
    $address1 = trim($_POST['address1']);
    $address2 = trim($_POST['address2']);
    $address3 = trim($_POST['address3']);
    $email = trim($_POST['email']);
    $tel = trim($_POST['tel']);
    $fax = trim($_POST['fax']);

    // Basic validation
    if (empty($customer_code) || empty($customer_name)) {
        // Updated class to use global alert style
        $message = '<div class="message alert-danger">Customer Code and Customer Name are required.</div>';
    } else {
        // Check for duplicate customer code for the same company
        $check_sql = "SELECT COUNT(*) FROM customers_master WHERE compcode = ? AND customer_code = ?";
        $check_stmt = $conn->prepare($check_sql);
        if ($check_stmt) {
            $check_stmt->bind_param("ss", $compcode, $customer_code);
            $check_stmt->execute();
            $check_stmt->bind_result($count);
            $check_stmt->fetch();
            $check_stmt->close();

            if ($count > 0) {
                // Updated class to use global alert style
                $message = '<div class="message alert-danger">Customer Code already exists for this company.</div>';
            } else {
                // Insert new customer using prepared statement
                $insert_sql = "INSERT INTO customers_master (compcode, customer_code, customer_name, address1, address2, address3, email, tel, fax) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($insert_sql);

                if ($stmt) {
                    $stmt->bind_param("sssssssss", $compcode, $customer_code, $customer_name, $address1, $address2, $address3, $email, $tel, $fax);
                    if ($stmt->execute()) {
                        // Updated class to use global alert style
                        $message = '<div class="message alert-success">Customer added successfully!</div>';
                        // Clear form fields after successful submission if needed, or redirect
                        // header("Location: index.php"); exit(); // uncomment to refresh and clear form
                    } else {
                        // Updated class to use global alert style
                        $message = '<div class="message alert-danger">Error adding customer: ' . htmlspecialchars($stmt->error) . '</div>';
                    }
                    $stmt->close();
                } else {
                    // Updated class to use global alert style
                    $message = '<div class="message alert-danger">Database error preparing statement: ' . htmlspecialchars($conn->error) . '</div>';
                }
            }
        } else {
            // Updated class to use global alert style
            $message = '<div class="message alert-danger">Database error checking duplicate: ' . htmlspecialchars($conn->error) . '</div>';
        }
    }
}

// Fetch Customers for display
$customers_sql = "SELECT * FROM customers_master WHERE compcode = ? ORDER BY customer_name";
$customers_stmt = $conn->prepare($customers_sql);
$customers_data = null;
if ($customers_stmt) {
    $customers_stmt->bind_param("s", $compcode);
    $customers_stmt->execute();
    $customers_data = $customers_stmt->get_result();
} else {
    // Updated class to use global alert style
    $message = '<div class="message alert-danger">Database error fetching customers: ' . htmlspecialchars($conn->error) . '</div>';
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Zynex WMS | Customer Master</title>
    <link rel="stylesheet" href="../inc/global.css">
    <style>
        .main {
            width: 85%;
            overflow: visible;
        }
        /*
         * Form Styles - Ensures the form-grid works as intended by the global CSS
         */
        .customer-form {
            display: grid;
            /* Sets up columns that auto-fit, stacking on small screens */
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px 20px;
        }

        .customer-form .input-group input {
            width: 100%;
        }

        /* Ensure the button spans the full width of the card on its own row */
        .customer-form .button-group {
            grid-column: 1 / -1;
            margin-top: 10px;
        }


        /*
         * Mobile Table Styles - Implementing the 'Card View' pattern
         */
        @media (max-width: 768px) {
            .data-table {
                border: none;
                /* Remove outer table border for card view */
                margin-top: 0;
            }

            .data-table thead {
                display: none;
                /* Hide standard headers */
            }

            .data-table tbody tr {
                display: block;
                /* Make row act as a block element (card) */
                margin-bottom: 15px;
                padding: 10px;
                border: 1px solid var(--color-border);
                border-radius: 6px;
                background-color: var(--color-bg-secondary);
                /* Ensure all rows look like cards */
            }

            /* Cells become blocks, right-aligned for content */
            .data-table th,
            .data-table td {
                display: block;
                text-align: right;
                padding: 5px 10px;
                border-bottom: none !important;
                /* Remove cell separators */
                border-right: none;
            }

            /* Use ::before to display the column header name (label) */
            .data-table td::before {
                content: attr(data-label);
                font-weight: 600;
                color: var(--color-text-secondary);
                float: left;
                padding-right: 10px;
            }

            /* Remove hover effect background as it conflicts with card structure */
            .data-table tbody tr:hover {
                background-color: var(--color-bg-secondary) !important;
            }

            /* Ensure background is primary in dark mode to not rely on nth-child */
            .data-table tbody tr:nth-child(even),
            .data-table tbody tr:nth-child(odd) {
                background-color: var(--color-bg-secondary);
            }
        }
    </style>
</head>

<body>
    <?php require '../parts/nav.php'; ?>

    <div id="main" class="main">
        <div class="module-container">
            <h2>Customer Master</h2>

            <?php echo $message; // Display messages 
            ?>

            <div class="card">
                <h3>Add New Customer</h3>
                <form action="" method="POST" class="customer-form">
                    <div class="input-group">
                        <label for="customer_code">Customer Code *</label>
                        <input type="text" id="customer_code" name="customer_code" required>
                    </div>
                    <div class="input-group">
                        <label for="customer_name">Customer Name *</label>
                        <input type="text" id="customer_name" name="customer_name" required>
                    </div>
                    <div class="input-group">
                        <label for="address1">Address 1</label>
                        <input type="text" id="address1" name="address1">
                    </div>
                    <div class="input-group">
                        <label for="address2">Address 2</label>
                        <input type="text" id="address2" name="address2">
                    </div>
                    <div class="input-group">
                        <label for="address3">Address 3</label>
                        <input type="text" id="address3" name="address3">
                    </div>
                    <div class="input-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email">
                    </div>
                    <div class="input-group">
                        <label for="tel">Telephone</label>
                        <input type="tel" id="tel" name="tel">
                    </div>
                    <div class="input-group">
                        <label for="fax">FAX</label>
                        <input type="text" id="fax" name="fax">
                    </div>

                    <div class="button-group">
                        <button type="submit" name="add_customer" class="action-button">Add Customer</button>
                    </div>
                </form>
            </div>

            <div class="card">
                <h3>Existing Customers</h3>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Customer Code</th>
                            <th>Customer Name</th>
                            <th>Address</th>
                            <th>Email</th>
                            <th>Telephone</th>
                            <th>FAX</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($customers_data && $customers_data->num_rows > 0): ?>
                            <?php while ($row = $customers_data->fetch_assoc()): ?>
                                <tr>
                                    <td data-label="Customer Code"><?= htmlspecialchars($row['customer_code']) ?></td>
                                    <td data-label="Customer Name"><?= htmlspecialchars($row['customer_name']) ?></td>
                                    <td data-label="Address">
                                        <?= htmlspecialchars($row['address1']) ?><br>
                                        <?= htmlspecialchars($row['address2']) ?><br>
                                        <?= htmlspecialchars($row['address3']) ?>
                                    </td>
                                    <td data-label="Email"><?= htmlspecialchars($row['email']) ?></td>
                                    <td data-label="Telephone"><?= htmlspecialchars($row['tel']) ?></td>
                                    <td data-label="FAX"><?= htmlspecialchars($row['fax']) ?></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6">No customers found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</body>

</html>