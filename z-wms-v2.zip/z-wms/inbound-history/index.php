<?php
session_start();
require '../inc/db.php'; // Adjust path if necessary

if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    header("Location: ../");
    exit();
}

$compcode = $_SESSION['compcode'];
$message = '';

// Get date filter parameters from GET request
$filter_start_date = isset($_GET['start_date']) ? $_GET['start_date'] : '';
$filter_end_date = isset($_GET['end_date']) ? $_GET['end_date'] : '';

// Fetch Confirmed Inbound History Records, joining with inbound_receipts to get the header ID
// and joining with sku_master to get smallest_cbm for total CBM calculation
$inbound_history_records = [];
$total_quantity_received = 0;
$total_cbm_received = 0;

$history_sql = "SELECT
                    ih.id,
                    ih.record_number,
                    ih.grn_number,
                    ih.receiving_type,
                    ih.receiving_number,
                    ih.receiving_date,
                    ih.vehicle_number,
                    ih.sku_code,
                    ih.quantity,
                    ih.mfd,
                    ih.exd,
                    ir.id AS receipt_header_id,
                    sm.smallest_cbm -- Fetch smallest_cbm from sku_master
                FROM
                    inbound_history ih
                LEFT JOIN
                    inbound_receipts ir ON ih.grn_number = ir.grn_number
                    AND ir.compcode = ih.compcode
                    AND ir.sku_code IS NULL -- To get the main GRN header record
                    AND ir.status = 'confirmed'
                LEFT JOIN
                    sku_master sm ON ih.sku_code = sm.sku_code AND ih.compcode = sm.compcode
                WHERE
                    ih.compcode = ? AND ih.status = 'confirmed'";

// Add date range filter to SQL query if dates are provided
if (!empty($filter_start_date) && !empty($filter_end_date)) {
    $history_sql .= " AND ih.receiving_date BETWEEN ? AND ?";
} elseif (!empty($filter_start_date)) {
    $history_sql .= " AND ih.receiving_date >= ?";
} elseif (!empty($filter_end_date)) {
    $history_sql .= " AND ih.receiving_date <= ?";
}

$history_sql .= " ORDER BY ih.created_at DESC";

$history_stmt = $conn->prepare($history_sql);
if ($history_stmt) {
    $param_types = "s";
    $params = [$compcode];

    if (!empty($filter_start_date) && !empty($filter_end_date)) {
        $param_types .= "ss";
        $params[] = $filter_start_date;
        $params[] = $filter_end_date;
    } elseif (!empty($filter_start_date)) {
        $param_types .= "s";
        $params[] = $filter_start_date;
    } elseif (!empty($filter_end_date)) {
        $param_types .= "s";
        $params[] = $filter_end_date;
    }

    // Fix for bind_param: arguments must be passed by reference
    // Create a new array with references to the parameters
    $bind_params = [];
    $bind_params[] = &$param_types; // First element is the type string
    for ($i = 0; $i < count($params); $i++) {
        $bind_params[] = &$params[$i]; // Subsequent elements are references to the actual parameters
    }

    // Use call_user_func_array to bind parameters dynamically
    call_user_func_array([$history_stmt, 'bind_param'], $bind_params);

    $history_stmt->execute();
    $history_result = $history_stmt->get_result();
    while ($row = $history_result->fetch_assoc()) {
        $inbound_history_records[] = $row;
        $total_quantity_received += (int)$row['quantity'];
        // Calculate CBM for each item and add to total
        $item_cbm = (float)$row['quantity'] * (float)($row['smallest_cbm'] ?? 0); // Use null coalescing to handle potential null smallest_cbm
        $total_cbm_received += $item_cbm;
    }
    $history_stmt->close();
} else {
    $message .= '<div class="error-message">Database error fetching inbound history: ' . htmlspecialchars($conn->error) . '</div>';
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Zynex WMS | Inbound History</title>
    <link rel="stylesheet" href="../inc/global.css">
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <style>
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .container h3 {
            color: var(--primary-color);
            margin-bottom: 15px;
        }

        .filter-group {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 20px;
            padding: 15px;
            background-color: #f8f9fa;
            border-radius: 8px;
            border: 1px solid #e9ecef;
        }

        .filter-group label {
            align-self: center;
            font-weight: bold;
            color: #333;
        }

        .filter-group input[type="text"],
        .filter-group input[type="date"] {
            flex: 1;
            min-width: 150px;
            padding: 8px;
            border: 1px solid #ced4da;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .filter-group input[type="text"]:focus,
        .filter-group input[type="date"]:focus {
            border-color: var(--color-accent-blue);
            outline: none;
            box-shadow: 0 0 0 3px var(--color-focus-shadow);
        }

        .filter-group button {
            cursor: pointer;
            font-weight: 500;
            line-height: 20px;
            padding: 8px 16px;
            text-align: center;
            color: #ffffff;
            background-color: var(--color-accent-blue);
            border: 1px solid var(--color-accent-blue);
            border-radius: 6px;
            transition: background-color 0.15s ease;
            display: inline-block;
        }

        .filter-group button:hover {
            background-color: #0c4d9a;
            border-color: #0c4d9a;
        }


        .history-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .history-table th,
        .history-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
            font-size: 14px;
        }

        .history-table th {
            background-color: #f2f2f2;
            color: #555;
            font-weight: bold;
        }

        .history-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .history-table tr:hover {
            background-color: #f1f1f1;
        }

        .history-table tfoot td {
            font-weight: bold;
            background-color: #e9ecef;
        }

        .text-right {
            text-align: right;
        }

        .text-center {
            text-align: center;
        }

        .error-message {
            color: #d9534f;
            background-color: #f2dede;
            border: 1px solid #ebccd1;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
        }

        .action-link {
            color: var(--btn-prim);
            text-decoration: none;
            font-weight: bold;
        }

        .action-link:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <?php require '../parts/nav.php'; ?>
    <div id="main" class="main">
        <h2>Inbound History</h2>
        <?php echo $message; ?>

        <div class="container">
            <h3>Confirmed Inbound Records</h3>

            <!-- Date Range Filter Form (Server-Side) -->
            <form method="GET" action="" class="filter-group">
                <label for="start_date">Date From:</label>
                <input type="date" id="start_date" name="start_date" value="<?= htmlspecialchars($filter_start_date) ?>" />
                <label for="end_date">Date To:</label>
                <input type="date" id="end_date" name="end_date" value="<?= htmlspecialchars($filter_end_date) ?>" />
                <button type="submit">Apply Date Filter</button>
                <button type="button" id="clear_date_filters_btn">Clear Date Filters</button>
            </form>

            <!-- Client-Side Text Filters -->
            <div class="filter-group">
                <input type="text" id="filter_grn_no" placeholder="Filter by GRN No" />
                <input type="text" id="filter_sku_code" placeholder="Filter by SKU Code" />
                <button id="clear_text_filters_btn">Clear Text Filters</button>
            </div>

            <table class="history-table">
                <thead>
                    <tr>
                        <th>GRN No</th>
                        <th>Record No</th>
                        <th>Type</th>
                        <th>Receiving No</th>
                        <th>Date</th>
                        <th>Vehicle</th>
                        <th>SKU Code</th>
                        <th>MFD</th>
                        <th>EXD</th>
                        <th class="text-right">Quantity</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="historyTableBody">
                    <?php if (!empty($inbound_history_records)): ?>
                        <?php foreach ($inbound_history_records as $record): ?>
                            <tr
                                data-grn-number="<?= htmlspecialchars($record['grn_number'] ?: '') ?>"
                                data-sku-code="<?= htmlspecialchars($record['sku_code'] ?: '') ?>"
                                data-receiving-date="<?= htmlspecialchars($record['receiving_date'] ?: '') ?>"
                                data-quantity="<?= (int)$record['quantity'] ?>"
                                data-cbm="<?= (float)$record['quantity'] * (float)($record['smallest_cbm'] ?? 0) ?>">
                                <td><?= htmlspecialchars($record['grn_number'] ?: 'N/A') ?></td>
                                <td><?= htmlspecialchars($record['record_number']) ?></td>
                                <td><?= htmlspecialchars($record['receiving_type'] ?: 'N/A') ?></td>
                                <td><?= htmlspecialchars($record['receiving_number'] ?: 'N/A') ?></td>
                                <td><?= htmlspecialchars($record['receiving_date'] ?: 'N/A') ?></td>
                                <td><?= htmlspecialchars($record['vehicle_number'] ?: 'N/A') ?></td>
                                <td><?= htmlspecialchars($record['sku_code']) ?></td>
                                <td><?= htmlspecialchars($record['mfd']) ?></td>
                                <td><?= htmlspecialchars($record['exd']) ?></td>
                                <td class="text-right"><?= (int)$record['quantity'] ?></td>
                                <td>
                                    <?php if (!empty($record['grn_number']) && !empty($record['receipt_header_id'])): ?>
                                        <a href="../inbound/print_grn.php?receipt_id=<?= (int)$record['receipt_header_id'] ?>&grn_number=<?= htmlspecialchars($record['grn_number']) ?>" target="_blank" class="action-link">Print GRN</a>
                                    <?php else: ?>
                                        N/A
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr id="no_records_row">
                            <td colspan="11" class="text-center">No confirmed inbound records found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="9" class="text-right"><strong>Total Quantity:</strong></td>
                        <td class="text-right" id="totalQuantityFooter"><strong><?= (int)$total_quantity_received ?></strong></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td colspan="9" class="text-right"><strong>Total CBM:</strong></td>
                        <td class="text-right" id="totalCBMFooter"><strong><?= number_format($total_cbm_received, 3) ?></strong></td>
                        <td></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            const $historyTableBody = $('#historyTableBody');
            const $totalQuantityFooter = $('#totalQuantityFooter');
            const $totalCBMFooter = $('#totalCBMFooter');

            // Function to update totals based on visible rows
            function updateTotals() {
                let currentTotalQuantity = 0;
                let currentTotalCBM = 0;
                let visibleRowsCount = 0;

                $historyTableBody.find('tr').each(function() {
                    if ($(this).css('display') !== 'none') {
                        currentTotalQuantity += parseInt($(this).data('quantity'));
                        currentTotalCBM += parseFloat($(this).data('cbm'));
                        visibleRowsCount++;
                    }
                });

                $totalQuantityFooter.text(currentTotalQuantity);
                $totalCBMFooter.text(currentTotalCBM.toFixed(3)); // Format to 3 decimal places

                // Handle "No records found" row dynamically for client-side filters
                let $noRecordsRow = $('#no_records_row');
                if (visibleRowsCount === 0) {
                    if ($noRecordsRow.length === 0) {
                        // Create and append if it doesn't exist
                        $historyTableBody.append('<tr id="no_records_row"><td colspan="11" class="text-center">No confirmed inbound records found matching filters.</td></tr>');
                    } else {
                        // Just show it if it exists
                        $noRecordsRow.show();
                    }
                } else {
                    // Hide it if there are visible rows
                    if ($noRecordsRow.length > 0) {
                        $noRecordsRow.hide();
                    }
                }
            }

            // Function to apply client-side text filters
            function applyTextFilters() {
                const filterGrnNo = $('#filter_grn_no').val().toLowerCase();
                const filterSkuCode = $('#filter_sku_code').val().toLowerCase();

                $historyTableBody.find('tr').each(function() {
                    const $row = $(this);
                    // Ensure the row is not the "no records" row before processing its data
                    if ($row.attr('id') === 'no_records_row') {
                        return true; // Continue to the next iteration
                    }

                    const rowGrnNumber = $row.data('grn-number').toLowerCase();
                    const rowSkuCode = $row.data('sku-code').toLowerCase();

                    let showRow = true;

                    // Filter by GRN No
                    if (filterGrnNo && !rowGrnNumber.includes(filterGrnNo)) {
                        showRow = false;
                    }

                    // Filter by SKU Code
                    if (filterSkuCode && !rowSkuCode.includes(filterSkuCode)) {
                        showRow = false;
                    }

                    if (showRow) {
                        $row.show();
                    } else {
                        $row.hide();
                    }
                });
                updateTotals(); // Recalculate totals after filtering
            }

            // Attach event listeners to client-side filter inputs
            $('#filter_grn_no, #filter_sku_code').on('input', applyTextFilters);

            // Clear text filters button
            $('#clear_text_filters_btn').on('click', function() {
                $('#filter_grn_no').val('');
                $('#filter_sku_code').val('');
                applyTextFilters(); // Apply filters to show all rows
            });

            // Clear date filters button
            $('#clear_date_filters_btn').on('click', function() {
                window.location.href = window.location.pathname; // Reload page without date parameters
            });

            // Initial total calculation and text filter application on page load
            // This ensures client-side filters are applied even if dates are pre-set
            applyTextFilters();
        });
    </script>
</body>

</html>