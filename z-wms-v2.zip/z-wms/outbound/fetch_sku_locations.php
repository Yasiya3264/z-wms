<?php
session_start();
require '../inc/db.php';

header('Content-Type: application/json');

if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit();
}

$compcode = $_SESSION['compcode'];
$sku_code_search = isset($_GET['sku_code']) ? trim($_GET['sku_code']) : '';

if (empty($sku_code_search)) {
    echo json_encode(['status' => 'error', 'message' => 'SKU code is required.']);
    exit();
}

// Fetch available inventory for the SKU code, ordered by EXD (FIFO/FEFO potential)
// We join with sku_master to get description
$sql = "SELECT i.sku_code, sm.sku_description, i.location_code, i.batch_number, i.mfd, i.exd, i.in_hand_qty, i.allocated_qty
        FROM inventory i
        JOIN sku_master sm ON i.sku_code = sm.sku_code AND i.compcode = sm.compcode
        WHERE i.compcode = ? AND i.sku_code LIKE ? AND i.in_hand_qty > i.allocated_qty
        ORDER BY i.exd ASC, i.location_code ASC"; // Order by EXD for FEFO/FIFO

$stmt = $conn->prepare($sql);
if ($stmt) {
    $search_param = '%' . $sku_code_search . '%';
    $stmt->bind_param("ss", $compcode, $search_param);
    $stmt->execute();
    $result = $stmt->get_result();

    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    echo json_encode(['status' => 'success', 'data' => $data]);
    $stmt->close();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Database error: ' . htmlspecialchars($conn->error)]);
}

$conn->close();
exit();
