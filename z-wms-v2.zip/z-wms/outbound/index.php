<?php
session_start();
require '../inc/db.php';

if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    header("Location: ../");
    exit();
}

$compcode = $_SESSION['compcode'];
// FIX 1: Retrieve wh_code from session for the INSERT statement
$wh_code = $_SESSION['wh_code'] ?? null;
$message = '';

if (empty($wh_code)) {
    // STYLE CHANGE: Updated class from 'error-message' to 'message alert-danger'
    $message .= '<div class="message alert-danger">Warehouse Code is missing from session. Cannot create issue.</div>';
    // Exit script if essential data is missing
    // You might want to remove 'exit()' and let the rest of the file run to display the message
}


// Fetch Customers for the dropdown
$customers = [];
$customers_sql = "SELECT customer_code, customer_name FROM customers_master WHERE compcode = ? ORDER BY customer_name";
$customers_stmt = $conn->prepare($customers_sql);
if ($customers_stmt) {
    $customers_stmt->bind_param("s", $compcode);
    $customers_stmt->execute();
    $customers_result = $customers_stmt->get_result();
    while ($row = $customers_result->fetch_assoc()) {
        $customers[] = $row;
    }
    $customers_stmt->close();
} else {
    // STYLE CHANGE: Updated class from 'error-message' to 'message alert-danger'
    $message .= '<div class="message alert-danger">Database error fetching customers: ' . htmlspecialchars($conn->error) . '</div>';
}


// Handle Create New Issue Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_issue'])) {
    $manual_issue_number = trim($_POST['manual_issue_number']); // User-entered issue number
    $customer_code = trim($_POST['customer_code']);
    $gdn_type = trim($_POST['gdn_type']);
    $vehicle_details = trim($_POST['vehicle_details']); // Optional

    if (empty($manual_issue_number) || empty($customer_code) || empty($gdn_type)) {
        // STYLE CHANGE: Updated class from 'error-message' to 'message alert-danger'
        $message = '<div class="message alert-danger">Issue Number, Customer, and Issuing Type are required.</div>';
    } else if (empty($wh_code)) {
        // Double check the wh_code before proceeding with DB operations
        // STYLE CHANGE: Updated class from 'error-message' to 'message alert-danger'
        $message = '<div class="message alert-danger">Warehouse Code is required to create a dispatch record.</div>';
    } else {
        // Check for duplicate manual_issue_number for the same company
        $check_sql = "SELECT COUNT(*) FROM outbound_issues WHERE compcode = ? AND issue_number = ? AND sku_code IS NULL"; // Only check header rows
        $check_stmt = $conn->prepare($check_sql);
        if ($check_stmt) {
            $check_stmt->bind_param("ss", $compcode, $manual_issue_number);
            $check_stmt->execute();
            $check_stmt->bind_result($count);
            $check_stmt->fetch();
            $check_stmt->close();

            if ($count > 0) {
                // STYLE CHANGE: Updated class from 'error-message' to 'message alert-danger'
                $message = '<div class="message alert-danger">Issue Number "' . htmlspecialchars($manual_issue_number) . '" already exists for this company. Please choose a different one.</div>';
            } else {
                // Insert new outbound issue header
                // status is 'draft' by default, gdn_final_number is NULL initially
                // FIX 2: Added wh_code to the INSERT column list
                $insert_sql = "INSERT INTO outbound_issues (compcode, issue_number, gdn_type, customer_code, vehicle_details, created_by, quantity, pick_qty, wh_code, sku_code) 
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NULL)";
                $stmt = $conn->prepare($insert_sql);

                if ($stmt) {
                    $created_by = $_SESSION['username'];
                    $zero_qty = 0;
                    // FIX 3: Added 's' (string) for wh_code and the variable $wh_code to the binding list
                    $stmt->bind_param("ssssssiis", $compcode, $manual_issue_number, $gdn_type, $customer_code, $vehicle_details, $created_by, $zero_qty, $zero_qty, $wh_code);
                    if ($stmt->execute()) {
                        $inserted_id = $conn->insert_id;
                        // STYLE CHANGE: Updated class from 'success-message' to 'message alert-success'
                        $message = '<div class="message alert-success">Issue ' . htmlspecialchars($manual_issue_number) . ' created successfully!</div>';
                        // Redirect to the issue details page
                        header("Location: issue_details.php?issue_id=" . $inserted_id);
                        exit();
                    } else {
                        // STYLE CHANGE: Updated class from 'error-message' to 'message alert-danger'
                        $message = '<div class="message alert-danger">Error creating issue: ' . htmlspecialchars($stmt->error) . '</div>';
                    }
                    $stmt->close();
                } else {
                    // STYLE CHANGE: Updated class from 'error-message' to 'message alert-danger'
                    $message = '<div class="message alert-danger">Database error preparing statement: ' . htmlspecialchars($conn->error) . '</div>';
                }
            }
        } else {
            // STYLE CHANGE: Updated class from 'error-message' to 'message alert-danger'
            $message = '<div class="message alert-danger">Database error checking duplicate: ' . htmlspecialchars($conn->error) . '</div>';
        }
    }
}

// Fetch Drafted Records for display
$draft_issues = [];
$draft_sql = "SELECT oi.id, oi.issue_number, oi.gdn_type, oi.customer_code, cm.customer_name, oi.created_at
              FROM outbound_issues oi
              JOIN customers_master cm ON oi.customer_code = cm.customer_code AND oi.compcode = cm.compcode
              WHERE oi.compcode = ? AND oi.status = 'draft' AND oi.sku_code IS NULL
              ORDER BY oi.created_at DESC";
$draft_stmt = $conn->prepare($draft_sql);
if ($draft_stmt) {
    $draft_stmt->bind_param("s", $compcode);
    $draft_stmt->execute();
    $draft_result = $draft_stmt->get_result();
    while ($row = $draft_result->fetch_assoc()) {
        $draft_issues[] = $row;
    }
    $draft_stmt->close();
} else {
    // STYLE CHANGE: Updated class from 'error-message' to 'message alert-danger'
    $message .= '<div class="message alert-danger">Database error fetching drafted issues: ' . htmlspecialchars($conn->error) . '</div>';
}

// --- THIS LINE IS REMOVED ---
// $conn->close(); // Close connection after all operations
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Zynex WMS | Outbound Dispatch</title>
    <link rel="stylesheet" href="../inc/global.css">
    <style>
        .main {
            width: 85%;
            overflow: visible;
        }

        .form-card {
            max-width: 400px;
        }

        .action_button,
        .action-link {
            cursor: pointer;
            font-weight: 500;
            line-height: 20px;
            padding: 8px 16px;
            text-align: center;
            color: #ffffff;
            background-color: var(--color-accent-blue);
            border: 1px solid var(--color-accent-blue);
            border-radius: 6px;
            transition: background-color 0.15s ease;
            display: inline-block;
            text-decoration: none;
        }

        .action-link:hover {
            background-color: #0c4d9a;
            border-color: #0c4d9a;
        }

        /* Ensure textarea inside input-group is styled correctly */
        .input-group textarea {
            width: 100%;
            min-height: 80px;
            /* Adjust height for textarea */
            padding: 8px;
            border: 1px solid var(--color-border);
            border-radius: 4px;
            box-sizing: border-box;
            resize: vertical;
        }

        /* Ensure form labels and inputs inside input-group align with global.css */
        /* Note: global.css should handle most of this, but adding H3 style for consistency */
        .card h3 {
            color: var(--color-text-primary);
            margin-bottom: 15px;
            font-weight: 600;
        }
    </style>
</head>

<body>
    <?php require '../parts/nav.php'; ?>

    <div id="main" class="main">
        <h2>Outbound Dispatch</h2>

        <?php echo $message; ?>

        <div class="card form-card">
            <h3>Create New Dispatch Record</h3>
            <form action="" method="POST">
                <div class="input-group">
                    <label for="manual_issue_number">Issuing Number (Manual) *</label>
                    <input type="text" id="manual_issue_number" name="manual_issue_number" required value="<?= htmlspecialchars($_POST['manual_issue_number'] ?? '') ?>">
                </div>
                <div class="input-group">
                    <label for="gdn_type">Issuing Type *</label>
                    <select id="gdn_type" name="gdn_type" required>
                        <option value="">-- Select Type --</option>
                        <option value="DO" <?= (isset($_POST['gdn_type']) && $_POST['gdn_type'] == 'DO') ? 'selected' : '' ?>>DO - Delivery Order</option>
                        <option value="AD" <?= (isset($_POST['gdn_type']) && $_POST['gdn_type'] == 'AD') ? 'selected' : '' ?>>AD - Adjustments</option>
                        <option value="TN" <?= (isset($_POST['gdn_type']) && $_POST['gdn_type'] == 'TN') ? 'selected' : '' ?>>TN - Transfer Note</option>
                        <option value="SO" <?= (isset($_POST['gdn_type']) && $_POST['gdn_type'] == 'SO') ? 'selected' : '' ?>>SO - Sales Order</option>
                    </select>
                </div>
                <div class="input-group">
                    <label for="customer_code">Issuing Customer *</label>
                    <select id="customer_code" name="customer_code" required>
                        <option value="">-- Select Customer --</option>
                        <?php foreach ($customers as $customer): ?>
                            <option value="<?= htmlspecialchars($customer['customer_code']) ?>"
                                <?= (isset($_POST['customer_code']) && $_POST['customer_code'] == $customer['customer_code']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($customer['customer_name']) ?> (<?= htmlspecialchars($customer['customer_code']) ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="input-group">
                    <label for="vehicle_details">Vehicle Details (Optional)</label>
                    <textarea id="vehicle_details" name="vehicle_details" rows="3"><?= htmlspecialchars($_POST['vehicle_details'] ?? '') ?></textarea>
                </div>
                <div class="input-group">
                    <input type="submit" name="create_issue" class="action_button" value="Create Issue">
                </div>
            </form>
        </div>

        <div class="card" style="margin-top: 20px;">
            <h3>Draft Dispatch Records</h3>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Issue No</th>
                        <th>Type</th>
                        <th>Customer</th>
                        <th>Created At</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($draft_issues)): ?>
                        <?php foreach ($draft_issues as $issue): ?>
                            <tr>
                                <td><?= htmlspecialchars($issue['issue_number']) ?></td>
                                <td><?= htmlspecialchars($issue['gdn_type']) ?></td>
                                <td><?= htmlspecialchars($issue['customer_name']) ?> (<?= htmlspecialchars($issue['customer_code']) ?>)</td>
                                <td><?= htmlspecialchars($issue['created_at']) ?></td>
                                <td><a href="issue_details.php?issue_id=<?= (int)$issue['id'] ?>" class="action-link">Manage Items</a></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" style="text-align: center; color: var(--color-text-secondary);">No draft dispatch records found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>

</html>
<?php
// --- THIS LINE IS ADDED ---
// Close the connection at the very end of the file
if ($conn) {
    $conn->close();
}
?>