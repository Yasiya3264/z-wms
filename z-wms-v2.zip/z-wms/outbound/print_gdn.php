<?php
session_start();
require '../inc/db.php';

if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    header("Location: ../");
    exit();
}

$compcode = $_SESSION['compcode'];
$issue_id = isset($_GET['issue_id']) ? (int)$_GET['issue_id'] : 0;
$gdn_number_param = isset($_GET['gdn_number']) ? $_GET['gdn_number'] : ''; // Passed after confirmation

if ($issue_id <= 0 || empty($gdn_number_param)) {
    die("Invalid request: Missing Issue ID or GDN Number.");
}

// Fetch Issue Header Details (MODIFIED: Added oi.wh_code to select)
$header_sql = "SELECT oi.issue_number, oi.gdn_final_number, oi.gdn_type, oi.customer_code, oi.wh_code, cm.customer_name,
                      cm.address1, cm.address2, cm.address3, cm.email, cm.tel, cm.fax,
                      oi.vehicle_details, oi.created_at, oi.status
               FROM outbound_issues oi
               JOIN customers_master cm ON oi.customer_code = cm.customer_code AND oi.compcode = cm.compcode
               WHERE oi.id = ? AND oi.compcode = ? AND oi.gdn_final_number = ? AND oi.sku_code IS NULL AND oi.status = 'confirmed'";
$header_stmt = $conn->prepare($header_sql);
$issue_details = null;
if ($header_stmt) {
    $header_stmt->bind_param("iss", $issue_id, $compcode, $gdn_number_param);
    $header_stmt->execute();
    $header_result = $header_stmt->get_result();
    if ($header_result->num_rows > 0) {
        $issue_details = $header_result->fetch_assoc();
    }
    $header_stmt->close();
}

if (!$issue_details) {
    die("GDN details not found, unauthorized, or not confirmed for this ID and GDN number combination.");
}

// === CORRECTED LOGIC: Fetch Warehouse Details (Removed 'AND compcode = ?') ===
$wh_code = $issue_details['wh_code'];
$warehouse_details = null;
if (!empty($wh_code)) {
    // Corrected SQL: Removed `AND compcode = ?`
    $wh_sql = "SELECT wh_name, wh_address1, wh_address2 FROM warehouse_master WHERE wh_code = ?";
    $wh_stmt = $conn->prepare($wh_sql);
    if ($wh_stmt) {
        // Corrected bind_param: Only binds $wh_code
        $wh_stmt->bind_param("s", $wh_code);
        $wh_stmt->execute();
        $wh_result = $wh_stmt->get_result();
        $warehouse_details = $wh_result->fetch_assoc();
        $wh_stmt->close();
    }
}
// ============================================================================


// Use the gdn_final_number from the fetched header to get its items
$final_gdn_number_for_items = $issue_details['gdn_final_number'];

// Fetch Issue Items for GDN, grouped by SKU Code and Batch/LOT No
$items_sql = "SELECT
                oi.sku_code,
                sm.sku_description,
                oi.batch_number,
                MAX(oi.exd) AS exd,
                SUM(oi.quantity) AS total_dispatched_quantity,
                (SUM(oi.quantity) * COALESCE(sm.smallest_cbm, 0)) AS cbm_line_total
              FROM
                outbound_issues oi
              LEFT JOIN
                sku_master sm ON oi.sku_code = sm.sku_code AND oi.compcode = sm.compcode
              WHERE
                oi.issue_number = ?
                AND oi.compcode = ?
                AND oi.sku_code IS NOT NULL
                AND oi.quantity > 0
                AND oi.status = 'confirmed'
              GROUP BY
                oi.sku_code,
                oi.batch_number
              ORDER BY
                oi.sku_code ASC, oi.batch_number ASC";

$items_stmt = $conn->prepare($items_sql);
$issue_items_grouped = [];
$total_dispatched_qty_overall = 0;
$total_cbm_overall = 0;

if ($items_stmt) {
    $items_stmt->bind_param("ss", $final_gdn_number_for_items, $compcode);
    $items_stmt->execute();
    $items_result = $items_stmt->get_result();
    while ($row = $items_result->fetch_assoc()) {
        $issue_items_grouped[] = $row;
        $total_dispatched_qty_overall += $row['total_dispatched_quantity'];
        $total_cbm_overall += $row['cbm_line_total'];
    }
    $items_stmt->close();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Goods Dispatch Note (GDN) - <?= htmlspecialchars($issue_details['gdn_final_number']) ?></title>
    <style>
        /* Import Inter font - Required to fulfill user request while using internal CSS */
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');

        /* Print-specific settings */
        @page {
            size: A4;
            margin: 10mm;
        }

        body {
            font-family: 'Inter', Arial, sans-serif;
            font-size: 8pt;
            margin: 0;
            padding: 0;
            background-color: #fff;
        }

        .container {
            width: 190mm;
            margin: 0 auto;
            padding: 5mm;
        }

        /* 1. Warehouse Header (New Block) */
        .warehouse-header {
            text-align: center;
            padding-bottom: 10px;
            margin-bottom: 20px;
            border-bottom: 1px solid #ccc;
        }

        .warehouse-header .wh-name {
            font-size: 14pt;
            font-weight: 700;
            margin-bottom: 2px;
        }

        .warehouse-header .wh-address,
        .warehouse-header .wh-comp {
            font-size: 9pt;
            color: #555;
        }

        /* 2. Document Header */
        .document-header {
            text-align: center;
            border-bottom: 3px solid #000;
            padding-bottom: 5px;
            margin-bottom: 20px;
        }

        .document-header h1 {
            font-size: 18pt;
            margin: 0;
        }

        .document-header h2 {
            font-size: 11pt;
            margin: 5px 0 0 0;
            font-weight: 400;
            color: #333;
        }

        /* 3. Subtitle */
        .section-title {
            font-size: 11pt;
            font-weight: 700;
            margin: 15px 0 5px 0;
            padding: 5px 0;
            border-bottom: 1px solid #000;
        }

        /* 4. Info Blocks (Professional Grid Style) */
        .info-grid {
            border: 1px solid #ddd;
            width: 100%;
            margin-bottom: 20px;
            box-sizing: border-box;
            display: table;
        }

        .info-row {
            display: table-row;
        }

        .info-label,
        .info-value {
            display: table-cell;
            padding: 8px 12px;
            vertical-align: top;
            border-bottom: 1px solid #eee;
        }

        .info-label {
            width: 15%;
            font-weight: 600;
            background-color: #f9f9f9;
            border-right: 1px solid #ddd;
        }

        .info-value {
            width: 35%;
            border-right: 1px solid #ddd;
        }

        /* Remove borders for print neatness */
        .info-row:last-child .info-label,
        .info-row:last-child .info-value {
            border-bottom: none;
        }

        .info-row .info-value:nth-child(4) {
            border-right: none;
        }

        /* 5. Item Table Styles */
        .item-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            margin-bottom: 40px;
        }

        .item-table th,
        .item-table td {
            border: 1px solid #000;
            padding: 8px 10px;
            text-align: left;
        }

        .item-table th {
            background-color: #e6e6e6;
            font-weight: 600;
        }

        .item-table tfoot td {
            background-color: #f0f0f0;
            font-size: 11pt;
            font-weight: 700;
            border-top: 2px solid #000;
        }

        .text-right {
            text-align: right;
        }

        .text-center {
            text-align: center;
        }

        /* 6. Signature Block */
        .signature-block {
            width: 100%;
            margin-top: 50px;
            display: flex;
            justify-content: space-around;
            text-align: center;
        }

        .signature-block div {
            width: 90%;
            margin: 1vh;
        }

        .signature-line {
            border-top: 1px solid #000;
            height: 1px;
            width: 100%;
            margin: 50px 0 5px 0;
        }

        .signature-text {
            font-size: 9pt;
            margin: 0;
            /* font-weight: 600; */
        }

        /* 7. Footer (Fixed for printing) */
        .document-footer {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            width: 100%;
            text-align: center;
            font-size: 8pt;
            color: #555;
            padding: 5px 0;
            border-top: 1px solid #ddd;
            background-color: #fff;
        }

        /* 8. Non-Printable Elements */
        .no-print {
            position: fixed;
            bottom: 20px;
            right: 20px;
            padding: 10px 20px;
            background-color: #0969da;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            z-index: 999;
        }

        @media print {
            .no-print {
                display: none;
            }
        }
    </style>
</head>

<body>
    <div class="container">

        <div class="warehouse-header">
            <div class="wh-name"><?= htmlspecialchars($warehouse_details['wh_name'] ?? 'Warehouse Name Not Found') ?></div>
            <div class="wh-address">
                <?= htmlspecialchars($warehouse_details['wh_address1'] ?? 'Address Line 1 Not Found') ?>
                <?= !empty($warehouse_details['wh_address2']) ? ', ' . htmlspecialchars($warehouse_details['wh_address2']) : '' ?>
            </div>
            <div class="wh-comp">Company Code: <?= htmlspecialchars($compcode) ?> | Warehouse Code: <?= htmlspecialchars($wh_code) ?></div>
        </div>

        <div class="document-header">
            <h1>Goods Dispatch Note (GDN)</h1>
            <h2>GDN Type: <?= htmlspecialchars($issue_details['gdn_type']) ?> | Status: <?= strtoupper(htmlspecialchars($issue_details['status'])) ?></h2>
        </div>

        <div class="section-title">Dispatch Details</div>
        <div class="info-grid">
            <div class="info-row">
                <div class="info-label">GDN Final No:</div>
                <div class="info-value"><strong><?= htmlspecialchars($issue_details['gdn_final_number']) ?></strong></div>
                <div class="info-label">Issue Date:</div>
                <div class="info-value"><?= htmlspecialchars(substr($issue_details['created_at'], 0, 10)) ?></div>
            </div>
            <div class="info-row">
                <div class="info-label">Source Issue No:</div>
                <div class="info-value"><?= htmlspecialchars($issue_details['issue_number']) ?></div>
                <div class="info-label">Vehicle Details:</div>
                <div class="info-value"><?= htmlspecialchars($issue_details['vehicle_details']) ?></div>
            </div>
            <div class="info-row">
                <div class="info-label">Loading Start:</div>
                <div class="info-value"></div>
                <div class="info-label">Loading End</div>
                <div class="info-value"></div>
            </div>
        </div>

        <div class="section-title">Customer/Delivery Address</div>
        <div class="info-grid">
            <div class="info-row">
                <div class="info-label">Customer:</div>
                <div class="info-value"><strong><?= htmlspecialchars($issue_details['customer_name']) ?></strong></div>
                <div class="info-label">Customer Code:</div>
                <div class="info-value"><strong><?= htmlspecialchars($issue_details['customer_code']) ?></strong></div>
            </div>
            <div class="info-row">
                <div class="info-label">Delivery Address:</div>
                <div class="info-value" colspan="3">
                    <?= htmlspecialchars($issue_details['address1']) ?><br>
                    <?= !empty($issue_details['address2']) ? htmlspecialchars($issue_details['address2']) . '<br>' : '' ?>
                    <?= !empty($issue_details['address3']) ? htmlspecialchars($issue_details['address3']) : '' ?>
                </div>
            </div>
            <div class="info-row">
                <div class="info-label">Contact No:</div>
                <div class="info-value"><?= htmlspecialchars($issue_details['tel']) ?> / <?= htmlspecialchars($issue_details['fax']) ?></div>
                <div class="info-label">Email:</div>
                <div class="info-value"><?= htmlspecialchars($issue_details['email']) ?></div>
            </div>
        </div>

        <table class="item-table">
            <thead>
                <tr>
                    <th style="width: 5%;">#</th>
                    <th style="width: 20%;">SKU Code</th>
                    <th>Description</th>
                    <th style="width: 15%;">Batch/LOT No</th>
                    <th style="width: 15%;">EXD</th>
                    <th style="width: 10%;" class="text-right">Quantity</th>
                    <th style="width: 10%;" class="text-right">Total CBM</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($issue_items_grouped)): ?>
                    <?php $count = 1;
                    foreach ($issue_items_grouped as $item): ?>
                        <tr>
                            <td><?= $count++ ?></td>
                            <td><?= htmlspecialchars($item['sku_code']) ?></td>
                            <td><?= htmlspecialchars($item['sku_description']) ?></td>
                            <td><?= htmlspecialchars($item['batch_number']) ?></td>
                            <td><?= htmlspecialchars($item['exd']) ?></td>
                            <td class="text-right"><?= (int)$item['total_dispatched_quantity'] ?></td>
                            <td class="text-right"><?= number_format($item['cbm_line_total'], 4) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center">No items confirmed for dispatch.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="5" class="text-right"><strong>Overall Total:</strong></td>
                    <td class="text-right"><strong><?= (int)$total_dispatched_qty_overall ?></strong></td>
                    <td class="text-right"><strong><?= number_format($total_cbm_overall, 4) ?></strong></td>
                </tr>
            </tfoot>
        </table>

        <div class="signature-block">
            <div>
                <div class="signature-line"></div>
                <p class="signature-text">Prepared By: (<?= htmlspecialchars($_SESSION['username']) ?>)</p>
            </div>
            <div>
                <div class="signature-line"></div>
                <p class="signature-text">Confirmed By (Warehouse)</p>
            </div>
            <div>
                <div class="signature-line"></div>
                <p class="signature-text">Received By (Customer/Carrier)</p>
            </div>
        </div>
        <div class="remarks" style="margin-top: 2vh;">
            Remarks:
        </div>
    </div>
    
    <div class="document-footer">
        Document generated by Zynex WMS. Designed and developed by Zynex Solutions 2019-2025.
    </div>

    <button class="no-print" onclick="window.print()">Print GDN</button>

</body>

</html>