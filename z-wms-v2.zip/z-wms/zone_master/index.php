<?php
session_start();
require '../inc/db.php';

// Check if the user is logged in
if (empty($_SESSION['username']) || empty($_SESSION['compcode']) || empty($_SESSION['wh_code'])) {
    header("Location: ../");
    exit();
}

// Variables for form feedback
$message = '';
$isSuccess = false;
$wh_code_session = $_SESSION['wh_code'];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $zone_code = trim($_POST['zone_code']);
    $zone_name = trim($_POST['zone_name']);
    $selective_type = $_POST['selective_type'];
    $status = $_POST['status'];

    if (!empty($zone_code) && !empty($zone_name) && !empty($selective_type) && !empty($status)) {
        // Prepare the INSERT statement
        $stmt = $conn->prepare("INSERT INTO zone_master (wh_code, zone_code, zone_name, selective_type, status) VALUES (?, ?, ?, ?, ?)");
        if ($stmt) {
            $stmt->bind_param("sssss", $wh_code_session, $zone_code, $zone_name, $selective_type, $status);

            if ($stmt->execute()) {
                $message = "Record inserted successfully!";
                $isSuccess = true;
            } else {
                // Check for duplicate key error
                if ($conn->errno === 1062) {
                    $message = "Error: A zone with this code already exists for this warehouse.";
                } else {
                    $message = "Error inserting record: " . $stmt->error;
                }
            }
            $stmt->close();
        } else {
            $message = "Database prepare statement failed: " . $conn->error;
        }
    } else {
        $message = "All fields are required.";
    }
}

// Fetch all records for the current warehouse
$zones = [];
$query = "SELECT * FROM zone_master WHERE wh_code = ? ORDER BY zone_code ASC";
$stmt = $conn->prepare($query);
if ($stmt) {
    $stmt->bind_param("s", $wh_code_session);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $zones[] = $row;
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Zynex WMS | Zone Master</title>
    <link rel="stylesheet" href="../inc/global.css">

    <style>
        .main {
            width: 85%;
            overflow: visible;
        }
    </style>

</head>

<body>

    <?php require '../parts/nav.php'; // Your navigation file 
    ?>

    <div id="main" class="main">
        <div class="zone-module">
            <h1>Zone Master</h1>
            <p style="color: var(--color-text-secondary);">
                Warehouse Code: <strong><?= htmlspecialchars($wh_code_session) ?></strong>
            </p>

            <?php if (!empty($message)): ?>
                <div class="message <?= $isSuccess ? 'alert-success' : 'alert-danger' ?>">
                    <?= htmlspecialchars($message) ?>
                </div>
            <?php endif; ?>

            <div class="card">
                <h2>Add New Zone</h2>
                <form action="" method="post">
                    <div class="form-grid">
                        <div class="input-group">
                            <label for="zone_code">Zone Code</label>
                            <input type="text" id="zone_code" name="zone_code" required autofocus>
                        </div>
                        <div class="input-group">
                            <label for="zone_name">Zone Name</label>
                            <input type="text" id="zone_name" name="zone_name" required>
                        </div>
                        <div class="input-group">
                            <label for="selective_type">Zone Type</label>
                            <select id="selective_type" name="selective_type" required>
                                <option value="">-- Select Type --</option>
                                <option value="Aisle">Aisle</option>
                                <option value="Rack">Rack</option>
                                <option value="Level">Level (e.g., A, B, C)</option>
                                <option value="Bin">Bin/Slot</option>
                                <option value="Bulk/Floor">Bulk/Floor Storage</option>
                                <option value="Selective">Selective Pallet</option>
                                <option value="Double Deep">Double Deep Pallet</option>
                                <option value="Drive-In/Through">Drive-In/Through</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <div class="input-group">
                            <label for="status">Status</label>
                            <select id="status" name="status" required>
                                <option value="Active">Active</option>
                                <option value="Inactive">Inactive</option>
                            </select>
                        </div>
                    </div>
                    <button type="submit" class="action-button" style="margin-top: 20px;">Add Zone</button>
                </form>
            </div>

            <div class="card">
                <h2>Available Zones</h2>
                <?php if (empty($zones)): ?>
                    <p style="color: var(--color-text-secondary);">No zones found for this warehouse.</p>
                <?php else: ?>
                    <div style="overflow-x: auto;">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Zone Code</th>
                                    <th>Zone Name</th>
                                    <th>Zone Type</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($zones as $zone): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($zone['zone_code']) ?></td>
                                        <td><?= htmlspecialchars($zone['zone_name']) ?></td>
                                        <td><?= htmlspecialchars($zone['selective_type']) ?></td>
                                        <td><span class="<?= $zone['status'] === 'Active' ? 'status-on' : 'status-off' ?>"><?= htmlspecialchars($zone['status']) ?></span></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

</body>

</html>