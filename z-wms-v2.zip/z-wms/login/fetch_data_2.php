<?php
header('Content-Type: application/json');
require '../inc/db.php'; // Adjust path as needed

$response = [
    'compcodes' => []
];

if (isset($_POST['username']) && isset($_POST['wh_code'])) {
    $username = trim($_POST['username']);
    $wh_code = trim($_POST['wh_code']);

    // Fetch unique company codes for the given username and warehouse code
    $query_comp = "SELECT DISTINCT compcode FROM users_db WHERE username = ? AND wh_code = ?";
    $stmt_comp = $conn->prepare($query_comp);
    if ($stmt_comp) {
        $stmt_comp->bind_param("ss", $username, $wh_code);
        $stmt_comp->execute();
        $result_comp = $stmt_comp->get_result();
        while ($row = $result_comp->fetch_assoc()) {
            $response['compcodes'][] = $row['compcode'];
        }
    }
}

echo json_encode($response);
$conn->close();
