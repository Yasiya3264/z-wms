<?php
header('Content-Type: application/json');
require '../inc/db.php'; // Adjust path as needed

$response = [
    'wh_codes' => []
];

if (isset($_POST['username'])) {
    $username = trim($_POST['username']);

    // Fetch unique warehouse codes for the given username
    $query_wh = "SELECT DISTINCT wh_code FROM users_db WHERE username = ?";
    $stmt_wh = $conn->prepare($query_wh);
    if ($stmt_wh) {
        $stmt_wh->bind_param("s", $username);
        $stmt_wh->execute();
        $result_wh = $stmt_wh->get_result();
        while ($row = $result_wh->fetch_assoc()) {
            $response['wh_codes'][] = $row['wh_code'];
        }
    }
}

echo json_encode($response);
$conn->close();
