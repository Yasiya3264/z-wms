<?php
session_start();
require '../inc/db.php'; // Adjust path as needed

// Show all errors (for development only)
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $wh_code = trim($_POST['wh_code']);
    $compcode = trim($_POST['compcode']);
    $password = trim($_POST['password']);

    if ($username && $wh_code && $compcode && $password) {
        // Query to check if the user exists with the provided credentials
        $query = "SELECT * FROM users_db WHERE username = ? AND wh_code = ? AND compcode = ?";
        $stmt = $conn->prepare($query);
        if ($stmt) {
            $stmt->bind_param("sss", $username, $wh_code, $compcode);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result && $result->num_rows === 1) {
                $user = $result->fetch_assoc();

                // Check status and verify hashed password
                if (strtolower($user['status']) === 'active' && password_verify($password, $user['password'])) {
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['wh_code'] = $user['wh_code'];
                    $_SESSION['compcode'] = $user['compcode'];

                    header("Location: ../");
                    exit();
                } else {
                    $error = "Incorrect password or inactive user.";
                }
            } else {
                $error = "User, warehouse, or company combination is incorrect.";
            }
        } else {
            $error = "Database query failed.";
        }
    } else {
        $error = "All fields are required.";
    }

    // Redirect back with error
    header("Location: index.php?error=" . urlencode($error));
    exit();
}

// If not a POST request, redirect back to the login page
header("Location: index.php");
exit();
