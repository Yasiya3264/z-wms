<?php
session_start();

require '../inc/db.php';

if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    header("Location: ../");
    exit();
}

// Fetch data
$locations = [];
$wh_code_session = $_SESSION['wh_code'];
$result = $conn->query("SELECT * FROM warehouse_locations ORDER BY id ASC");
while ($row = $result->fetch_assoc()) {
    $locations[] = $row;
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Zynex WMS | Location Master</title>

    <link rel="stylesheet" href="../inc/global.css">
    <style>
        .main {
            width: 85%;
            overflow: visible;
        }

        .form-container {
            display: grid;
            grid-template-columns: 220px 1fr;
            gap: 15px 10px;
            max-width: 650px;
            margin-bottom: 20px;
        }

        .form-container label {
            display: block;
            margin-bottom: 0;
            font-weight: 600;
            font-size: 14px;
            color: var(--color-text-primary);
            text-align: right;
            align-self: start;
            padding-top: 8px;
        }

        .input-wrapper {
            display: flex;
            align-items: center;
            gap: 5px;
        }

        input[type="text"],
        input[type="number"],
        select,
        textarea {
            width: 100%;
            padding: 8px 12px;
            box-sizing: border-box;
            border: 1px solid var(--color-border);
            border-radius: 6px;
            background-color: var(--color-bg-secondary);
            color: var(--color-text-primary);
            transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
            appearance: none;
        }

        input:focus,
        select:focus,
        textarea:focus {
            border-color: var(--color-accent-blue);
            outline: none;
            box-shadow: 0 0 0 3px var(--color-focus-shadow);
        }

        .input-range {
            width: 100px;
        }

        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .checkbox-group input[type="checkbox"] {
            width: auto;
            padding: 0;
            margin: 0;
            min-width: unset;
        }

        .status-on {
            color: var(--color-status-on);
            font-weight: 600;
        }

        .status-off {
            color: var(--color-status-off);
        }

        .data-table .filter-row th:first-child input {
            width: 60px !important;
        }

        .data-table .filter-row th:last-child input {
            width: 100px !important;
        }

        #result {
            margin-top: 20px;
            padding: 10px;
            white-space: pre-wrap;
            background-color: var(--color-bg-secondary);
            border: 1px solid var(--color-border);
            border-radius: 6px;
            font-family: monospace;
            font-size: 14px;
        }

        .data-table tfoot td {
            background-color: var(--color-bg-primary);
            border-top: 2px solid var(--color-border);
            border-bottom: none;
            color: var(--color-text-primary);
        }
    </style>
</head>

<body>

    <?php require '../parts/nav.php'; ?>

    <div id="main" class="main">
        <div class="module-container">
            <h2>Warehouse Rack Location Generator</h2>
            <p style="color: var(--color-text-secondary);">
                Warehouse Code: <strong><?= htmlspecialchars($wh_code_session) ?></strong>
            </p>

            <div class="card">
                <h3>Location Creation Parameters</h3>
                <div class="form-container">
                    <label for="zone_code">Rack Zone Codes:</label>
                    <div class="input-wrapper">
                        <?php
                        $wh_code = $_SESSION['wh_code'];

                        $sql = "SELECT zone_code, zone_name FROM zone_master WHERE wh_code = ?";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("s", $wh_code); // "s" = string type
                        $stmt->execute();
                        $result = $stmt->get_result();
                        ?>

                        <select name="zone_code" id="zone_code">
                            <option value="">-- Select Zone --</option>
                            <?php while ($row = $result->fetch_assoc()) { ?>
                                <option value="<?php echo htmlspecialchars($row['zone_code']); ?>">
                                    <?php echo htmlspecialchars($row['zone_code']) . " | " . htmlspecialchars($row['zone_name']); ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>

                    <label for="zones">Color Zone Codes:</label>
                    <div class="input-wrapper">
                        <input type="text" id="zones" placeholder="(comma separated)">
                    </div>

                    <label for="racks">Racks per Zone:</label>
                    <div class="input-wrapper">
                        <input type="number" id="racks" value="1" class="input-range">
                    </div>

                    <label for="position_start">Positions per Rack:</label>
                    <div class="input-wrapper">
                        <input type="number" id="position_start" value="1" class="input-range"> to
                        <input type="number" id="position_end" value="1" class="input-range">
                    </div>

                    <label for="level_start">Levels per Position:</label>
                    <div class="input-wrapper">
                        <input type="number" id="level_start" value="1" class="input-range"> to
                        <input type="number" id="level_end" value="1" class="input-range">
                    </div>

                    <label for="length">Length (M):</label>
                    <div class="input-wrapper">
                        <input type="number" id="length" value="">
                    </div>

                    <label for="width">Width (M):</label>
                    <div class="input-wrapper">
                        <input type="number" id="width" value="">
                    </div>

                    <label for="height">Height (M):</label>
                    <div class="input-wrapper">
                        <input type="number" id="height" value="">
                    </div>

                    <label for="occupancy">Occupancy Type:</label>
                    <div class="input-wrapper">
                        <select id="occupancy">
                            <option value="Actual">Actual</option>
                            <option value="Virtual">Virtual</option>
                        </select>
                    </div>

                    <label for="status">Status:</label>
                    <div class="checkbox-group">
                        <input type="checkbox" id="status" checked> Active
                    </div>
                </div>

                <button onclick="generateAndSend()" class="action-button">Generate + Insert</button>
            </div>

            <div id="result"></div>

            <script>
                function pad(n) {
                    return n.toString().padStart(2, '0');
                }

                function generateAndSend() {
                    const zone_code = document.getElementById("zone_code").value;
                    const zones = document.getElementById("zones").value.split(',').map(z => z.trim());
                    const racks = parseInt(document.getElementById("racks").value);

                    const position_start = parseInt(document.getElementById("position_start").value);
                    const position_end = parseInt(document.getElementById("position_end").value);
                    const level_start = parseInt(document.getElementById("level_start").value);
                    const level_end = parseInt(document.getElementById("level_end").value);

                    const length = parseFloat(document.getElementById("length").value);
                    const width = parseFloat(document.getElementById("width").value);
                    const height = parseFloat(document.getElementById("height").value);
                    const cbm = (length * width * height);

                    const occupancy = document.getElementById("occupancy").value;
                    const status = document.getElementById("status").checked ? 1 : 0;

                    let results = [];

                    zones.forEach(zone => {
                        for (let r = 1; r <= racks; r++) {
                            for (let p = position_start; p <= position_end; p++) {
                                for (let l = level_start; l <= level_end; l++) {
                                    const location_code = `${zone}-${pad(r)}-${pad(p)}-${pad(l)}`;

                                    fetch('insert_location.php', {
                                            method: 'POST',
                                            headers: {
                                                'Content-Type': 'application/json'
                                            },
                                            body: JSON.stringify({
                                                zone_code,
                                                location_code,
                                                length,
                                                width,
                                                height,
                                                cbm,
                                                occupancy,
                                                status
                                            })
                                        })
                                        .then(res => res.text())
                                        .then(data => {
                                            results.push(`${location_code}: ${data}`);
                                            document.getElementById("result").innerText = results.join('\n');
                                        });
                                }
                            }
                        }
                    });
                }
            </script>

            <div class="card">
                <h3>Existing Warehouse Locations</h3>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Zone Code</th>
                            <th>Code</th>
                            <th>Length</th>
                            <th>Width</th>
                            <th>Height</th>
                            <th>CBM</th>
                            <th>Occupancy</th>
                            <th>Status</th>
                        </tr>
                        <tr class="filter-row">
                            <th><input type="text" class="filter" data-index="0" placeholder="Filter ID"></th>
                            <th><input type="text" class="filter" data-index="1" placeholder="Zone Code"></th>
                            <th><input type="text" class="filter" data-index="2" placeholder="Filter Code"></th>
                            <th><input type="text" class="filter" data-index="3" placeholder="Filter L"></th>
                            <th><input type="text" class="filter" data-index="4" placeholder="Filter W"></th>
                            <th><input type="text" class="filter" data-index="5" placeholder="Filter H"></th>
                            <th><input type="text" class="filter" data-index="6" placeholder="Filter CBM"></th>
                            <th><input type="text" class="filter" data-index="7" placeholder="Filter Occupancy"></th>
                            <th><input type="text" class="filter" data-index="8" placeholder="Filter Status"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($locations as $loc): ?>
                            <tr>
                                <td><?= "#" . $loc['id'] ?></td>
                                <td><?= $loc['zone_code'] ?></td>
                                <td><?= $loc['location_code'] ?></td>
                                <td><?= $loc['length_cm'] ?></td>
                                <td><?= $loc['width_cm'] ?></td>
                                <td><?= $loc['height_cm'] ?></td>
                                <td><?= $loc['cbm'] ?></td>
                                <td><?= $loc['occupancy_type'] ?></td>
                                <td class="<?= $loc['status'] ? 'status-on' : 'status-off' ?>">
                                    <?= $loc['status'] ? 'Active' : 'Inactive' ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="9" style="text-align:right; font-weight:bold;">
                                Total Records: <?= count($locations) ?>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>



    <script>
        document.querySelectorAll(".filter").forEach(input => {
            input.addEventListener("input", function() {
                const table = input.closest("table");
                const rows = table.querySelectorAll("tbody tr");
                const filters = Array.from(table.querySelectorAll(".filter")).map(i => i.value.toLowerCase());

                rows.forEach(row => {
                    const cells = Array.from(row.children);
                    const visible = filters.every((filter, i) => {
                        return cells[i].textContent.toLowerCase().includes(filter);
                    });
                    row.style.display = visible ? "" : "none";
                });
            });
        });
    </script>

</body>

</html>