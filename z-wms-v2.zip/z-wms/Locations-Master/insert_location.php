<?php
session_start();

require '../inc/db.php';

$data = json_decode(file_get_contents("php://input"), true);

// Get both zone_code and location_code from the POST data
$zone_code = $data['zone_code'];
$location_code = $data['location_code'];

// The rest of the data
$length = floatval($data['length']);
$width = floatval($data['width']);
$height = floatval($data['height']);
$cbm = floatval($data['cbm']);
$occupancy = $data['occupancy'];
$status = intval($data['status']);

// Get the warehouse code from the session
$wh_code = $_SESSION['wh_code'];

// Use prepared statements to prevent SQL injection and fix the foreign key constraint
$sql = "INSERT INTO warehouse_locations 
  (zone_code, location_code, length_cm, width_cm, height_cm, cbm, occupancy_type, status, wh_code) 
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ssddddsis", $zone_code, $location_code, $length, $width, $height, $cbm, $occupancy, $status, $wh_code);

if ($stmt->execute()) {
  echo "✅ Success!";
} else {
  echo "❌ Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
