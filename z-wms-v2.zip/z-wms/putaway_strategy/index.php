<?php
session_start();
require '../inc/db.php';

if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    header("Location: ../");
    exit();
}

$compcode = $_SESSION['compcode'];
$wh_code = $_SESSION['wh_code'];

// Fetch existing putaway strategies for the user's company and warehouse
$strategies = [];
$sql_strategies = "SELECT ps.id, ps.priority, zm.zone_code, zm.zone_name 
                   FROM putaway_strategy ps
                   INNER JOIN zone_master zm ON ps.zone_code = zm.zone_code AND ps.wh_code = zm.wh_code
                   WHERE ps.compcode = ? AND ps.wh_code = ? ORDER BY ps.priority ASC";
$stmt_strategies = $conn->prepare($sql_strategies);
$stmt_strategies->bind_param("ss", $compcode, $wh_code);
$stmt_strategies->execute();
$result_strategies = $stmt_strategies->get_result();
while ($row = $result_strategies->fetch_assoc()) {
    $strategies[] = $row;
}
$stmt_strategies->close();

// Fetch zone codes for the dropdown list, filtered by warehouse code
$zones = [];
$sql_zones = "SELECT zone_code, zone_name FROM zone_master WHERE wh_code = ? ORDER BY zone_code ASC";
$stmt_zones = $conn->prepare($sql_zones);
$stmt_zones->bind_param("s", $wh_code);
$stmt_zones->execute();
$result_zones = $stmt_zones->get_result();
while ($row = $result_zones->fetch_assoc()) {
    $zones[] = $row;
}
$stmt_zones->close();
// Note: Assuming $conn is not closed here as it might be used by other included files later
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Zynex WMS | Putaway Strategy</title>

    <link rel="stylesheet" href="../inc/global.css">

    <style>
        .main {
            width: 85%;
            overflow: visible;
        }

        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }

        .modal-content {
            background: var(--color-bg-secondary);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 90%;
            color: var(--color-text-primary);
        }

        .modal-actions {
            margin-top: 15px;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
    </style>
</head>

<body>

    <?php require '../parts/nav.php'; ?>

    <div id="main" class="main">
        <div class="strategy-module"> 
            <h1>Putaway Strategy Master</h1>
            <p style="color: var(--color-text-secondary);">
                Warehouse Code: <strong><?= htmlspecialchars($wh_code) ?></strong>
            </p>

            <div class="card">
                <h2>Define New Strategy</h2>
                <form id="strategyForm">
                    <div class="input-group"> 
                        <label for="zone_code">Zone Code:</label>
                        <select id="zone_code" name="zone_code" required>
                            <option value="">-- Select Zone --</option>
                            <?php foreach ($zones as $zone): ?>
                                <option value="<?= htmlspecialchars($zone['zone_code']) ?>">
                                    <?= htmlspecialchars($zone['zone_code']) . " | " . htmlspecialchars($zone['zone_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="input-group"> 
                        <label for="priority">Priority (0-1000):</label>
                        <input type="number" id="priority" name="priority" min="0" max="1000" required>
                    </div>
                    <button type="submit">Save Strategy</button>
                </form>
                <div id="status-message" style="margin-top: 10px;"></div>
            </div>

            <div class="card">
                <h2>Existing Strategies</h2>
                <?php if (!empty($strategies)): ?>
                    <div style="overflow-x: auto;">
                        <table class="data-table"> 
                            <thead>
                                <tr>
                                    <th>Priority</th>
                                    <th>Zone Code</th>
                                    <th>Zone Name</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($strategies as $strategy): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($strategy['priority']) ?></td>
                                        <td><?= htmlspecialchars($strategy['zone_code']) ?></td>
                                        <td><?= htmlspecialchars($strategy['zone_name']) ?></td>
                                        <td>
                                            <button class="action-button delete" onclick="showDeleteModal(<?= $strategy['id'] ?>)">Delete</button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p style="color: var(--color-text-secondary);">No putaway strategies found for your company and warehouse.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div id="deleteModal" class="modal-overlay">
        <div class="modal-content">
            <h3>Confirm Deletion</h3>
            <p>Are you sure you want to delete this putaway strategy?</p>
            <div class="modal-actions">
                <button class="action-button" onclick="hideModal('deleteModal')">Cancel</button>
                <button class="action-button delete" id="confirmDeleteButton">Delete</button>
            </div>
        </div>
    </div>


    <script>
        function showModal(modalId, actionCallback) {
            const modal = document.getElementById(modalId);
            modal.style.display = 'flex';
            if (actionCallback) {
                const confirmBtn = document.getElementById('confirmDeleteButton');
                if (modalId === 'deleteModal') {
                    confirmBtn.onclick = () => {
                        actionCallback();
                        hideModal(modalId);
                    };
                }
            }
        }

        function hideModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        let strategyToDeleteId = null;

        function showDeleteModal(id) {
            strategyToDeleteId = id;
            showModal('deleteModal', executeDeleteStrategy);
        }

        function showMessageModal(message, isError = false) {
            const statusMessage = document.getElementById('status-message');
            statusMessage.innerHTML = `<div class="message ${isError ? 'alert-danger' : 'alert-success'}">${message}</div>`;
            setTimeout(() => statusMessage.innerHTML = '', 4000);
        }

        const form = document.getElementById('strategyForm');

        form.addEventListener('submit', async (e) => {
            e.preventDefault();

            const zone_code = document.getElementById('zone_code').value;
            const priority = document.getElementById('priority').value;

            try {
                const response = await fetch('create_strategy.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        zone_code,
                        priority
                    })
                });

                const result = await response.text();

                if (response.ok) {
                    showMessageModal(result, false);
                    form.reset();
                    setTimeout(() => {
                        window.location.reload();
                    }, 1000);
                } else {
                    showMessageModal(result, true);
                }
            } catch (error) {
                showMessageModal('An unexpected error occurred during creation.', true);
            }
        });

        async function executeDeleteStrategy() {
            const id = strategyToDeleteId;
            if (!id) return;

            try {
                const response = await fetch('delete_strategy.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        id
                    })
                });

                const result = await response.text();

                if (response.ok) {
                    showMessageModal(result, false);
                    window.location.reload();
                } else {
                    showMessageModal(result, true);
                }
            } catch (error) {
                showMessageModal('An unexpected error occurred during deletion.', true);
            }
        }
    </script>
</body>

</html>