<?php
session_start();
require '../inc/db.php';

if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    http_response_code(401);
    echo "Unauthorized access.";
    exit();
}

$data = json_decode(file_get_contents("php://input"), true);
$id = $data['id'];

// Get company and warehouse codes from the session for security
$compcode = $_SESSION['compcode'];
$wh_code = $_SESSION['wh_code'];

if (!isset($id)) {
    http_response_code(400);
    echo "Invalid request. Missing strategy ID.";
    exit();
}

// Use a prepared statement to prevent SQL injection
// and ensure the user can only delete strategies for their company and warehouse
$sql = "DELETE FROM putaway_strategy WHERE id = ? AND compcode = ? AND wh_code = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("iss", $id, $compcode, $wh_code);

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        echo "Strategy deleted successfully!";
    } else {
        http_response_code(404);
        echo "Strategy not found or you do not have permission to delete it.";
    }
} else {
    http_response_code(500);
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
