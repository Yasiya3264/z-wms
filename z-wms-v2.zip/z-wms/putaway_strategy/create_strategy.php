<?php
session_start();
require '../inc/db.php';

if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    http_response_code(401);
    echo "Unauthorized access.";
    exit();
}

$data = json_decode(file_get_contents("php://input"), true);

$compcode = $_SESSION['compcode'];
$wh_code = $_SESSION['wh_code'];
$zone_code = $data['zone_code'];
$priority = intval($data['priority']);

// Check for existing strategy for the same zone
$check_sql = "SELECT id FROM putaway_strategy WHERE compcode = ? AND wh_code = ? AND zone_code = ?";
$check_stmt = $conn->prepare($check_sql);
$check_stmt->bind_param("sss", $compcode, $wh_code, $zone_code);
$check_stmt->execute();
$check_result = $check_stmt->get_result();

if ($check_result->num_rows > 0) {
    http_response_code(409); // Conflict
    echo "A putaway strategy for this zone already exists. Please delete the old one first.";
    $check_stmt->close();
    $conn->close();
    exit();
}
$check_stmt->close();

// Insert the new strategy using prepared statements
$insert_sql = "INSERT INTO putaway_strategy (compcode, wh_code, zone_code, priority) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($insert_sql);
$stmt->bind_param("sssi", $compcode, $wh_code, $zone_code, $priority);

if ($stmt->execute()) {
    echo "Putaway strategy saved successfully!";
} else {
    http_response_code(500);
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
