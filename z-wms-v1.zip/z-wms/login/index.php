<?php
// Start session if not already started
session_start();

// Capture error if redirected from login
$error = $_GET['error'] ?? '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Zynex WMS | Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../inc/global.css">
  <link rel="stylesheet" href="./styles.css">
</head>
<body>

<section>
  <div class="form_container">
    <form action="login.php" method="post">
      <h1>Z-WMS</h1>
      <p>Advanced warehouse management system</p>

      <?php if ($error): ?>
        <div class="error" style="color:red; margin-bottom: 10px;">
          <?= htmlspecialchars($error) ?>
        </div>
      <?php endif; ?>

      <div class="input_group">
        <label for="username">User Name</label>
        <input type="text" name="username" id="username" required autofocus>
      </div>

      <div class="input_group">
        <label for="compcode">Company Code</label>
        <input type="text" name="compcode" id="compcode" required>
      </div>

      <div class="input_group">
        <label for="password">Password</label>
        <input type="password" name="password" id="password" required>
      </div>

      <div class="action_group">
        <button type="submit">Login</button>
      </div>
    </form>
  </div>
</section>

<footer></footer>
</body>
</html>
