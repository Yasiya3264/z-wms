    <style>
        .topnav {
            display: none;
            background-color: var(--dashnav);
            color: var(--main-bg);
            padding: 14px 20px;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 2;
        }

        .topnav button {
            background: none;
            color: var(--main-bg);
            font-size: 24px;
            border: none;
            cursor: pointer;
        }

        .sidenav {
            height: 100vh;
            width: 220px;
            background-color: var(--dashnav);
            position: fixed;
            top: 0;
            left: 0;
            padding-top: 60px;
            overflow-y: auto;
            transition: transform 0.3s ease-in-out;
        }

        .sidenav a {
            display: block;
            color: white;
            padding: 14px 20px;
            text-decoration: none;
            font-size: 16px;
            transition: background-color 0.2s;
        }

        .sidenav a:hover {
            background-color: var(--btn-prim);
        }

        .main {
            margin-left: 220px;
            padding: 20px;
            transition: margin-left 0.3s;
        }

        /* Hide sidebar on mobile */
        @media (max-width: 768px) {
            .topnav {
                display: flex;
                align-items: center;
            }

            .sidenav {
                transform: translateX(-100%);
                z-index: 3;
            }

            .sidenav.open {
                transform: translateX(0);
            }

            .main {
                margin-left: 0;
                padding-top: 60px;
            }

            .main.shifted {
                margin-left: 220px;
            }
        }
    </style>    
    
    
    <div class="topnav">
        <button onclick="toggleNav()">☰</button>
        <span style="margin-left: 10px;">Menu</span>
    </div>

    <div id="sidenav" class="sidenav">
        <a href="../SKU-Master/">SKU Master</a>
        <a href="../Locations-Master/">Locations Master</a>
        <a href="../customer-master/">Customers Master</a>
        <a href="../inbound/">Inbound</a>
        <a href="../outbound/">Outbound</a>
        <a href="../inventory/">Inventory</a>
        <a href="../inventory-transfer/">Inventory Transfer</a>
        <a href="../inbound-history/">Inbound History</a>
        <a href="../outbound-history/">Outbound History</a>
        <a href="../transfer-history/">INT-Transfer History</a>
    </div>



    <script>
        function toggleNav() {
            const sidenav = document.getElementById("sidenav");
            const main = document.getElementById("main");
            sidenav.classList.toggle("open");
            main.classList.toggle("shifted");
        }
    </script>