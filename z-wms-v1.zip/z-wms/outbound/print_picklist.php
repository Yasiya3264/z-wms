<?php
session_start();
require '../inc/db.php';

if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    header("Location: ../");
    exit();
}

$compcode = $_SESSION['compcode'];
$issue_id = isset($_GET['issue_id']) ? (int)$_GET['issue_id'] : 0;

if ($issue_id <= 0) {
    die("Invalid Issue ID.");
}

// Fetch Issue Header Details
// Get the current manual issue number from the header row (must be in 'draft' status for picklist)
$header_sql = "SELECT oi.issue_number, oi.gdn_type, oi.customer_code, cm.customer_name, oi.vehicle_details, oi.created_at, oi.status
               FROM outbound_issues oi
               JOIN customers_master cm ON oi.customer_code = cm.customer_code AND oi.compcode = cm.compcode
               WHERE oi.id = ? AND oi.compcode = ? AND oi.sku_code IS NULL AND oi.status = 'draft'"; // Picklist is for draft issues
$header_stmt = $conn->prepare($header_sql);
$issue_details = null;
if ($header_stmt) {
    $header_stmt->bind_param("is", $issue_id, $compcode);
    $header_stmt->execute();
    $header_result = $header_stmt->get_result();
    if ($header_result->num_rows > 0) {
        $issue_details = $header_result->fetch_assoc();
    }
    $header_stmt->close();
}

if (!$issue_details) {
    die("Issue details not found, unauthorized, or already confirmed (Pick List is for Drafts).");
}

// Use the manual issue_number from the fetched header to get its items
$manual_issue_number = $issue_details['issue_number'];

// Fetch Issue Items for Pick List
$items_sql = "SELECT oi.sku_code, sm.sku_description, oi.batch_number, oi.exd, oi.location_code, oi.quantity AS pick_quantity, 
                     i.in_hand_qty AS current_in_hand_qty, sm.smallest_cbm 
              FROM outbound_issues oi
              LEFT JOIN sku_master sm ON oi.sku_code = sm.sku_code AND oi.compcode = sm.compcode
              LEFT JOIN inventory i ON oi.sku_code = i.sku_code 
                                    AND oi.batch_number = i.batch_number 
                                    AND oi.location_code = i.location_code 
                                    AND oi.compcode = i.compcode
              WHERE oi.issue_number = ? AND oi.compcode = ? AND oi.sku_code IS NOT NULL AND oi.quantity > 0 AND oi.status = 'draft'
              ORDER BY oi.location_code ASC, oi.sku_code ASC";

$items_stmt = $conn->prepare($items_sql);
$issue_items = [];
if ($items_stmt) {
    $items_stmt->bind_param("ss", $manual_issue_number, $compcode);
    $items_stmt->execute();
    $items_result = $items_stmt->get_result();
    while ($row = $items_result->fetch_assoc()) {
        $issue_items[] = $row;
    }
    $items_stmt->close();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pick List - <?= htmlspecialchars($issue_details['issue_number']) ?></title>
    <link rel="stylesheet" href="../inc/global.css">
    <style>
        body {
            margin: 20px;
            font-size: 12px;
        }

        .header,
        .footer {
            width: 100%;
            margin-bottom: 20px;
        }

        .header div {
            margin-bottom: 5px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #000;
            padding: 6px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .text-right {
            text-align: right;
        }

        .text-center {
            text-align: center;
        }

        .signature-block {
            margin-top: 50px;
            display: flex;
            justify-content: space-around;
            width: 100%;
        }

        .signature-line {
            border-top: 1px solid #000;
            width: 200px;
            text-align: center;
            padding-top: 5px;
        }

        button {
            padding: 0.1rem 1rem;
            font-size: 16px;
            background-color: var(--btn-prim);
            color: var(--btn-text, #fff);
            font-weight: 400;
            border: 1px solid var(--btn-prim);
            border-radius: 5px;
            transition: 0.4s;
            cursor: pointer;
            margin-top: 2vh;
        }

        button:hover {
            background-color: var(--btn-hover);
        }

        @media print {
            /* body {
                -webkit-print-color-adjust: exact;
            } */

            .no-print {
                display: none;
            }
        }
    </style>
</head>

<body>

    <div class="header">
        <h2>Pick List</h2>
        <div><strong>Issue Number:</strong> <?= htmlspecialchars($issue_details['issue_number']) ?></div>
        <div><strong>Issuing Type:</strong> <?= htmlspecialchars($issue_details['gdn_type']) ?></div>
        <div><strong>Customer:</strong> <?= htmlspecialchars($issue_details['customer_name']) ?> (<?= htmlspecialchars($issue_details['customer_code']) ?>)</div>
        <div><strong>Vehicle Details:</strong> <?= htmlspecialchars($issue_details['vehicle_details'] ?: 'N/A') ?></div>
        <div><strong>Date:</strong> <?= date('Y-m-d H:i:s', strtotime($issue_details['created_at'])) ?></div>
    </div>

    <table>
        <thead>
            <tr>
                <th>Line No</th>
                <th>SKU Code</th>
                <th>SKU Description</th>
                <th>Batch/LOT No</th>
                <th>EXD</th>
                <th>Location</th>
                <th class="text-right">Pick Quantity</th>
                <th class="text-right">Balance Quantity</th>
                <th class="text-right">CBM (m³)</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($issue_items)): ?>
                <?php $line_no = 1;
                foreach ($issue_items as $item):
                    $balance_qty = ($item['current_in_hand_qty'] ?? 0) - $item['pick_quantity'];
                    $cbm = ($item['smallest_cbm'] ?? 0) * $item['pick_quantity'];
                ?>
                    <tr>
                        <td><?= $line_no++ ?></td>
                        <td><?= htmlspecialchars($item['sku_code']) ?></td>
                        <td><?= htmlspecialchars($item['sku_description']) ?></td>
                        <td><?= htmlspecialchars($item['batch_number']) ?></td>
                        <td><?= htmlspecialchars($item['exd']) ?></td>
                        <td><?= htmlspecialchars($item['location_code']) ?></td>
                        <td class="text-right"><?= (int)$item['pick_quantity'] ?></td>
                        <td class="text-right"><?= (int)$balance_qty ?></td>
                        <td class="text-right"><?= number_format($cbm, 4) ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="9" class="text-center">No items for this pick list.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="signature-block">
        <div>
            <p>Prepared By:</p>
            <div class="signature-line"></div>
            <p>(<?= htmlspecialchars($_SESSION['username']) ?>)</p>
        </div>
        <div>
            <p>Checked By:</p>
            <div class="signature-line"></div>
            <p>_________________________</p>
        </div>
        <div>
            <p>Approved By:</p>
            <div class="signature-line"></div>
            <p>_________________________</p>
        </div>
    </div>

    <button class="no-print" onclick="window.print()" style="margin-top: 20px; padding: 10px 20px;">Print Pick List</button>

</body>

</html>