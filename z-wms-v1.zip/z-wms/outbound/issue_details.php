<?php
session_start();
require '../inc/db.php';

if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    header("Location: ../");
    exit();
}

$compcode = $_SESSION['compcode'];
$message = '';
$issue_id = isset($_GET['issue_id']) ? (int)$_GET['issue_id'] : 0;
$issue_details = null;
$issue_items = []; // Items already added to this issue

if ($issue_id <= 0) {
    header("Location: index.php"); // Redirect if no valid issue_id
    exit();
}

// Fetch Issue Header Details
// Fetch the 'status' column directly from the database schema
$header_sql = "SELECT oi.id, oi.issue_number, oi.gdn_type, oi.customer_code, oi.vehicle_details, cm.customer_name, oi.created_at, oi.status, oi.gdn_final_number
               FROM outbound_issues oi
               JOIN customers_master cm ON oi.customer_code = cm.customer_code AND oi.compcode = cm.compcode
               WHERE oi.id = ? AND oi.compcode = ? AND oi.sku_code IS NULL"; // Crucial: Fetch the header record
$header_stmt = $conn->prepare($header_sql);
if ($header_stmt) {
    $header_stmt->bind_param("is", $issue_id, $compcode);
    $header_stmt->execute();
    $header_result = $header_stmt->get_result();
    if ($header_result->num_rows > 0) {
        $issue_details = $header_result->fetch_assoc();
    } else {
        $message = '<div class="error-message">Issue not found or unauthorized. It might already be confirmed.</div>';
        $issue_id = 0; // Invalidate issue_id to prevent further processing
    }
    $header_stmt->close();
} else {
    $message = '<div class="error-message">Database error fetching issue header: ' . htmlspecialchars($conn->error) . '</div>';
}

if ($issue_id > 0 && $issue_details) { // Only proceed if issue header details are successfully loaded
    // Use the issue_number from details for fetching items, which might be temporary or final GDN
    $issue_number_for_items = $issue_details['issue_number'];
    $current_user = $_SESSION['username']; // Get the current logged-in user

    // Fetch current items for this issue from outbound_issues table
    $items_sql = "SELECT oi.id as item_id, oi.sku_code, sm.sku_description, oi.batch_number, oi.exd, oi.location_code, oi.quantity as requested_qty
                  FROM outbound_issues oi
                  LEFT JOIN sku_master sm ON oi.sku_code = sm.sku_code AND oi.compcode = sm.compcode
                  WHERE oi.issue_number = ? AND oi.compcode = ? AND oi.sku_code IS NOT NULL
                  ORDER BY oi.created_at ASC";
    $items_stmt = $conn->prepare($items_sql);
    if ($items_stmt) {
        $items_stmt->bind_param("ss", $issue_number_for_items, $compcode);
        $items_stmt->execute();
        $items_result = $items_stmt->get_result();
        while ($row = $items_result->fetch_assoc()) {
            $issue_items[] = $row;
        }
        $items_stmt->close();
    } else {
        $message .= '<div class="error-message">Database error fetching issue items: ' . htmlspecialchars($conn->error) . '</div>';
    }

    // Handle AJAX POST requests for adding/deleting items or confirming dispatch
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
        // Prevent modifications if already confirmed using the 'status' column
        if ($issue_details['status'] === 'confirmed') { // Check the actual status column
            echo json_encode(['status' => 'error', 'message' => 'This issue has already been confirmed and cannot be modified.']);
            exit();
        }

        if ($_POST['action'] === 'add_sku_item') {
            $sku_code = trim($_POST['sku_code']);
            $location_code = trim($_POST['location_code']);
            $batch_number = trim($_POST['batch_number']);
            $exd = trim($_POST['exd']); // This comes from client-side, originally from DB
            $quantity_to_add = (int)$_POST['quantity_to_add'];

            if (empty($sku_code) || empty($location_code) || $quantity_to_add <= 0) {
                echo json_encode(['status' => 'error', 'message' => 'SKU Code, Location, and Quantity are required.']);
                exit();
            }

            // Validate and reformat EXD if necessary before insertion into outbound_issues (draft)
            $formatted_exd_for_draft = null;
            if (!empty($exd)) {
                $timestamp = strtotime($exd);
                if ($timestamp !== false) {
                    $formatted_exd_for_draft = date('Y-m-d', $timestamp);
                } else {
                    // If strtotime fails, it's truly invalid, set to NULL
                    $formatted_exd_for_draft = null;
                }
            }


            $conn->begin_transaction(); // Start transaction for atomicity

            try {
                // 1. Check if SKU exists in inventory at specified location/batch and has enough unallocated quantity
                // FOR UPDATE locks the row to prevent race conditions during allocation
                $check_inventory_sql = "SELECT in_hand_qty, allocated_qty FROM inventory WHERE compcode = ? AND sku_code = ? AND location_code = ? AND batch_number = ? FOR UPDATE";
                $check_inventory_stmt = $conn->prepare($check_inventory_sql);
                if (!$check_inventory_stmt) {
                    throw new Exception("Error preparing inventory check: " . $conn->error);
                }
                $check_inventory_stmt->bind_param("ssss", $compcode, $sku_code, $location_code, $batch_number);
                $check_inventory_stmt->execute();
                $inv_result = $check_inventory_stmt->get_result();
                $inv_row = $inv_result->fetch_assoc();
                $check_inventory_stmt->close();

                if (!$inv_row) {
                    throw new Exception('SKU/Batch not found in inventory at this location.');
                }

                $current_in_hand = $inv_row['in_hand_qty'];
                $current_allocated = $inv_row['allocated_qty'];
                $available_for_allocation = $current_in_hand - $current_allocated;

                if ($available_for_allocation < $quantity_to_add) {
                    throw new Exception("Not enough unallocated quantity in inventory for this SKU/Location/Batch. Available: " . $available_for_allocation . ", Requested: " . $quantity_to_add);
                }

                // 2. Update inventory allocated_qty
                $update_inv_sql = "UPDATE inventory SET allocated_qty = allocated_qty + ? WHERE compcode = ? AND sku_code = ? AND location_code = ? AND batch_number = ?";
                $update_inv_stmt = $conn->prepare($update_inv_sql);
                if (!$update_inv_stmt) {
                    throw new Exception("Error preparing inventory allocation update: " . $conn->error);
                }
                $update_inv_stmt->bind_param("issss", $quantity_to_add, $compcode, $sku_code, $location_code, $batch_number);
                if (!$update_inv_stmt->execute()) {
                    throw new Exception("Error updating inventory allocation: " . $update_inv_stmt->error);
                }
                $update_inv_stmt->close();

                // 3. Insert into outbound_issues as a line item
                // 'quantity' is the requested/allocated amount. 'pick_qty' is also set here for simplicity
                // but could be updated separately during a "picking" phase if needed.
                $insert_item_sql = "INSERT INTO outbound_issues (compcode, issue_number, gdn_type, customer_code, sku_code, batch_number, location_code, quantity, pick_qty, exd) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                $insert_item_stmt = $conn->prepare($insert_item_sql);
                if (!$insert_item_stmt) {
                    throw new Exception("Error preparing outbound item insert: " . $conn->error);
                }
                $insert_item_stmt->bind_param("sssssssiis", $compcode, $issue_number_for_items, $issue_details['gdn_type'], $issue_details['customer_code'], $sku_code, $batch_number, $location_code, $quantity_to_add, $quantity_to_add, $formatted_exd_for_draft); // Use formatted_exd_for_draft
                if (!$insert_item_stmt->execute()) {
                    throw new Exception("Error inserting outbound item: " . $insert_item_stmt->error);
                }
                $insert_item_stmt->close();

                $conn->commit();
                echo json_encode(['status' => 'success', 'message' => 'SKU item added and allocated successfully.']);
            } catch (Exception $e) {
                $conn->rollback();
                echo json_encode(['status' => 'error', 'message' => 'Transaction failed: ' . $e->getMessage()]);
            }
            exit(); // Important to exit after AJAX response

        } elseif ($_POST['action'] === 'delete_item') {
            $item_id_to_delete = (int)$_POST['item_id'];

            $conn->begin_transaction();
            try {
                // 1. Get quantity to de-allocate
                $get_qty_sql = "SELECT sku_code, batch_number, location_code, quantity FROM outbound_issues WHERE id = ? AND compcode = ? AND issue_number = ? FOR UPDATE";
                $get_qty_stmt = $conn->prepare($get_qty_sql);
                if (!$get_qty_stmt) {
                    throw new Exception("Error preparing get quantity statement: " . $conn->error);
                }
                $get_qty_stmt->bind_param("iss", $item_id_to_delete, $compcode, $issue_number_for_items);
                $get_qty_stmt->execute();
                $qty_result = $get_qty_stmt->get_result();
                $qty_row = $qty_result->fetch_assoc();
                $get_qty_stmt->close();

                if (!$qty_row) {
                    throw new Exception("Item not found for deletion or not part of this issue.");
                }

                $sku_code_del = $qty_row['sku_code'];
                $batch_number_del = $qty_row['batch_number'];
                $location_code_del = $qty_row['location_code'];
                $quantity_del = $qty_row['quantity'];

                // 2. De-allocate quantity in inventory
                $update_inv_sql = "UPDATE inventory SET allocated_qty = allocated_qty - ? WHERE compcode = ? AND sku_code = ? AND location_code = ? AND batch_number = ?";
                $update_inv_stmt = $conn->prepare($update_inv_sql);
                if (!$update_inv_stmt) {
                    throw new Exception("Error preparing de-allocation statement: " . $conn->error);
                }
                $update_inv_stmt->bind_param("issss", $quantity_del, $compcode, $sku_code_del, $location_code_del, $batch_number_del);
                if (!$update_inv_stmt->execute()) {
                    throw new Exception("Error de-allocating inventory: " . $update_inv_stmt->error);
                }
                $update_inv_stmt->close();

                // 3. Delete the item from outbound_issues
                $delete_item_sql = "DELETE FROM outbound_issues WHERE id = ? AND compcode = ? AND issue_number = ?";
                $delete_item_stmt = $conn->prepare($delete_item_sql);
                if (!$delete_item_stmt) {
                    throw new Exception("Error preparing item deletion statement: " . $conn->error);
                }
                $delete_item_stmt->bind_param("iss", $item_id_to_delete, $compcode, $issue_number_for_items);
                if (!$delete_item_stmt->execute()) {
                    throw new Exception("Error deleting outbound item: " . $delete_item_stmt->error);
                }
                $delete_item_stmt->close();

                $conn->commit();
                echo json_encode(['status' => 'success', 'message' => 'SKU item removed and de-allocated successfully.']);
            } catch (Exception $e) {
                $conn->rollback();
                echo json_encode(['status' => 'error', 'message' => 'Deletion failed: ' . $e->getMessage()]);
            }
            exit();
        } elseif ($_POST['action'] === 'confirm_dispatch') {
            // This is where final inventory adjustment happens and GDN is finalized.
            // It's crucial this is an atomic operation.

            $conn->begin_transaction();
            try {
                // Get all items associated with this issue_number that have been "picked" (quantity > 0)
                // Use issue_number_for_items which holds the temporary issue number.
                $confirm_items_sql = "SELECT sku_code, batch_number, location_code, quantity, exd FROM outbound_issues WHERE issue_number = ? AND compcode = ? AND sku_code IS NOT NULL AND quantity > 0 FOR UPDATE";
                $confirm_items_stmt = $conn->prepare($confirm_items_sql);
                if (!$confirm_items_stmt) {
                    throw new Exception("Error preparing confirmation item fetch: " . $conn->error);
                }
                $confirm_items_stmt->bind_param("ss", $issue_number_for_items, $compcode);
                $confirm_items_stmt->execute();
                $confirm_result = $confirm_items_stmt->get_result();

                if ($confirm_result->num_rows === 0) {
                    throw new Exception("No items found to confirm for this issue or all quantities are zero.");
                }

                // --- New GDN Number Generation Logic ---
                // Format: [compcode]-[gdn_type]-00001
                $gdn_prefix = $compcode . '-' . $issue_details['gdn_type'] . '-';

                // Find the highest existing GDN number for this type/compcode
                // The LIKE pattern should now be [compcode]-[type]- followed by 5 digits
                $max_gdn_sql = "SELECT gdn_final_number FROM outbound_issues
                               WHERE compcode = ? AND gdn_final_number LIKE ? AND sku_code IS NULL AND status = 'confirmed'
                               ORDER BY gdn_final_number DESC LIMIT 1";
                $max_gdn_stmt = $conn->prepare($max_gdn_sql);
                if (!$max_gdn_stmt) {
                    throw new Exception("Error preparing max GDN query: " . $conn->error);
                }
                // The LIKE parameter should match the exact format: [compcode]-[type]- followed by 5 digits
                $gdn_like_param = $gdn_prefix . '_____'; // 5 underscores for 5 digits
                $max_gdn_stmt->bind_param("ss", $compcode, $gdn_like_param);
                $max_gdn_stmt->execute();
                $max_gdn_result = $max_gdn_stmt->get_result();
                $last_gdn_number = '';
                if ($max_gdn_row = $max_gdn_result->fetch_assoc()) {
                    $last_gdn_number = $max_gdn_row['gdn_final_number'];
                }
                $max_gdn_stmt->close();

                $next_gdn_sequence = 1;
                if (!empty($last_gdn_number)) {
                    // Use regex to extract the numeric sequence from the end of the string
                    // This regex specifically looks for 5 digits at the end after a hyphen
                    if (preg_match('/-(\d{5})$/', $last_gdn_number, $matches)) {
                        $next_gdn_sequence = (int)$matches[1] + 1;
                    }
                }
                // The sprintf now just pads the sequence number to 5 digits
                $final_gdn_number = $gdn_prefix . sprintf('%05d', $next_gdn_sequence); // 5 digits, padded

                // Iterate through items to update inventory and insert into outbound_history
                while ($item = $confirm_result->fetch_assoc()) {
                    // Debugging: Log the original EXD value before formatting
                    error_log("Original EXD from item: " . var_export($item['exd'], true));

                    // Validate and reformat EXD for history insertion
                    $history_exd = null;
                    if (!empty($item['exd'])) {
                        $timestamp = strtotime($item['exd']);
                        if ($timestamp !== false) {
                            $history_exd = date('Y-m-d', $timestamp);
                        } else {
                            $history_exd = null; // Set to null if strtotime fails
                        }
                    }
                    // Debugging: Log the formatted EXD value
                    error_log("Formatted EXD for history: " . var_export($history_exd, true));


                    // Update inventory: subtract quantity from in_hand_qty and allocated_qty
                    $update_inv_sql = "UPDATE inventory SET in_hand_qty = in_hand_qty - ?, allocated_qty = allocated_qty - ? WHERE compcode = ? AND sku_code = ? AND location_code = ? AND batch_number = ?";
                    $update_inv_stmt = $conn->prepare($update_inv_sql);
                    if (!$update_inv_stmt) {
                        throw new Exception("Error preparing inventory adjustment statement: " . $conn->error);
                    }
                    $update_inv_stmt->bind_param("iissss", $item['quantity'], $item['quantity'], $compcode, $item['sku_code'], $item['location_code'], $item['batch_number']);
                    if (!$update_inv_stmt->execute()) {
                        throw new Exception("Error adjusting inventory: " . $update_inv_stmt->error);
                    }
                    // Crucial: Check if the update actually affected a row. If not, it means the record wasn't found
                    // or the quantity in inventory was already insufficient.
                    if ($update_inv_stmt->affected_rows === 0) {
                        throw new Exception("Failed to adjust inventory for SKU " . htmlspecialchars($item['sku_code']) . " at " . htmlspecialchars($item['location_code']) . ". Possibly insufficient quantity or record not found.");
                    }
                    $update_inv_stmt->close();

                    // Insert into outbound_history table
                    $insert_history_sql = "INSERT INTO outbound_history (compcode, issue_number, gdn_final_number, gdn_type, customer_code, sku_code, batch_number, location_code, quantity, pick_qty, exd, vehicle_details, created_by, status)
                                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'confirmed')";
                    $insert_history_stmt = $conn->prepare($insert_history_sql);
                    if (!$insert_history_stmt) {
                        throw new Exception("Error preparing outbound history insert: " . $conn->error);
                    }
                    $insert_history_stmt->bind_param(
                        "sssssssssisss",
                        $compcode,
                        $issue_details['issue_number'], // Original draft issue number
                        $final_gdn_number, // The newly generated GDN
                        $issue_details['gdn_type'],
                        $issue_details['customer_code'],
                        $item['sku_code'],
                        $item['batch_number'],
                        $item['location_code'],
                        $item['quantity'],
                        $item['quantity'], // Assuming pick_qty is same as quantity upon confirmation
                        $history_exd, // Use the validated/formatted EXD for history
                        $issue_details['vehicle_details'],
                        $current_user
                    );
                    if (!$insert_history_stmt->execute()) {
                        throw new Exception("Error inserting into outbound history for SKU " . htmlspecialchars($item['sku_code']) . ": " . $insert_history_stmt->error);
                    }
                    $insert_history_stmt->close();
                }
                $confirm_items_stmt->close();

                // Update the main outbound_issues header record with the final GDN number
                // and set its status to 'confirmed'
                $update_header_sql = "UPDATE outbound_issues SET issue_number = ?, gdn_final_number = ?, status = 'confirmed' WHERE id = ? AND compcode = ? AND sku_code IS NULL";
                $update_header_stmt = $conn->prepare($update_header_sql);
                if (!$update_header_stmt) {
                    throw new Exception("Error preparing GDN update for header: " . $conn->error);
                }
                $update_header_stmt->bind_param("ssis", $final_gdn_number, $final_gdn_number, $issue_id, $compcode);
                if (!$update_header_stmt->execute()) {
                    throw new Exception("Error updating GDN number and status for issue header: " . $update_header_stmt->error);
                }
                $update_header_stmt->close();

                // Update all line items in outbound_issues with the new GDN number
                // They should also get the status of 'confirmed'
                $update_items_sql = "UPDATE outbound_issues SET issue_number = ?, status = 'confirmed' WHERE issue_number = ? AND compcode = ? AND sku_code IS NOT NULL";
                $update_items_stmt = $conn->prepare($update_items_sql);
                if (!$update_items_stmt) {
                    throw new Exception("Error preparing GDN update for line items: " . $conn->error);
                }
                $update_items_stmt->bind_param("sss", $final_gdn_number, $issue_number_for_items, $compcode);
                if (!$update_items_stmt->execute()) {
                    throw new Exception("Error updating GDN number and status for line items: " . $update_items_stmt->error);
                }
                $update_items_stmt->close();

                $conn->commit();
                echo json_encode(['status' => 'success', 'message' => 'Dispatch confirmed! GDN Number: ' . $final_gdn_number, 'gdn_number' => $final_gdn_number, 'issue_id' => $issue_id]);
            } catch (Exception $e) {
                $conn->rollback();
                echo json_encode(['status' => 'error', 'message' => 'Confirmation failed: ' . $e->getMessage()]);
            }
            exit();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Zynex WMS | Issue Details</title>
    <link rel="stylesheet" href="../inc/global.css">
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <style>
        .details-container,
        .form-container,
        .table-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        
        .form-container {
            max-width: 400px;
        }

        .table-container {
            max-width: 100%;
        }

        .details-container h3,
        .form-container h3,
        .table-container h3 {
            color: var(--primary-color);
            margin-bottom: 15px;
        }

        .details-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px 20px;
            margin-bottom: 20px;
        }

        .details-grid div strong {
            display: inline-block;
            width: 120px;
            /* Align labels */
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }

        .form-group input[type="text"],
        .form-group select,
        .form-group input[type="number"],
        .form-group input[type="date"] {
            width: calc(100% - 16px);
            /* Adjust for padding and border */
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button,
        .form-group button,
        .action-buttons button {
            background-color: var(--btn-prim);
            color: var(--btn-text);
            padding: 0.3rem 1rem;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
            margin-right: 10px;
            font-weight: 400;
        }

        .form-group button:hover,
        .action-buttons button:hover {
            background-color: var(--btn-hover);
        }

        .action-buttons {
            margin-top: 20px;
            text-align: right;
        }

        .action-buttons button.red-btn {
            background-color: #dc3545;
        }

        .action-buttons button.red-btn:hover {
            background-color: #c82333;
        }

        .item-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .item-table th,
        .item-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
            font-size: 14px;
        }

        .item-table th {
            background-color: #f2f2f2;
            color: #555;
            font-weight: bold;
        }

        .item-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .item-table tr:hover {
            background-color: #f1f1f1;
        }

        .error-message {
            color: #d9534f;
            background-color: #f2dede;
            border: 1px solid #ebccd1;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
        }

        .success-message {
            color: #5cb85c;
            background-color: #dff0d8;
            border: 1px solid #d6e9c6;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
        }

        #sku_locations_data {
            margin-top: 10px;
            border: 1px solid #ccc;
            width: 700px;
            max-height: 200px;
            overflow-y: auto;
            background-color: #f9f9f9;
            padding: 5px;
        }

        #sku_locations_data div {
            padding: 5px;
            border-bottom: 3px dotted #000;
            cursor: pointer;
            transition: 0.4s;
        }

        #sku_locations_data div:hover {
            background-color: var(--btn-prim);
            color: var(--btn-text);
        }

        #sku_locations_data div.selected {
            background-color: #d0e0ff;
            font-weight: bold;
        }

        .read-only {
            background-color: #f0f0f0;
            cursor: not-allowed;
        }

        .action-cell {
            white-space: nowrap;
            /* Prevent buttons from wrapping */
        }

        .disabled-item {
            background-color: #f2f2f2;
            color: #999;
            cursor: not-allowed !important;
        }
    </style>
</head>

<body>
    <?php require '../parts/nav.php'; ?>
    <div id="main" class="main">
        <h2>Outbound Issue Details</h2>
        <?php echo $message; ?>

        <?php if ($issue_details): ?>
            <div class="details-container">
                <h3>Issue Header</h3>
                <div class="details-grid">
                    <div><strong>Issue No:</strong> <?= htmlspecialchars($issue_details['issue_number']) ?></div>
                    <div><strong>Customer:</strong> <?= htmlspecialchars($issue_details['customer_name']) ?> (<?= htmlspecialchars($issue_details['customer_code']) ?>)</div>
                    <div><strong>Type:</strong> <?= htmlspecialchars($issue_details['gdn_type']) ?></div>
                    <div><strong>Vehicle:</strong> <?= htmlspecialchars($issue_details['vehicle_details'] ?: 'N/A') ?></div>
                    <div><strong>Created At:</strong> <?= htmlspecialchars($issue_details['created_at']) ?></div>
                    <div><strong>Status:</strong> <?= ($issue_details['status'] === 'confirmed') ? '<span style="color: green; font-weight: bold;">CONFIRMED</span>' : '<span style="color: orange; font-weight: bold;">DRAFT</span>' ?></div>
                    <?php if ($issue_details['status'] === 'confirmed' && !empty($issue_details['gdn_final_number'])): ?>
                        <div><strong>GDN No:</strong> <?= htmlspecialchars($issue_details['gdn_final_number']) ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <div id="add_sku_form_container" class="form-container">
                <h3>Add SKU to Issue</h3>
                <form id="add_sku_form">
                    <div class="form-group">
                        <label for="sku_search">SKU Code:</label>
                        <input type="text" id="sku_search" name="sku_search" placeholder="Enter SKU Code" required />
                        <div id="sku_locations_data"></div>
                    </div>
                    <div class="form-group">
                        <label for="location_code">Location:</label>
                        <input type="text" id="location_code" name="location_code" readonly class="read-only" />
                    </div>
                    <div class="form-group">
                        <label for="batch_number">Batch No:</label>
                        <input type="text" id="batch_number" name="batch_number" readonly class="read-only" />
                    </div>
                    <div class="form-group">
                        <label for="exd">EXD:</label>
                        <input type="date" id="exd" name="exd" readonly class="read-only" />
                    </div>
                    <div class="form-group">
                        <label for="in_hand_qty_display">In Hand Qty (Available):</label>
                        <input type="text" id="in_hand_qty_display" readonly class="read-only" />
                    </div>
                    <div class="form-group">
                        <label for="quantity_to_add">Quantity to Add:</label>
                        <input type="number" id="quantity_to_add" name="quantity_to_add" min="1" required />
                    </div>
                    <button type="submit">Add Item</button>
                </form>
            </div>

            <div class="table-container">
                <h3>Issue Items</h3>
                <table class="item-table">
                    <thead>
                        <tr>
                            <th>SKU Code</th>
                            <th>Description</th>
                            <th>Batch No</th>
                            <th>EXD</th>
                            <th>Location</th>
                            <th class="text-right">Requested Qty</th>
                            <th class="action-cell">Action</th>
                        </tr>
                    </thead>
                    <tbody id="issueItemsTableBody">
                        <?php if (!empty($issue_items)): ?>
                            <?php foreach ($issue_items as $item): ?>
                                <tr data-item-id="<?= (int)$item['item_id'] ?>">
                                    <td><?= htmlspecialchars($item['sku_code']) ?></td>
                                    <td><?= htmlspecialchars($item['sku_description']) ?></td>
                                    <td><?= htmlspecialchars($item['batch_number']) ?></td>
                                    <td><?= htmlspecialchars($item['exd']) ?></td>
                                    <td><?= htmlspecialchars($item['location_code']) ?></td>
                                    <td class="text-right"><?= (int)$item['requested_qty'] ?></td>
                                    <td class="action-cell">
                                        <button class="delete-item-btn red-btn" data-item-id="<?= (int)$item['item_id'] ?>">Delete</button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr id="no_items_row">
                                <td colspan="7" class="text-center">No items added to this issue yet.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <div class="action-buttons">
                    <button id="printPicklistBtn">Print Pick List</button>
                    <?php if ($issue_details['status'] === 'confirmed'): ?>
                        <button id="printGdnBtn" data-gdn-number="<?= htmlspecialchars($issue_details['gdn_final_number']) ?>">Print GDN</button>
                    <?php else: ?>
                        <button id="confirmDispatchBtn">Confirm Dispatch</button>
                    <?php endif; ?>
                </div>
            </div>

        <?php endif; ?>
    </div>

    <script>
        $(document).ready(function() {
            const issueId = <?= (int)$issue_id ?>;
            const isConfirmed = <?= ($issue_details['status'] === 'confirmed') ? 'true' : 'false' ?>; // Use the actual status

            function displayMessage(type, message) {
                const messageDiv = $('#main');
                const html = `<div class="${type}-message">${message}</div>`;
                messageDiv.prepend(html);
                setTimeout(function() {
                    messageDiv.find(`.${type}-message`).fadeOut(500, function() {
                        $(this).remove();
                    });
                }, 5000);
            }

            // SKU Search Autocomplete/Selection
            $('#sku_search').on('input', function() {
                const sku_code = $(this).val();
                const skuLocationsData = $('#sku_locations_data');
                skuLocationsData.empty();
                if (sku_code.length < 2) { // Only search if at least 2 characters
                    return;
                }

                $.ajax({
                    url: 'fetch_sku_locations.php', // This file fetches available inventory for a SKU
                    method: 'GET',
                    data: {
                        sku_code: sku_code
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === 'success' && response.data.length > 0) {
                            response.data.forEach(item => {
                                // Only show locations with unallocated quantity
                                if (item.in_hand_qty > item.allocated_qty) {
                                    const available = item.in_hand_qty - item.allocated_qty;
                                    skuLocationsData.append(
                                        `<div data-sku="${item.sku_code}"
                                             data-location="${item.location_code}"
                                             data-batch="${item.batch_number}"
                                             data-exd="${item.exd}"
                                             data-inhand="${item.in_hand_qty}"
                                             data-allocated="${item.allocated_qty}"
                                             data-available="${available}">
                                            <strong>${item.sku_code}</strong> (${item.sku_description}) - Location: ${item.location_code} - Batch: ${item.batch_number} - EXD: ${item.exd} - Available: ${available}
                                        </div>`
                                    );
                                }
                            });
                        } else {
                            skuLocationsData.append('<div>' + (response.message || 'No available inventory found for this SKU.') + '</div>');
                        }
                    },
                    error: function(xhr, status, error) {
                        skuLocationsData.append('<div>Error fetching SKU data.</div>');
                        console.error("AJAX error: ", status, error, xhr.responseText);
                    }
                });
            });

            // Handle selection from SKU locations
            $('#sku_locations_data').on('click', 'div', function() {
                $('#sku_locations_data div').removeClass('selected');
                $(this).addClass('selected');

                $('#sku_search').val($(this).data('sku'));
                $('#location_code').val($(this).data('location'));
                $('#batch_number').val($(this).data('batch'));
                $('#exd').val($(this).data('exd'));
                $('#in_hand_qty_display').val($(this).data('available')); // Display available qty
                $('#quantity_to_add').attr('max', $(this).data('available')); // Set max for input
                $('#sku_locations_data').empty(); // Clear suggestions
            });

            // Handle Add Item Form Submission
            $('#add_sku_form').on('submit', function(e) {
                e.preventDefault();

                const sku_code = $('#sku_search').val();
                const location_code = $('#location_code').val();
                const batch_number = $('#batch_number').val();
                const exd = $('#exd').val();
                const quantity_to_add = parseInt($('#quantity_to_add').val());
                const available_qty = parseInt($('#in_hand_qty_display').val());

                if (!sku_code || !location_code || !batch_number || !exd || isNaN(quantity_to_add) || quantity_to_add <= 0) {
                    displayMessage('error', 'Please select an SKU from the list and enter a valid quantity.');
                    return;
                }

                if (quantity_to_add > available_qty) {
                    displayMessage('error', 'Quantity to add (' + quantity_to_add + ') exceeds available quantity (' + available_qty + ').');
                    return;
                }

                $.ajax({
                    url: window.location.href, // Post to the same page
                    method: 'POST',
                    data: {
                        action: 'add_sku_item',
                        issue_id: issueId,
                        sku_code: sku_code,
                        location_code: location_code,
                        batch_number: batch_number,
                        exd: exd,
                        quantity_to_add: quantity_to_add
                    },
                    dataType: 'json',
                    success: function(response) {
                        displayMessage(response.status, response.message);
                        if (response.status === 'success') {
                            // Reload the page to show updated items and available quantities
                            window.location.reload();
                        }
                    },
                    error: function(xhr, status, error) {
                        displayMessage('error', 'An error occurred: ' + (xhr.responseJSON ? xhr.responseJSON.message : error));
                        console.error("AJAX error: ", status, error, xhr.responseText);
                    }
                });
            });

            // Handle Delete Item Button
            $('#issueItemsTableBody').on('click', '.delete-item-btn', function() {
                if (!confirm('Are you sure you want to remove this item?')) {
                    return;
                }

                const itemId = $(this).data('item-id');
                $.ajax({
                    url: window.location.href,
                    method: 'POST',
                    data: {
                        action: 'delete_item',
                        issue_id: issueId,
                        item_id: itemId
                    },
                    dataType: 'json',
                    success: function(response) {
                        displayMessage(response.status, response.message);
                        if (response.status === 'success') {
                            // Reload the page to show updated items and available quantities
                            window.location.reload();
                        }
                    },
                    error: function(xhr, status, error) {
                        displayMessage('error', 'An error occurred: ' + (xhr.responseJSON ? xhr.responseJSON.message : error));
                    }
                });
            });

            // Handle Confirm Dispatch Button
            $('#confirmDispatchBtn').on('click', function() {
                if ($('#issueItemsTableBody tr').length === 0 || $('#issueItemsTableBody tr#no_items_row').length > 0) {
                    displayMessage('error', 'No items to confirm dispatch for.');
                    return;
                }
                if (!confirm('Are you sure you want to confirm dispatch for this issue? This action cannot be undone.')) {
                    return;
                }

                $.ajax({
                    url: window.location.href, // Post to the same page
                    method: 'POST',
                    data: {
                        action: 'confirm_dispatch',
                        issue_id: issueId
                    },
                    dataType: 'json',
                    success: function(response) {
                        displayMessage(response.status, response.message);
                        if (response.status === 'success') {
                            // Redirect or refresh to show the confirmed state and GDN number
                            window.location.reload();
                        }
                    },
                    error: function(xhr, status, error) {
                        displayMessage('error', 'An error occurred during dispatch confirmation: ' + (xhr.responseJSON ? xhr.responseJSON.message : error));
                        console.error("AJAX error: ", status, error, xhr.responseText);
                    }
                });
            });

            // Handle Print Pick List Button
            $('#printPicklistBtn').on('click', function() {
                if ($('#issueItemsTableBody tr').length === 0 || $('#issueItemsTableBody tr#no_items_row').length > 0) {
                    displayMessage('error', 'No items to print pick list for.');
                    return;
                }
                window.open('print_picklist.php?issue_id=' + issueId, '_blank');
            });

            // Handle Print GDN Button (for already confirmed issues)
            $('#printGdnBtn').on('click', function() {
                const gdnNumber = $(this).data('gdn-number');
                window.open('print_gdn.php?issue_id=' + issueId + '&gdn_number=' + gdnNumber, '_blank');
            });


            // Initial state adjustments if the issue is already confirmed
            if (isConfirmed) {
                $('#add_sku_form_container').hide();
                $('.delete-item-btn').prop('disabled', true).hide();
                // Remove action column header for confirmed issues
                $('#issueItemsTableBody').closest('table').find('thead th:last-child').remove();
            }
        });
    </script>
</body>

</html>