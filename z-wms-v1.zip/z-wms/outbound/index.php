<?php
session_start();
require '../inc/db.php';

if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    header("Location: ../");
    exit();
}

$compcode = $_SESSION['compcode'];
$message = '';

// Fetch Customers for the dropdown
$customers = [];
$customers_sql = "SELECT customer_code, customer_name FROM customers_master WHERE compcode = ? ORDER BY customer_name";
$customers_stmt = $conn->prepare($customers_sql);
if ($customers_stmt) {
    $customers_stmt->bind_param("s", $compcode);
    $customers_stmt->execute();
    $customers_result = $customers_stmt->get_result();
    while ($row = $customers_result->fetch_assoc()) {
        $customers[] = $row;
    }
    $customers_stmt->close();
} else {
    $message .= '<div class="error-message">Database error fetching customers: ' . htmlspecialchars($conn->error) . '</div>';
}


// Handle Create New Issue Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_issue'])) {
    $manual_issue_number = trim($_POST['manual_issue_number']); // User-entered issue number
    $customer_code = trim($_POST['customer_code']);
    $gdn_type = trim($_POST['gdn_type']);
    $vehicle_details = trim($_POST['vehicle_details']); // Optional

    if (empty($manual_issue_number) || empty($customer_code) || empty($gdn_type)) {
        $message = '<div class="error-message">Issue Number, Customer, and Issuing Type are required.</div>';
    } else {
        // Check for duplicate manual_issue_number for the same company
        $check_sql = "SELECT COUNT(*) FROM outbound_issues WHERE compcode = ? AND issue_number = ? AND sku_code IS NULL"; // Only check header rows
        $check_stmt = $conn->prepare($check_sql);
        if ($check_stmt) {
            $check_stmt->bind_param("ss", $compcode, $manual_issue_number);
            $check_stmt->execute();
            $check_stmt->bind_result($count);
            $check_stmt->fetch();
            $check_stmt->close();

            if ($count > 0) {
                $message = '<div class="error-message">Issue Number "' . htmlspecialchars($manual_issue_number) . '" already exists for this company. Please choose a different one.</div>';
            } else {
                // Insert new outbound issue header
                // status is 'draft' by default, gdn_final_number is NULL initially
                $insert_sql = "INSERT INTO outbound_issues (compcode, issue_number, gdn_type, customer_code, vehicle_details, created_by, quantity, pick_qty, sku_code) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL)";
                $stmt = $conn->prepare($insert_sql);

                if ($stmt) {
                    $created_by = $_SESSION['username'];
                    $zero_qty = 0;
                    $stmt->bind_param("ssssssii", $compcode, $manual_issue_number, $gdn_type, $customer_code, $vehicle_details, $created_by, $zero_qty, $zero_qty);
                    if ($stmt->execute()) {
                        $inserted_id = $conn->insert_id;
                        $message = '<div class="success-message">Issue ' . htmlspecialchars($manual_issue_number) . ' created successfully!</div>';
                        // Redirect to the issue details page
                        header("Location: issue_details.php?issue_id=" . $inserted_id);
                        exit();
                    } else {
                        $message = '<div class="error-message">Error creating issue: ' . htmlspecialchars($stmt->error) . '</div>';
                    }
                    $stmt->close();
                } else {
                    $message = '<div class="error-message">Database error preparing statement: ' . htmlspecialchars($conn->error) . '</div>';
                }
            }
        } else {
            $message = '<div class="error-message">Database error checking duplicate: ' . htmlspecialchars($conn->error) . '</div>';
        }
    }
}

// Fetch Drafted Records for display
$draft_issues = [];
$draft_sql = "SELECT oi.id, oi.issue_number, oi.gdn_type, oi.customer_code, cm.customer_name, oi.created_at
              FROM outbound_issues oi
              JOIN customers_master cm ON oi.customer_code = cm.customer_code AND oi.compcode = cm.compcode
              WHERE oi.compcode = ? AND oi.status = 'draft' AND oi.sku_code IS NULL
              ORDER BY oi.created_at DESC";
$draft_stmt = $conn->prepare($draft_sql);
if ($draft_stmt) {
    $draft_stmt->bind_param("s", $compcode);
    $draft_stmt->execute();
    $draft_result = $draft_stmt->get_result();
    while ($row = $draft_result->fetch_assoc()) {
        $draft_issues[] = $row;
    }
    $draft_stmt->close();
} else {
    $message .= '<div class="error-message">Database error fetching drafted issues: ' . htmlspecialchars($conn->error) . '</div>';
}

$conn->close(); // Close connection after all operations
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Zynex WMS | Outbound Dispatch</title>
    <link rel="stylesheet" href="../inc/global.css">
    <style>
        .form-container,
        .table-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px
        }
        
        .form-container {
            max-width: 400px;
        }

        .table-container {
            max-width: 100%;
        }

        .form-container h3,
        .table-container h3 {
            color: var(--primary-color);
            margin-bottom: 15px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }

        .form-group input[type="text"],
        .form-group select,
        .form-group textarea {
            width: calc(100% - 16px);
            /* Adjust for padding and border */
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .form-group input[type="submit"] {
            background-color: var(--btn-prim);
            color: var(--btn-text);
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        .form-group input[type="submit"]:hover {
            background-color: var(--btn-hover);
        }

        .error-message {
            color: #d9534f;
            background-color: #f2dede;
            border: 1px solid #ebccd1;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
        }

        .success-message {
            color: #5cb85c;
            background-color: #dff0d8;
            border: 1px solid #d6e9c6;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
        }

        /* Table styles for drafted records */
        .draft-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .draft-table th,
        .draft-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
            font-size: 14px;
        }

        .draft-table th {
            background-color: #f2f2f2;
            color: #555;
            font-weight: bold;
        }

        .draft-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .draft-table tr:hover {
            background-color: #f1f1f1;
        }

        .draft-table .action-link {
            display: inline-block;
            padding: 5px 10px;
            background-color: #007bff;
            color: white;
            border-radius: 4px;
            text-decoration: none;
            font-size: 13px;
        }

        .draft-table .action-link:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>
    <?php require '../parts/nav.php'; ?>

    <div id="main" class="main">
        <h2>Outbound Dispatch</h2>

        <?php echo $message; ?>

        <div class="form-container">
            <h3>Create New Dispatch Record</h3>
            <form action="" method="POST">
                <div class="form-group">
                    <label for="manual_issue_number">Issuing Number (Manual) *</label>
                    <input type="text" id="manual_issue_number" name="manual_issue_number" required value="<?= htmlspecialchars($_POST['manual_issue_number'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label for="gdn_type">Issuing Type *</label>
                    <select id="gdn_type" name="gdn_type" required>
                        <option value="">-- Select Type --</option>
                        <option value="DO" <?= (isset($_POST['gdn_type']) && $_POST['gdn_type'] == 'DO') ? 'selected' : '' ?>>DO - Delivery Order</option>
                        <option value="AD" <?= (isset($_POST['gdn_type']) && $_POST['gdn_type'] == 'AD') ? 'selected' : '' ?>>AD - Adjustments</option>
                        <option value="TN" <?= (isset($_POST['gdn_type']) && $_POST['gdn_type'] == 'TN') ? 'selected' : '' ?>>TN - Transfer Note</option>
                        <option value="SO" <?= (isset($_POST['gdn_type']) && $_POST['gdn_type'] == 'SO') ? 'selected' : '' ?>>SO - Sales Order</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="customer_code">Issuing Customer *</label>
                    <select id="customer_code" name="customer_code" required>
                        <option value="">-- Select Customer --</option>
                        <?php foreach ($customers as $customer): ?>
                            <option value="<?= htmlspecialchars($customer['customer_code']) ?>"
                                <?= (isset($_POST['customer_code']) && $_POST['customer_code'] == $customer['customer_code']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($customer['customer_name']) ?> (<?= htmlspecialchars($customer['customer_code']) ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="vehicle_details">Vehicle Details (Optional)</label>
                    <textarea id="vehicle_details" name="vehicle_details" rows="3"><?= htmlspecialchars($_POST['vehicle_details'] ?? '') ?></textarea>
                </div>
                <div class="form-group">
                    <input type="submit" name="create_issue" value="Create Issue">
                </div>
            </form>
        </div>

        <div class="table-container">
            <h3>Draft Dispatch Records</h3>
            <table class="draft-table">
                <thead>
                    <tr>
                        <th>Issue No</th>
                        <th>Type</th>
                        <th>Customer</th>
                        <th>Created At</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($draft_issues)): ?>
                        <?php foreach ($draft_issues as $issue): ?>
                            <tr>
                                <td><?= htmlspecialchars($issue['issue_number']) ?></td>
                                <td><?= htmlspecialchars($issue['gdn_type']) ?></td>
                                <td><?= htmlspecialchars($issue['customer_name']) ?> (<?= htmlspecialchars($issue['customer_code']) ?>)</td>
                                <td><?= htmlspecialchars($issue['created_at']) ?></td>
                                <td><a href="issue_details.php?issue_id=<?= (int)$issue['id'] ?>" class="action-link">Manage Items</a></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5">No draft dispatch records found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>

</html>