<?php
session_start();
require '../inc/db.php';

if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    header("Location: ../");
    exit();
}

$compcode = $_SESSION['compcode'];
$issue_id = isset($_GET['issue_id']) ? (int)$_GET['issue_id'] : 0;
$gdn_number_param = isset($_GET['gdn_number']) ? $_GET['gdn_number'] : ''; // Passed after confirmation

if ($issue_id <= 0 || empty($gdn_number_param)) {
    die("Invalid request: Missing Issue ID or GDN Number.");
}

// Fetch Issue Header Details (using the actual GDN number from outbound_issues)
$header_sql = "SELECT oi.issue_number, oi.gdn_final_number, oi.gdn_type, oi.customer_code, cm.customer_name,
                      cm.address1, cm.address2, cm.address3, cm.email, cm.tel, cm.fax,
                      oi.vehicle_details, oi.created_at, oi.status
               FROM outbound_issues oi
               JOIN customers_master cm ON oi.customer_code = cm.customer_code AND oi.compcode = cm.compcode
               WHERE oi.id = ? AND oi.compcode = ? AND oi.gdn_final_number = ? AND oi.sku_code IS NULL AND oi.status = 'confirmed'"; // Ensure it's the confirmed header row
$header_stmt = $conn->prepare($header_sql);
$issue_details = null;
if ($header_stmt) {
    $header_stmt->bind_param("iss", $issue_id, $compcode, $gdn_number_param);
    $header_stmt->execute();
    $header_result = $header_stmt->get_result();
    if ($header_result->num_rows > 0) {
        $issue_details = $header_result->fetch_assoc();
    }
    $header_stmt->close();
}

if (!$issue_details) {
    die("GDN details not found, unauthorized, or not confirmed for this ID and GDN number combination.");
}

// Use the gdn_final_number from the fetched header to get its items
$final_gdn_number_for_items = $issue_details['gdn_final_number'];

// Fetch Issue Items for GDN, grouped by SKU Code and Batch/LOT No
$items_sql = "SELECT
                oi.sku_code,
                sm.sku_description,
                oi.batch_number,
                MAX(oi.exd) AS exd, -- Get the latest EXD for the group, or just one if all are same
                SUM(oi.quantity) AS total_dispatched_quantity,
                (SUM(oi.quantity) * COALESCE(sm.smallest_cbm, 0)) AS cbm_line_total -- Calculate total CBM for the grouped line
              FROM
                outbound_issues oi
              LEFT JOIN
                sku_master sm ON oi.sku_code = sm.sku_code AND oi.compcode = sm.compcode
              WHERE
                oi.issue_number = ?
                AND oi.compcode = ?
                AND oi.sku_code IS NOT NULL
                AND oi.quantity > 0
                AND oi.status = 'confirmed'
              GROUP BY
                oi.sku_code,
                oi.batch_number
              ORDER BY
                oi.sku_code ASC, oi.batch_number ASC";

$items_stmt = $conn->prepare($items_sql);
$issue_items_grouped = [];
$total_dispatched_qty_overall = 0;
$total_cbm_overall = 0;

if ($items_stmt) {
    $items_stmt->bind_param("ss", $final_gdn_number_for_items, $compcode);
    $items_stmt->execute();
    $items_result = $items_stmt->get_result();
    while ($row = $items_result->fetch_assoc()) {
        $issue_items_grouped[] = $row;
        $total_dispatched_qty_overall += $row['total_dispatched_quantity'];
        $total_cbm_overall += $row['cbm_line_total'];
    }
    $items_stmt->close();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GDN - <?= htmlspecialchars($issue_details['gdn_final_number']) ?></title>
    <link rel="stylesheet" href="../inc/global.css">
    <style>
        body {
            margin: 20px;
            font-size: 12px;
        }

        .header,
        .footer {
            width: 100%;
            margin-bottom: 20px;
        }

        .header h2 {
            text-align: center;
            margin-bottom: 10px;
        }

        .header-info,
        .customer-info {
            margin-bottom: 15px;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 5px 15px;
        }

        .customer-info div {
            margin-bottom: 3px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #000;
            padding: 6px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .text-right {
            text-align: right;
        }

        .text-center {
            text-align: center;
        }

        .signature-block {
            display: flex;
            justify-content: space-around;
            text-align: center;
        }

        .signature-block div {
            width: 80%;
            margin: 0px auto;
        }

        .signature-line {
            border-bottom: 1px dotted #444;
        }

        .signature-text {
            margin-bottom: 50px;
        }

        .footer-totals {
            margin-top: 15px;
            text-align: right;
            font-weight: bold;
        }

        @media print {
            .no-print {
                display: none;
            }
        }
    </style>
</head>

<body>

    <div class="header">
        <h2>GOODS DISPATCH NOTE (GDN)</h2>
        <div class="header-info">
            <div><strong>GDN Number:</strong> <?= htmlspecialchars($issue_details['gdn_final_number']) ?></div>
            <div><strong>GDN Date:</strong> <?= date('Y-m-d H:i:s', strtotime($issue_details['created_at'])) ?></div>
            <div><strong>Issuing Type:</strong> <?= htmlspecialchars($issue_details['gdn_type']) ?></div>
            <div><strong>Vehicle Details:</strong> <?= htmlspecialchars($issue_details['vehicle_details'] ?: 'N/A') ?></div>
        </div>
        <div class="customer-info">
            <div><strong>Customer Name:</strong> <?= htmlspecialchars($issue_details['customer_name']) ?></div>
            <div><strong>Customer Code:</strong> <?= htmlspecialchars($issue_details['customer_code']) ?></div>
            <div><strong>Address:</strong>
                <?= htmlspecialchars($issue_details['address1']) ?><br>
                <?= htmlspecialchars($issue_details['address2']) ?><br>
                <?= htmlspecialchars($issue_details['address3']) ?>
            </div>
            <div><strong>Contact:</strong>
                Email: <?= htmlspecialchars($issue_details['email']) ?><br>
                Tel: <?= htmlspecialchars($issue_details['tel']) ?><br>
                FAX: <?= htmlspecialchars($issue_details['fax']) ?>
            </div>
        </div>
    </div>

    <table>
        <thead>
            <tr>
                <th>L/N</th>
                <th>SKU Code</th>
                <th>SKU Description</th>
                <th>Batch/LOT</th>
                <th>EXD</th>
                <th class="text-right">Total</th>
                <th class="text-right">CBM</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($issue_items_grouped)): ?>
                <?php $line_no = 1;
                foreach ($issue_items_grouped as $item): ?>
                    <tr>
                        <td><?= $line_no++ ?></td>
                        <td><?= htmlspecialchars($item['sku_code']) ?></td>
                        <td><?= htmlspecialchars($item['sku_description']) ?></td>
                        <td><?= htmlspecialchars($item['batch_number']) ?></td>
                        <td><?= htmlspecialchars($item['exd']) ?></td>
                        <td class="text-right"><?= (int)$item['total_dispatched_quantity'] ?></td>
                        <td class="text-right"><?= number_format($item['cbm_line_total'], 4) ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7" class="text-center">No items confirmed for dispatch.</td>
                </tr>
            <?php endif; ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="5" class="text-right"><strong>Overall Total Dispatched Quantity:</strong></td>
                <td class="text-right"><strong><?= (int)$total_dispatched_qty_overall ?></strong></td>
                <td class="text-right"><strong><?= number_format($total_cbm_overall, 4) ?></strong></td>
            </tr>
        </tfoot>
    </table>

    <div class="signature-block">
        <div>
            <p class="signature-text">Prepared By:</p>
            <div class="signature-line"></div>
            <p>(<?= htmlspecialchars($_SESSION['username']) ?>)</p>
        </div>
        <div>
            <p class="signature-text">Confirmed By (Warehouse):</p>
            <div class="signature-line"></div>
            <p>_________________________</p>
        </div>
        <div>
            <p class="signature-text">Received By (Customer):</p>
            <div class="signature-line"></div>
            <p>_________________________</p>
        </div>
    </div>

    <button class="no-print" onclick="window.print()" style="margin-top: 20px; padding: 10px 20px;">Print GDN</button>

</body>

</html>