<?php
session_start();
require '../inc/db.php'; // Adjust path if necessary

if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    header("Location: ../");
    exit();
}

$compcode = $_SESSION['compcode'];
$message = '';

// Get date filter parameters from GET request
$filter_start_date = isset($_GET['start_date']) ? $_GET['start_date'] : '';
$filter_end_date = isset($_GET['end_date']) ? $_GET['end_date'] : '';

// Fetch Confirmed Outbound History Records from the outbound_history table
$outbound_history_records = [];
$total_quantity_issued = 0;
$total_cbm_issued = 0;

$history_sql = "SELECT
                    oh.id,
                    oh.issue_number,
                    oh.gdn_final_number,
                    oh.gdn_type,
                    oh.customer_code,
                    cm.customer_name, -- Join to get customer name
                    oh.sku_code,
                    sm.sku_description, -- Join to get SKU description
                    sm.smallest_cbm, -- Fetch smallest_cbm from sku_master
                    oh.batch_number,
                    oh.location_code,
                    oh.quantity,
                    oh.pick_qty,
                    oh.exd,
                    oh.vehicle_details,
                    oh.created_by,
                    oh.created_at,
                    oi_header.id AS issue_header_id -- Get the ID from the outbound_issues header record
                FROM
                    outbound_history oh
                LEFT JOIN
                    sku_master sm ON oh.sku_code = sm.sku_code AND oh.compcode = sm.compcode
                LEFT JOIN
                    customers_master cm ON oh.customer_code = cm.customer_code AND oh.compcode = cm.compcode
                LEFT JOIN
                    outbound_issues oi_header ON oh.gdn_final_number = oi_header.gdn_final_number
                    AND oh.compcode = oi_header.compcode
                    AND oi_header.sku_code IS NULL -- To get the main GDN header record
                    AND oi_header.status = 'confirmed'
                WHERE
                    oh.compcode = ?
                    AND oh.status = 'confirmed'
                    AND oh.sku_code IS NOT NULL -- Ensure only line items are shown in history
                ";

// Add date range filter to SQL query if dates are provided
if (!empty($filter_start_date) && !empty($filter_end_date)) {
    $history_sql .= " AND oh.created_at BETWEEN ? AND ?";
} elseif (!empty($filter_start_date)) {
    $history_sql .= " AND oh.created_at >= ?";
} elseif (!empty($filter_end_date)) {
    $history_sql .= " AND oh.created_at <= ?";
}

$history_sql .= " ORDER BY oh.created_at DESC";

$history_stmt = $conn->prepare($history_sql);
if ($history_stmt) {
    $param_types = "s";
    $params = [$compcode];

    if (!empty($filter_start_date) && !empty($filter_end_date)) {
        $param_types .= "ss";
        $params[] = $filter_start_date;
        $params[] = $filter_end_date;
    } elseif (!empty($filter_start_date)) {
        $param_types .= "s";
        $params[] = $filter_start_date;
    } elseif (!empty($filter_end_date)) {
        $param_types .= "s";
        $params[] = $filter_end_date;
    }

    // Fix for bind_param: arguments must be passed by reference
    $bind_params = [];
    $bind_params[] = &$param_types;
    for ($i = 0; $i < count($params); $i++) {
        $bind_params[] = &$params[$i];
    }

    call_user_func_array([$history_stmt, 'bind_param'], $bind_params);

    $history_stmt->execute();
    $history_result = $history_stmt->get_result();
    while ($row = $history_result->fetch_assoc()) {
        $outbound_history_records[] = $row;
        $total_quantity_issued += (int)$row['quantity'];
        // Calculate CBM for each item and add to total
        $item_cbm = (float)$row['quantity'] * (float)($row['smallest_cbm'] ?? 0); // Use null coalescing
        $total_cbm_issued += $item_cbm;
    }
    $history_stmt->close();
} else {
    $message .= '<div class="error-message">Database error fetching outbound history: ' . htmlspecialchars($conn->error) . '</div>';
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Zynex WMS | Outbound History</title>
    <link rel="stylesheet" href="../inc/global.css">
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <style>
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .container h3 {
            color: var(--primary-color);
            margin-bottom: 15px;
        }

        .filter-group {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 20px;
            padding: 15px;
            background-color: #f8f9fa;
            border-radius: 8px;
            border: 1px solid #e9ecef;
        }

        .filter-group label {
            align-self: center;
            font-weight: bold;
            color: #333;
        }

        .filter-group input[type="text"],
        .filter-group input[type="date"] {
            flex: 1;
            min-width: 150px;
            padding: 8px;
            border: 1px solid #ced4da;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .filter-group button {
            padding: 8px 15px;
            background-color: var(--btn-prim);
            color: var(--btn-text);
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .filter-group button:hover {
            background-color: var(--btn-hover);
        }

        .history-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .history-table th,
        .history-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
            font-size: 14px;
        }

        .history-table th {
            background-color: #f2f2f2;
            color: #555;
            font-weight: bold;
        }

        .history-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .history-table tr:hover {
            background-color: #f1f1f1;
        }

        .history-table tfoot td {
            font-weight: bold;
            background-color: #e9ecef;
        }

        .text-right {
            text-align: right;
        }

        .text-center {
            text-align: center;
        }

        .error-message {
            color: #d9534f;
            background-color: #f2dede;
            border: 1px solid #ebccd1;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
        }
        .action-link {
            color: var(--btn-prim);
            text-decoration: none;
            font-weight: bold;
        }

        .action-link:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <?php require '../parts/nav.php'; ?>
    <div id="main" class="main">
        <h2>Outbound History</h2>
        <?php echo $message; ?>

        <div class="container">
            <h3>Confirmed Outbound Records</h3>

            <!-- Date Range Filter Form (Server-Side) -->
            <form method="GET" action="" class="filter-group">
                <label for="start_date">Date From:</label>
                <input type="date" id="start_date" name="start_date" value="<?= htmlspecialchars($filter_start_date) ?>" />
                <label for="end_date">Date To:</label>
                <input type="date" id="end_date" name="end_date" value="<?= htmlspecialchars($filter_end_date) ?>" />
                <button type="submit">Apply Date Filter</button>
                <button type="button" id="clear_date_filters_btn">Clear Date Filters</button>
            </form>

            <!-- Client-Side Text Filters -->
            <div class="filter-group">
                <input type="text" id="filter_gdn_no" placeholder="Filter by GDN No" />
                <input type="text" id="filter_sku_code" placeholder="Filter by SKU Code" />
                <input type="text" id="filter_customer_name" placeholder="Filter by Customer Name" />
                <button id="clear_text_filters_btn">Clear Text Filters</button>
            </div>

            <table class="history-table">
                <thead>
                    <tr>
                        <th>GDN No</th>
                        <th>Issue No</th>
                        <th>Type</th>
                        <th>Customer</th>
                        <th>SKU Code</th>
                        <th>Description</th>
                        <th>Batch No</th>
                        <th>Location</th>
                        <th class="text-right">Quantity</th>
                        <th>EXD</th>
                        <th>Vehicle</th>
                        <th>Created By</th>
                        <th>Created At</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="historyTableBody">
                    <?php if (!empty($outbound_history_records)): ?>
                        <?php foreach ($outbound_history_records as $record): ?>
                            <tr
                                data-gdn-number="<?= htmlspecialchars($record['gdn_final_number'] ?: '') ?>"
                                data-sku-code="<?= htmlspecialchars($record['sku_code'] ?: '') ?>"
                                data-customer-name="<?= htmlspecialchars($record['customer_name'] ?: '') ?>"
                                data-quantity="<?= (int)$record['quantity'] ?>"
                                data-cbm="<?= (float)$record['quantity'] * (float)($record['smallest_cbm'] ?? 0) ?>"
                            >
                                <td><?= htmlspecialchars($record['gdn_final_number'] ?: 'N/A') ?></td>
                                <td><?= htmlspecialchars($record['issue_number']) ?></td>
                                <td><?= htmlspecialchars($record['gdn_type']) ?></td>
                                <td><?= htmlspecialchars($record['customer_name'] ?: 'N/A') ?></td>
                                <td><?= htmlspecialchars($record['sku_code']) ?></td>
                                <td><?= htmlspecialchars($record['sku_description'] ?: 'N/A') ?></td>
                                <td><?= htmlspecialchars($record['batch_number'] ?: 'N/A') ?></td>
                                <td><?= htmlspecialchars($record['location_code'] ?: 'N/A') ?></td>
                                <td class="text-right"><?= (int)$record['quantity'] ?></td>
                                <td><?= htmlspecialchars($record['exd'] ?: 'N/A') ?></td>
                                <td><?= htmlspecialchars($record['vehicle_details'] ?: 'N/A') ?></td>
                                <td><?= htmlspecialchars($record['created_by'] ?: 'N/A') ?></td>
                                <td><?= htmlspecialchars($record['created_at']) ?></td>
                                <td>
                                    <?php if (!empty($record['gdn_final_number']) && !empty($record['issue_header_id'])): ?>
                                        <a href="../outbound/print_gdn.php?issue_id=<?= (int)$record['issue_header_id'] ?>&gdn_number=<?= htmlspecialchars($record['gdn_final_number']) ?>" target="_blank" class="action-link">Print GDN</a>
                                    <?php else: ?>
                                        N/A
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr id="no_records_row">
                            <td colspan="14" class="text-center">No confirmed outbound records found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="8" class="text-right"><strong>Total Quantity:</strong></td>
                        <td class="text-right" id="totalQuantityFooter"><strong><?= (int)$total_quantity_issued ?></strong></td>
                        <td colspan="5"></td>
                    </tr>
                    <tr>
                        <td colspan="8" class="text-right"><strong>Total CBM:</strong></td>
                        <td class="text-right" id="totalCBMFooter"><strong><?= number_format($total_cbm_issued, 3) ?></strong></td>
                        <td colspan="5"></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            const $historyTableBody = $('#historyTableBody');
            const $totalQuantityFooter = $('#totalQuantityFooter');
            const $totalCBMFooter = $('#totalCBMFooter');

            // Function to update totals based on visible rows
            function updateTotals() {
                let currentTotalQuantity = 0;
                let currentTotalCBM = 0;
                let visibleRowsCount = 0;

                $historyTableBody.find('tr').each(function() {
                    // Skip the "no records" row if it's present
                    if ($(this).attr('id') === 'no_records_row') {
                        return true; // Continue to the next iteration
                    }

                    if ($(this).css('display') !== 'none') {
                        currentTotalQuantity += parseInt($(this).data('quantity'));
                        currentTotalCBM += parseFloat($(this).data('cbm'));
                        visibleRowsCount++;
                    }
                });

                $totalQuantityFooter.text(currentTotalQuantity);
                $totalCBMFooter.text(currentTotalCBM.toFixed(3)); // Format to 3 decimal places

                // Handle "No records found" row dynamically for client-side filters
                let $noRecordsRow = $('#no_records_row');
                if (visibleRowsCount === 0) {
                    if ($noRecordsRow.length === 0) {
                        // Create and append if it doesn't exist
                        $historyTableBody.append('<tr id="no_records_row"><td colspan="14" class="text-center">No confirmed outbound records found matching filters.</td></tr>');
                    } else {
                        // Just show it if it exists
                        $noRecordsRow.show();
                    }
                } else {
                    // Hide it if there are visible rows
                    if ($noRecordsRow.length > 0) {
                        $noRecordsRow.hide();
                    }
                }
            }

            // Function to apply client-side text filters
            function applyTextFilters() {
                const filterGdnNo = $('#filter_gdn_no').val().toLowerCase();
                const filterSkuCode = $('#filter_sku_code').val().toLowerCase();
                const filterCustomerName = $('#filter_customer_name').val().toLowerCase();

                $historyTableBody.find('tr').each(function() {
                    const $row = $(this);
                    // Ensure the row is not the "no records" row before processing its data
                    if ($row.attr('id') === 'no_records_row') {
                        return true; // Continue to the next iteration
                    }

                    const rowGdnNumber = $row.data('gdn-number').toLowerCase();
                    const rowSkuCode = $row.data('sku-code').toLowerCase();
                    const rowCustomerName = $row.data('customer-name').toLowerCase();

                    let showRow = true;

                    // Filter by GDN No
                    if (filterGdnNo && !rowGdnNumber.includes(filterGdnNo)) {
                        showRow = false;
                    }

                    // Filter by SKU Code
                    if (filterSkuCode && !rowSkuCode.includes(filterSkuCode)) {
                        showRow = false;
                    }

                    // Filter by Customer Name
                    if (filterCustomerName && !rowCustomerName.includes(filterCustomerName)) {
                        showRow = false;
                    }

                    if (showRow) {
                        $row.show();
                    } else {
                        $row.hide();
                    }
                });
                updateTotals(); // Recalculate totals after filtering
            }

            // Attach event listeners to client-side filter inputs
            $('#filter_gdn_no, #filter_sku_code, #filter_customer_name').on('input', applyTextFilters);

            // Clear text filters button
            $('#clear_text_filters_btn').on('click', function() {
                $('#filter_gdn_no').val('');
                $('#filter_sku_code').val('');
                $('#filter_customer_name').val('');
                applyTextFilters(); // Apply filters to show all rows
            });

            // Clear date filters button
            $('#clear_date_filters_btn').on('click', function() {
                window.location.href = window.location.pathname; // Reload page without date parameters
            });

            // Initial total calculation and text filter application on page load
            applyTextFilters();
        });
    </script>
</body>

</html>
