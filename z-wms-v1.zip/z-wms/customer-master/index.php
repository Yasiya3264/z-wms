<?php
session_start();
require '../inc/db.php'; // Ensure db.php establishes $conn (mysqli object)

if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    header("Location: ../");
    exit();
}

$compcode = $_SESSION['compcode'];
$message = ''; // For success/error messages

// Handle Add Customer Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_customer'])) {
    $customer_code = trim($_POST['customer_code']);
    $customer_name = trim($_POST['customer_name']);
    $address1 = trim($_POST['address1']);
    $address2 = trim($_POST['address2']);
    $address3 = trim($_POST['address3']);
    $email = trim($_POST['email']);
    $tel = trim($_POST['tel']);
    $fax = trim($_POST['fax']);

    // Basic validation
    if (empty($customer_code) || empty($customer_name)) {
        $message = '<div class="error-message">Customer Code and Customer Name are required.</div>';
    } else {
        // Check for duplicate customer code for the same company
        $check_sql = "SELECT COUNT(*) FROM customers_master WHERE compcode = ? AND customer_code = ?";
        $check_stmt = $conn->prepare($check_sql);
        if ($check_stmt) {
            $check_stmt->bind_param("ss", $compcode, $customer_code);
            $check_stmt->execute();
            $check_stmt->bind_result($count);
            $check_stmt->fetch();
            $check_stmt->close();

            if ($count > 0) {
                $message = '<div class="error-message">Customer Code already exists for this company.</div>';
            } else {
                // Insert new customer using prepared statement
                $insert_sql = "INSERT INTO customers_master (compcode, customer_code, customer_name, address1, address2, address3, email, tel, fax) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($insert_sql);

                if ($stmt) {
                    $stmt->bind_param("sssssssss", $compcode, $customer_code, $customer_name, $address1, $address2, $address3, $email, $tel, $fax);
                    if ($stmt->execute()) {
                        $message = '<div class="success-message">Customer added successfully!</div>';
                        // Clear form fields after successful submission if needed, or redirect
                        // header("Location: index.php"); exit(); // uncomment to refresh and clear form
                    } else {
                        $message = '<div class="error-message">Error adding customer: ' . htmlspecialchars($stmt->error) . '</div>';
                    }
                    $stmt->close();
                } else {
                    $message = '<div class="error-message">Database error preparing statement: ' . htmlspecialchars($conn->error) . '</div>';
                }
            }
        } else {
            $message = '<div class="error-message">Database error checking duplicate: ' . htmlspecialchars($conn->error) . '</div>';
        }
    }
}

// Fetch Customers for display
$customers_sql = "SELECT * FROM customers_master WHERE compcode = ? ORDER BY customer_name";
$customers_stmt = $conn->prepare($customers_sql);
$customers_data = null;
if ($customers_stmt) {
    $customers_stmt->bind_param("s", $compcode);
    $customers_stmt->execute();
    $customers_data = $customers_stmt->get_result();
} else {
    $message = '<div class="error-message">Database error fetching customers: ' . htmlspecialchars($conn->error) . '</div>';
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Zynex WMS | Customer Master</title>
    <link rel="stylesheet" href="../inc/global.css">
    <link rel="stylesheet" href="../SKU-Master/styles.css">
    <style>
        .error-message {
            color: #d9534f;
            background-color: #f2dede;
            border: 1px solid #ebccd1;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
        }

        .success-message {
            color: #5cb85c;
            background-color: #dff0d8;
            border: 1px solid #d6e9c6;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
        }

        .form-group input[type="submit"] {
            padding: 0.5rem 2rem;
            font-size: 16px;
            background-color: var(--btn-prim);
            color: var(--btn-text);
            font-weight: 600;
            border: solid 1 var(--btn-prim);
            border-radius: 5px;
            transition: 0.4s;
            cursor: pointer;
            margin-top: 2vh;
            width: auto;
        }

        .form-group input[type="submit"]:hover {
            background-color: var(--btn-hover);
        }
    </style>
</head>

<body>
    <?php require '../parts/nav.php'; ?>

    <div id="main" class="main">
        <h2>Customer Master</h2>

        <?php echo $message; // Display messages 
        ?>

        <div class="form-container">
            <h3>Add New Customer</h3>
            <form action="" method="POST">
                <div class="form-group">
                    <label for="customer_code">Customer Code *</label>
                    <input type="text" id="customer_code" name="customer_code" required>
                </div>
                <div class="form-group">
                    <label for="customer_name">Customer Name *</label>
                    <input type="text" id="customer_name" name="customer_name" required>
                </div>
                <div class="form-group">
                    <label for="address1">Address 1</label>
                    <input type="text" id="address1" name="address1">
                </div>
                <div class="form-group">
                    <label for="address2">Address 2</label>
                    <input type="text" id="address2" name="address2">
                </div>
                <div class="form-group">
                    <label for="address3">Address 3</label>
                    <input type="text" id="address3" name="address3">
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email">
                </div>
                <div class="form-group">
                    <label for="tel">Telephone</label>
                    <input type="tel" id="tel" name="tel">
                </div>
                <div class="form-group">
                    <label for="fax">FAX</label>
                    <input type="text" id="fax" name="fax">
                </div>
                <div class="form-group">
                    <input type="submit" name="add_customer" value="Add Customer">
                </div>
            </form>
        </div>

        <div class="table-container">
            <h3>Existing Customers</h3>
            <table class="customer-table">
                <thead>
                    <tr>
                        <th>Customer Code</th>
                        <th>Customer Name</th>
                        <th>Address</th>
                        <th>Email</th>
                        <th>Telephone</th>
                        <th>FAX</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($customers_data && $customers_data->num_rows > 0): ?>
                        <?php while ($row = $customers_data->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($row['customer_code']) ?></td>
                                <td><?= htmlspecialchars($row['customer_name']) ?></td>
                                <td>
                                    <?= htmlspecialchars($row['address1']) ?><br>
                                    <?= htmlspecialchars($row['address2']) ?><br>
                                    <?= htmlspecialchars($row['address3']) ?>
                                </td>
                                <td><?= htmlspecialchars($row['email']) ?></td>
                                <td><?= htmlspecialchars($row['tel']) ?></td>
                                <td><?= htmlspecialchars($row['fax']) ?></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6">No customers found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</body>

</html>