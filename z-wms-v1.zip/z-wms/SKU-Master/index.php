<?php
session_start();
require '../inc/db.php';

if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    header("Location: ../");
    exit();
}

// Handle insert request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sku_code'])) {
    $compcode = $_SESSION['compcode'];

    $stmt = $conn->prepare("INSERT INTO sku_master (
        compcode, sku_code, sku_description, picking_strategy,
        net_weight, gross_weight,
        smallest_uom, smallest_length, smallest_width, smallest_height, smallest_cbm,
        biggest_uom, biggest_length, biggest_width, biggest_height, biggest_cbm, epl, lpp, epp,
        pellet_length, pellet_width, pellet_height, pellet_cbm
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    $stmt->bind_param(
        "ssssddsssdsdsssdssssddd",
        $compcode,
        $_POST['sku_code'],
        $_POST['sku_description'],
        $_POST['picking_strategy'],
        $_POST['net_weight'],
        $_POST['gross_weight'],
        $_POST['smallest_uom'],
        $_POST['smallL'],
        $_POST['smallW'],
        $_POST['smallH'],
        $_POST['small_cbm'],
        $_POST['biggest_uom'],
        $_POST['bigL'],
        $_POST['bigW'],
        $_POST['bigH'],
        $_POST['big_cbm'],
        $_POST['epl'],
        $_POST['lpp'],
        $_POST['epp'],
        $_POST['pelletL'],
        $_POST['pelletW'],
        $_POST['pelletH'],
        $_POST['pellet_cbm']
    );

    $stmt->execute();
    header("Location: ./");
    exit();
}

// Fetch all SKUs
$compcode = $_SESSION['compcode'];
$result = $conn->query("SELECT * FROM sku_master WHERE compcode = '" . $conn->real_escape_string($compcode) . "'");
$skus = $result->fetch_all(MYSQLI_ASSOC);

// Export to excel file
if (isset($_POST['export_csv'])) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="sku_full_export.csv"');

    $output = fopen('php://output', 'w');

    // Full header row
    fputcsv($output, [
        'SKU Code',
        'SKU Description',
        'Picking Strategy',
        'Net Weight (KG)',
        'Gross Weight (KG)',
        'Smallest UOM',
        'Smallest Length (CM)',
        'Smallest Width (CM)',
        'Smallest Height (CM)',
        'Smallest CBM',
        'Biggest UOM',
        'Biggest Length (CM)',
        'Biggest Width (CM)',
        'Biggest Height (CM)',
        'Biggest CBM',
        'Each Per Layer',
        'Layer Per Pellet',
        'Each Per Pellet',
        'Pellet Length (CM)',
        'Pellet Width (CM)',
        'Pellet Height (CM)',
        'Pellet CBM',
        'Created At'
    ]);

    $compcode = $_SESSION['compcode'];
    $res = $conn->query("SELECT * FROM sku_master WHERE compcode = '" . $conn->real_escape_string($compcode) . "'");
    while ($row = $res->fetch_assoc()) {
        fputcsv($output, [
            $row['sku_code'],
            $row['sku_description'],
            $row['picking_strategy'],
            $row['net_weight'],
            $row['gross_weight'],
            $row['smallest_uom'],
            $row['smallest_length'],
            $row['smallest_width'],
            $row['smallest_height'],
            $row['smallest_cbm'],
            $row['biggest_uom'],
            $row['biggest_length'],
            $row['biggest_width'],
            $row['biggest_height'],
            $row['biggest_cbm'],
            $row['epl'],
            $row['lpp'],
            $row['epp'],
            $row['pellet_length'],
            $row['pellet_width'],
            $row['pellet_height'],
            $row['pellet_cbm'],
            $row['created_at']
        ]);
    }
    fclose($output);
    exit;
}

?>

<!DOCTYPE html>
<html>

<head>
    <title>Zynex WMS | SKU Master</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="../inc/global.css">
    <link rel="stylesheet" href="./styles.css">
</head>

<body>

    <?php require '../parts/nav.php'; ?>

    <div id="main" class="main">
        <h2>SKU Master Form</h2>
        <form method="POST">
            <strong>Item Section</strong>
            <div class="row">
                <div class="col">
                    <label>SKU Code</label>
                    <input type="text" name="sku_code" required autofocus>
                </div>
                <div class="col">
                    <label>SKU Description</label>
                    <input type="text" name="sku_description" required>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <label>Picking Strategy</label>
                    <select name="picking_strategy" required>
                        <option value="">Select</option>
                        <option>First In First Out</option>
                        <option>First Expiry First Out</option>
                        <option>Last In First Out</option>
                        <option>First Manufacture First Out</option>
                    </select>
                </div>
                <div class="col">
                    <label>Net Weight (kg)</label>
                    <input type="number" name="net_weight" step="0.01">
                </div>
                <div class="col">
                    <label>Gross Weight (kg)</label>
                    <input type="number" name="gross_weight" step="0.01">
                </div>
            </div>
            
            <strong>SKU Data Section</strong>
            <div class="row">
                <div class="col">
                    <label>Smallest UOM</label>
                    <select name="smallest_uom" id="smallest_uom">
                        <option value="EACH">EACH</option>
                        <option value="CASE">CASE</option>
                        <option value="PELLET">PELLET</option>
                    </select>
                    <input type="number" name="smallL" placeholder="Length" step="0.01">
                    <input type="number" name="smallW" placeholder="Width" step="0.01">
                    <input type="number" name="smallH" placeholder="Height" step="0.01">
                    <div class="cbm">CBM: <span id="smallCBM">0.000</span></div>
                    <input type="hidden" name="small_cbm" id="inputSmallCBM">
                </div>
                <div class="col">
                    <label>Biggest UOM</label>
                    <select name="biggest_uom" id="biggest_uom">
                        <option value="EACH">EACH</option>
                        <option value="CASE">CASE</option>
                        <option value="PELLET">PELLET</option>
                    </select>
                    <input type="number" name="bigL" placeholder="Length" step="0.01">
                    <input type="number" name="bigW" placeholder="Width" step="0.01">
                    <input type="number" name="bigH" placeholder="Height" step="0.01">
                    <div class="cbm">CBM: <span id="bigCBM">0.000</span></div>
                    <input type="hidden" name="big_cbm" id="inputBigCBM">
                </div>
                <div class="col">
                    <label>Pellet Data</label>
                    <input type="text" name="epl" placeholder="Each Per Layer">
                    <input type="text" name="lpp" placeholder="Layer Per Pellet">
                    <input type="text" name="epp" placeholder="Each Per Pellet">
                </div>
            </div>
            
            <strong>Pellet Data</strong>
            <div class="row">
                <div class="col">
                    <input type="number" name="pelletL" placeholder="Length" step="0.01">
                    <input type="number" name="pelletW" placeholder="Width" step="0.01">
                    <input type="number" name="pelletH" placeholder="Height" step="0.01">
                    <div class="cbm">CBM: <span id="pelletCBM">0.000</span></div>
                    <input type="hidden" name="pellet_cbm" id="inputPelletCBM">
                </div>
            </div>
            
            <button type="submit">Save SKU</button>
        </form>
        
        <h2>SKU Records</h2>
        <table>
            <thead>
                <tr>
                    <th>SKU Code</th>
                    <th>Description</th>
                    <th>Strategy</th>
                    <th>Net</th>
                    <th>Gross</th>
                    <th>Smallest CBM</th>
                    <th>Biggest CBM</th>
                    <th>Pellet CBM</th>
                </tr>
                <tr class="filters">
                    <th><input type="text" class="filter" data-index="0" placeholder="Filter SKU Code"></th>
                    <th><input type="text" class="filter" data-index="1" placeholder="Filter Description"></th>
                    <th><input type="text" class="filter" data-index="2" placeholder="Filter Strategy"></th>
                    <th><input type="text" class="filter" data-index="3" placeholder="Filter Net"></th>
                    <th><input type="text" class="filter" data-index="4" placeholder="Filter Gross"></th>
                    <th><input type="text" class="filter" data-index="5" placeholder="Filter Small CBM"></th>
                    <th><input type="text" class="filter" data-index="6" placeholder="Filter Big CBM"></th>
                    <th><input type="text" class="filter" data-index="7" placeholder="Filter Pellet CBM"></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($skus as $sku): ?>
                    <tr>
                        <td><?= htmlspecialchars($sku['sku_code']) ?></td>
                        <td><?= htmlspecialchars($sku['sku_description']) ?></td>
                        <td><?= htmlspecialchars($sku['picking_strategy']) ?></td>
                        <td><?= htmlspecialchars($sku['net_weight']) ?></td>
                        <td><?= htmlspecialchars($sku['gross_weight']) ?></td>
                        <td><?= htmlspecialchars($sku['smallest_cbm']) ?></td>
                        <td><?= htmlspecialchars($sku['biggest_cbm']) ?></td>
                        <td><?= htmlspecialchars($sku['pellet_cbm']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <form method="post" style="margin-bottom: 20px;">
            <button type="submit" name="export_csv">Export as CSV</button>
        </form>

    </div>

    <script>
        function cbm(l, w, h) {
            return ((l * w * h)).toFixed(3);
        }

        function updateCBM() {
            let sL = +document.querySelector('[name=smallL]').value;
            let sW = +document.querySelector('[name=smallW]').value;
            let sH = +document.querySelector('[name=smallH]').value;
            let bL = +document.querySelector('[name=bigL]').value;
            let bW = +document.querySelector('[name=bigW]').value;
            let bH = +document.querySelector('[name=bigH]').value;
            let pL = +document.querySelector('[name=pelletL]').value;
            let pW = +document.querySelector('[name=pelletW]').value;
            let pH = +document.querySelector('[name=pelletH]').value;

            let smallCBM = cbm(sL, sW, sH);
            let bigCBM = cbm(bL, bW, bH);
            let pelletCBM = cbm(pL, pW, pH);

            document.getElementById('smallCBM').innerText = smallCBM;
            document.getElementById('inputSmallCBM').value = smallCBM;

            document.getElementById('bigCBM').innerText = bigCBM;
            document.getElementById('inputBigCBM').value = bigCBM;

            document.getElementById('pelletCBM').innerText = pelletCBM;
            document.getElementById('inputPelletCBM').value = pelletCBM;
        }

        document.querySelectorAll('input[type=number]').forEach(input => {
            input.addEventListener('input', updateCBM);
        });
    </script>

    <script>
        document.querySelectorAll(".filter").forEach(input => {
            input.addEventListener("input", function() {
                const table = input.closest("table");
                const rows = table.querySelectorAll("tbody tr");
                const filters = Array.from(table.querySelectorAll(".filter")).map(i => i.value.toLowerCase());

                rows.forEach(row => {
                    const cells = Array.from(row.children);
                    const visible = filters.every((filter, i) => {
                        return cells[i].textContent.toLowerCase().includes(filter);
                    });
                    row.style.display = visible ? "" : "none";
                });
            });
        });
    </script>


</body>

</html>