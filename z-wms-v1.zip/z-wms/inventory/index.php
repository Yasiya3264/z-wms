<?php
session_start();
// Ensure db.php connects to the database and provides a $conn object
require_once '../inc/db.php';

// Check if user is logged in
if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    header("Location: ../");
    exit();
}

$compcode = $_SESSION['compcode'];

// --- SECURITY FIX: Using Prepared Statements to prevent SQL Injection ---
// MODIFICATION: Added AND i.in_hand_qty > 0 to filter out zero-quantity items
$sql = "SELECT i.*, s.sku_description, s.smallest_cbm 
        FROM inventory i
        LEFT JOIN sku_master s ON i.sku_code = s.sku_code AND s.compcode = i.compcode
        WHERE i.compcode = ? AND i.in_hand_qty > 0
        ORDER BY i.location_code, i.sku_code";

// Prepare the SQL statement
$stmt = $conn->prepare($sql);

// Check if the statement was prepared successfully
if ($stmt === false) {
    // Log error for debugging, do not expose internal error messages to users
    error_log("Failed to prepare statement: " . $conn->error);
    die('Database error: Unable to retrieve inventory data.');
}

// Bind the company code parameter to the prepared statement
// "s" indicates that $compcode is a string type
$stmt->bind_param("s", $compcode);

// Execute the prepared statement
$stmt->execute();

// Get the result set from the executed statement
$data = $stmt->get_result();

// Define the number of columns for dynamic filter input generation
// This avoids a "magic number" in the HTML loop
$num_table_columns = 13;
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Zynex WMS | Inventory Reports</title>
    <link rel="stylesheet" href="../inc/global.css">
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
            font-size: 14px;
        }

        th {
            background-color: #f2f2f2;
            color: #555;
            font-weight: bold;
        }

        input.filter {
            width: 100%;
            padding: 5px;
            box-sizing: border-box;
            background-color: transparent;
            border: none;
            outline: none;
        }

        tfoot td {
            font-weight: bold;
            background: #eee;
        }

        /* Ensure these CSS variables are defined in global.css or elsewhere */
        button {
            padding: 0.3rem 1rem;
            font-size: 14px;
            background-color: var(--btn-prim);
            color: var(--btn-text, #fff);
            font-weight: 400;
            border: 1px solid var(--btn-prim);
            border-radius: 5px;
            transition: 0.4s;
            cursor: pointer;
            margin-top: 2vh;
        }

        button:hover {
            background-color: var(--btn-hover);
        }
    </style>
</head>

<body>

    <?php require_once '../parts/nav.php'; // Using require_once for consistency 
    ?>

    <div id="main" class="main">
        <h2><?php echo "Inventory by Location {$_SESSION['compcode']} | {$_SESSION['company_comp_name']}"?></h2>

        <button id="exportBtn">Export to Excel</button>
        <button onclick="location.reload();">Refresh</button>

        <table id="inventoryTable">
            <thead>
                <tr>
                    <th>Location</th>
                    <th>SKU</th>
                    <th>Description</th>
                    <th>Batch</th>
                    <th>MFD</th>
                    <th>EXD</th>
                    <th>Age (Days)</th>
                    <th>Received Date</th>
                    <th>GRN</th>
                    <th>In Hand</th>
                    <th>Allocated</th>
                    <th>Net Qty</th>
                    <th>CBM</th>
                </tr>
                <tr>
                    <?php for ($i = 0; $i < $num_table_columns; $i++): ?>
                        <th><input type="text" class="filter" data-col="<?= $i ?>" placeholder="Filter..."></th>
                    <?php endfor; ?>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($data->num_rows > 0) {
                    while ($row = $data->fetch_assoc()):
                        // Calculate age in days from MFD to current date
                        $mfd_timestamp = strtotime($row['mfd']);
                        $current_timestamp = strtotime(date('Y-m-d'));
                        $age = ($current_timestamp - $mfd_timestamp) / (60 * 60 * 24);

                        $net_qty = $row['in_hand_qty'] - $row['allocated_qty'];
                        // Ensure smallest_cbm is treated as a float to prevent calculation errors
                        $cbm = (float)$row['smallest_cbm'] * (int)$row['in_hand_qty'];
                ?>
                        <tr>
                            <td><?= htmlspecialchars($row['location_code']) ?></td>
                            <td><?= htmlspecialchars($row['sku_code']) ?></td>
                            <td><?= htmlspecialchars($row['sku_description']) ?></td>
                            <td><?= htmlspecialchars($row['batch_number']) ?></td>
                            <td><?= htmlspecialchars($row['mfd']) ?></td>
                            <td><?= htmlspecialchars($row['exd']) ?></td>
                            <td><?= (int)$age ?></td>
                            <td><?= htmlspecialchars($row['received_date']) ?></td>
                            <td><?= htmlspecialchars($row['grn_number']) ?></td>
                            <td class="inhand"><?= (int)$row['in_hand_qty'] ?></td>
                            <td class="allocated"><?= (int)$row['allocated_qty'] ?></td>
                            <td class="net"><?= (int)$net_qty ?></td>
                            <td class="cbm"><?= number_format($cbm, 4) ?></td>
                        </tr>
                <?php
                    endwhile;
                } else {
                    echo '<tr><td colspan="' . $num_table_columns . '">No inventory data found.</td></tr>';
                }
                $stmt->close(); // Close the statement
                $conn->close(); // Close the database connection
                ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="9" style="text-align:right;">Totals:</td>
                    <td id="totalInHand">0</td>
                    <td id="totalAllocated">0</td>
                    <td id="totalNet">0</td>
                    <td id="totalCBM">0.0000</td>
                </tr>
            </tfoot>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script>
        // Function to recalculate totals based on visible rows
        function recalcTotals() {
            let inhand = 0,
                allocated = 0,
                net = 0,
                cbm = 0;
            $("#inventoryTable tbody tr:visible").each(function() {
                // Use parseFloat for CBM to handle decimal values correctly
                inhand += parseInt($(this).find(".inhand").text()) || 0;
                allocated += parseInt($(this).find(".allocated").text()) || 0;
                net += parseInt($(this).find(".net").text()) || 0;
                cbm += parseFloat($(this).find(".cbm").text()) || 0;
            });
            $("#totalInHand").text(inhand);
            $("#totalAllocated").text(allocated);
            $("#totalNet").text(net);
            $("#totalCBM").text(cbm.toFixed(4)); // Format CBM to 4 decimal places
        }

        // Event listener for filter input changes
        $(".filter").on("input", function() {
            const col = $(this).data("col");
            const val = $(this).val().toLowerCase();
            $("#inventoryTable tbody tr").each(function() {
                // Ensure the text content is retrieved correctly before toggling
                const cellText = $(this).find("td").eq(col).text().toLowerCase();
                $(this).toggle(cellText.includes(val));
            });
            recalcTotals(); // Recalculate totals after filtering
        });

        // Initial calculation of totals when the page loads
        recalcTotals();

        // Export to Excel functionality
        $("#exportBtn").click(function() {
            let table = document.getElementById("inventoryTable");
            // Clone the table to avoid modifying the original and remove filter row
            let clonedTable = table.cloneNode(true);
            // Remove the filter row from the cloned table (second row of thead)
            $(clonedTable).find('thead tr:eq(1)').remove();

            let html = clonedTable.outerHTML;
            // Proper encoding for Excel
            let url = 'data:application/vnd.ms-excel;charset=utf-8,' + encodeURIComponent(html);
            let link = document.createElement('a');
            link.href = url;
            // Generate a dynamic filename
            link.download = 'Inventory_' + new Date().toISOString().slice(0, 10) + '.xls';
            document.body.appendChild(link); // Append to body is good practice
            link.click();
            document.body.removeChild(link); // Clean up
        });
    </script>

</body>

</html>