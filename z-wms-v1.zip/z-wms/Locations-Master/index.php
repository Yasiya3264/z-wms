<?php
session_start();

require '../inc/db.php';

if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    header("Location: ../");
    exit();
}

// Fetch data
$locations = [];
$result = $conn->query("SELECT * FROM warehouse_locations ORDER BY id ASC");
while ($row = $result->fetch_assoc()) {
    $locations[] = $row;
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Zynex WMS | Location Master</title>

    <link rel="stylesheet" href="../inc/global.css">
    <style>
        label,
        input,
        select {
            display: inline-block;
            margin: 5px 0;
        }

        label {
            width: 200px;
            align-self: center;
            font-weight: bold;
            color: #333;
        }

        input,
        select {
            flex: 1;
            min-width: 150px;
            padding: 8px;
            border: 1px solid #ced4da;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            padding: 0.5rem 2rem;
            font-size: 16px;
            background-color: var(--btn-prim);
            color: var(--btn-text);
            font-weight: 600;
            border: solid 1 var(--btn-prim);
            border-radius: 5px;
            transition: 0.4s;
            cursor: pointer;
            margin-top: 2vh;
        }

        button:hover {
            background-color: var(--btn-hover);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
            font-size: 14px;
        }

        th {
            background-color: #f2f2f2;
            color: #555;
            font-weight: bold;
        }

        .status-on {
            color: green;
            font-weight: bold;
        }

        .status-off {
            color: red;
            font-weight: bold;
        }

        .filters th input {
            background-color: transparent;
            border: none;
            outline: none;
        }
    </style>
</head>

<body>

    <?php require '../parts/nav.php'; ?>

    <div id="main" class="main">
        <h2>Warehouse Rack Location Generator</h2>

        <label>Zone Codes:</label><input id="zones" placeholder="(comma separated)"><br>
        <label>Racks per Zone:</label><input type="number" id="racks" value="1"><br>
        <label>Positions per Rack:</label><input type="number" id="positions" value="1"><br>
        <label>Levels per Position:</label><input type="number" id="levels" value="1"><br>

        <label>Length (M):</label><input type="number" id="length" value=""><br>
        <label>Width (M):</label><input type="number" id="width" value=""><br>
        <label>Height (M):</label><input type="number" id="height" value=""><br>

        <label>Occupancy Type:</label>
        <select id="occupancy">
            <option value="Actual">Actual</option>
            <option value="Virtual">Virtual</option>
        </select><br>

        <label>Status:</label>
        <input type="checkbox" id="status" checked> Active<br>

        <button onclick="generateAndSend()">Generate + Insert</button>

        <div id="result"></div>

        <script>
            function pad(n) {
                return n.toString().padStart(2, '0');
            }

            function generateAndSend() {
                const zones = document.getElementById("zones").value.split(',').map(z => z.trim());
                const racks = parseInt(document.getElementById("racks").value);
                const positions = parseInt(document.getElementById("positions").value);
                const levels = parseInt(document.getElementById("levels").value);

                const length = parseFloat(document.getElementById("length").value);
                const width = parseFloat(document.getElementById("width").value);
                const height = parseFloat(document.getElementById("height").value);
                const cbm = (length * width * height); // in cubic meters

                const occupancy = document.getElementById("occupancy").value;
                const status = document.getElementById("status").checked ? 1 : 0;

                let results = [];

                zones.forEach(zone => {
                    for (let r = 1; r <= racks; r++) {
                        for (let p = 1; p <= positions; p++) {
                            for (let l = 1; l <= levels; l++) {
                                const location_code = `${zone}-${pad(r)}-${pad(p)}-${pad(l)}`;

                                // Send to backend PHP
                                fetch('insert_location.php', {
                                        method: 'POST',
                                        headers: {
                                            'Content-Type': 'application/json'
                                        },
                                        body: JSON.stringify({
                                            location_code,
                                            length,
                                            width,
                                            height,
                                            cbm,
                                            occupancy,
                                            status
                                        })
                                    })
                                    .then(res => res.text())
                                    .then(data => {
                                        results.push(`${location_code}: ${data}`);
                                        document.getElementById("result").innerText = results.join('\n');
                                    });
                            }
                        }
                    }
                });
            }
        </script>


        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Code</th>
                    <th>L×W×H (cm)</th>
                    <th>CBM</th>
                    <th>Occupancy</th>
                    <th>Status</th>
                </tr>
                <tr class="filters">
                    <th><input type="text" class="filter" data-index="0" placeholder="Filter ID" style="width: 20px;"></th>
                    <th><input type="text" class="filter" data-index="1" placeholder="Filter Code"></th>
                    <th><input type="text" class="filter" data-index="2" placeholder="Filter L×W×H"></th>
                    <th><input type="text" class="filter" data-index="3" placeholder="Filter CBM"></th>
                    <th><input type="text" class="filter" data-index="4" placeholder="Filter Occupancy"></th>
                    <th><input type="text" class="filter" data-index="5" placeholder="Filter Status" style="width: 100px;"></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($locations as $loc): ?>
                    <tr>
                        <td><?= $loc['id'] ?></td>
                        <td><?= $loc['location_code'] ?></td>
                        <td><?= $loc['length_cm'] ?>×<?= $loc['width_cm'] ?>×<?= $loc['height_cm'] ?></td>
                        <td><?= $loc['cbm'] ?></td>
                        <td><?= $loc['occupancy_type'] ?></td>
                        <td class="<?= $loc['status'] ? 'status-on' : 'status-off' ?>">
                            <?= $loc['status'] ? 'Active' : 'Inactive' ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="6" style="text-align:right; font-weight:bold;">
                        Total Records: <?= count($locations) ?>
                    </td>
                </tr>
            </tfoot>
        </table>
    </div>



    <script>
        document.querySelectorAll(".filter").forEach(input => {
            input.addEventListener("input", function() {
                const table = input.closest("table");
                const rows = table.querySelectorAll("tbody tr");
                const filters = Array.from(table.querySelectorAll(".filter")).map(i => i.value.toLowerCase());

                rows.forEach(row => {
                    const cells = Array.from(row.children);
                    const visible = filters.every((filter, i) => {
                        return cells[i].textContent.toLowerCase().includes(filter);
                    });
                    row.style.display = visible ? "" : "none";
                });
            });
        });
    </script>

</body>

</html>