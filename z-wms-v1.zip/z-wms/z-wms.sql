-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 17, 2025 at 07:29 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `z-wms`
--

-- --------------------------------------------------------

--
-- Table structure for table `company_master`
--

CREATE TABLE `company_master` (
  `id` int(11) NOT NULL,
  `comp_code` varchar(10) NOT NULL,
  `comp_name` varchar(100) NOT NULL,
  `comp_address1` varchar(100) NOT NULL,
  `comp_address2` varchar(100) DEFAULT NULL,
  `comp_address3` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `company_master`
--

INSERT INTO `company_master` (`id`, `comp_code`, `comp_name`, `comp_address1`, `comp_address2`, `comp_address3`) VALUES
(1, 'PEL', 'Pelwatte Diary Industries PVT LTD', '234/2, Galle Road,', 'Colombo 03', '');

-- --------------------------------------------------------

--
-- Table structure for table `customers_master`
--

CREATE TABLE `customers_master` (
  `id` int(11) NOT NULL,
  `compcode` varchar(20) DEFAULT NULL,
  `customer_code` varchar(50) DEFAULT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `address1` varchar(100) DEFAULT NULL,
  `address2` varchar(100) DEFAULT NULL,
  `address3` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `tel` varchar(50) DEFAULT NULL,
  `fax` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inbound_history`
--

CREATE TABLE `inbound_history` (
  `id` int(11) NOT NULL,
  `compcode` varchar(20) DEFAULT NULL,
  `record_number` varchar(50) DEFAULT NULL,
  `grn_number` varchar(50) DEFAULT NULL,
  `receiving_type` enum('PO','AD','TN') DEFAULT NULL,
  `receiving_number` varchar(50) DEFAULT NULL,
  `receiving_date` date DEFAULT NULL,
  `vehicle_number` varchar(50) DEFAULT NULL,
  `sku_code` varchar(100) DEFAULT NULL,
  `mfd` date DEFAULT NULL,
  `exd` date DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `unit_price` decimal(10,2) DEFAULT NULL,
  `total_price` decimal(10,2) DEFAULT NULL,
  `status` enum('draft','confirmed') DEFAULT 'confirmed',
  `remarks` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inbound_receipts`
--

CREATE TABLE `inbound_receipts` (
  `id` int(11) NOT NULL,
  `compcode` varchar(20) DEFAULT NULL,
  `record_number` varchar(50) DEFAULT NULL,
  `grn_number` varchar(50) DEFAULT NULL,
  `grn_type` enum('PO','AD','TN') DEFAULT NULL,
  `receiving_number` varchar(50) DEFAULT NULL,
  `receiving_date` date DEFAULT NULL,
  `vehicle_number` varchar(50) DEFAULT NULL,
  `sku_code` varchar(100) DEFAULT NULL,
  `mfd` date DEFAULT NULL,
  `exd` date DEFAULT NULL,
  `batch_number` varchar(50) DEFAULT NULL,
  `location_code` varchar(50) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `carton_number` varchar(50) DEFAULT NULL,
  `packing_list_number` varchar(50) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('draft','confirmed') NOT NULL DEFAULT 'draft'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `id` int(11) NOT NULL,
  `sku_code` varchar(100) DEFAULT NULL,
  `location_code` varchar(50) DEFAULT NULL,
  `batch_number` varchar(50) DEFAULT NULL,
  `mfd` date DEFAULT NULL,
  `exd` date DEFAULT NULL,
  `grn_number` varchar(50) DEFAULT NULL,
  `received_date` date DEFAULT NULL,
  `in_hand_qty` int(11) DEFAULT NULL,
  `allocated_qty` int(11) DEFAULT 0,
  `compcode` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inventory_transfers`
--

CREATE TABLE `inventory_transfers` (
  `id` int(11) NOT NULL,
  `compcode` varchar(20) DEFAULT NULL,
  `transfer_number` varchar(50) DEFAULT NULL,
  `from_sku_code` varchar(100) DEFAULT NULL,
  `from_location_code` varchar(50) DEFAULT NULL,
  `from_batch_number` varchar(50) DEFAULT NULL,
  `from_mfd` date DEFAULT NULL,
  `from_exd` date DEFAULT NULL,
  `transfer_quantity` int(11) DEFAULT NULL,
  `to_location_code` varchar(50) DEFAULT NULL,
  `to_batch_number` varchar(50) DEFAULT NULL,
  `to_mfd` date DEFAULT NULL,
  `to_exd` date DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('draft','confirmed') NOT NULL DEFAULT 'draft'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `outbound_history`
--

CREATE TABLE `outbound_history` (
  `id` int(11) NOT NULL,
  `compcode` varchar(20) DEFAULT NULL,
  `issue_number` varchar(50) DEFAULT NULL,
  `gdn_final_number` varchar(50) DEFAULT NULL,
  `gdn_type` enum('DO','AD','TN','SO') DEFAULT NULL,
  `customer_code` varchar(50) DEFAULT NULL,
  `sku_code` varchar(100) DEFAULT NULL,
  `batch_number` varchar(50) DEFAULT NULL,
  `location_code` varchar(50) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `pick_qty` int(11) DEFAULT NULL,
  `exd` date DEFAULT NULL,
  `vehicle_details` text DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('draft','confirmed') NOT NULL DEFAULT 'confirmed'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `outbound_issues`
--

CREATE TABLE `outbound_issues` (
  `id` int(11) NOT NULL,
  `compcode` varchar(20) DEFAULT NULL,
  `issue_number` varchar(50) DEFAULT NULL,
  `gdn_type` enum('DO','AD','TN','SO') DEFAULT NULL,
  `customer_code` varchar(50) DEFAULT NULL,
  `sku_code` varchar(100) DEFAULT NULL,
  `batch_number` varchar(50) DEFAULT NULL,
  `location_code` varchar(50) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `pick_qty` int(11) DEFAULT NULL,
  `exd` date DEFAULT NULL,
  `vehicle_details` text DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('draft','confirmed') NOT NULL DEFAULT 'draft',
  `gdn_final_number` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sku_master`
--

CREATE TABLE `sku_master` (
  `id` int(11) NOT NULL,
  `compcode` varchar(50) NOT NULL,
  `sku_code` varchar(100) NOT NULL,
  `sku_description` text DEFAULT NULL,
  `picking_strategy` varchar(100) DEFAULT NULL,
  `net_weight` decimal(10,2) DEFAULT NULL,
  `gross_weight` decimal(10,2) DEFAULT NULL,
  `smallest_uom` varchar(50) DEFAULT NULL,
  `smallest_length` decimal(10,2) DEFAULT NULL,
  `smallest_width` decimal(10,2) DEFAULT NULL,
  `smallest_height` decimal(10,2) DEFAULT NULL,
  `smallest_cbm` decimal(10,5) DEFAULT NULL,
  `biggest_uom` varchar(50) DEFAULT NULL,
  `biggest_length` decimal(10,2) DEFAULT NULL,
  `biggest_width` decimal(10,2) DEFAULT NULL,
  `biggest_height` decimal(10,2) DEFAULT NULL,
  `biggest_cbm` decimal(10,5) DEFAULT NULL,
  `epl` varchar(50) NOT NULL,
  `lpp` varchar(50) NOT NULL,
  `epp` varchar(50) NOT NULL,
  `pellet_length` decimal(10,2) DEFAULT NULL,
  `pellet_width` decimal(10,2) DEFAULT NULL,
  `pellet_height` decimal(10,2) DEFAULT NULL,
  `pellet_cbm` decimal(10,5) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users_db`
--

CREATE TABLE `users_db` (
  `id` int(11) NOT NULL,
  `user_f_name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `compcode` varchar(10) NOT NULL,
  `email_address` varchar(100) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users_db`
--

INSERT INTO `users_db` (`id`, `user_f_name`, `username`, `password`, `compcode`, `email_address`, `status`) VALUES
(1, 'Yasith Kalhara', 'YasithK', '$2y$10$Wd1LD06AVueo8fczyFDJSeEbmGhPFPyxFBTny12/YmMVSi925aFRi', 'PEL', 'yasith.fdo@outlook.com', 'active'),
(2, 'Yasith Kalhara', 'YasithK', '$2y$10$Wd1LD06AVueo8fczyFDJSeEbmGhPFPyxFBTny12/YmMVSi925aFRi', 'WAT', 'yasith.fdo@outlook.com', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `warehouse_locations`
--

CREATE TABLE `warehouse_locations` (
  `id` int(11) NOT NULL,
  `location_code` varchar(50) NOT NULL,
  `length_cm` decimal(10,2) DEFAULT NULL,
  `width_cm` decimal(10,2) DEFAULT NULL,
  `height_cm` decimal(10,2) DEFAULT NULL,
  `cbm` decimal(10,4) DEFAULT NULL,
  `occupancy_type` enum('Actual','Virtual') DEFAULT 'Actual',
  `status` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_used` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `company_master`
--
ALTER TABLE `company_master`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `comp_code` (`comp_code`);

--
-- Indexes for table `customers_master`
--
ALTER TABLE `customers_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inbound_history`
--
ALTER TABLE `inbound_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inbound_receipts`
--
ALTER TABLE `inbound_receipts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inventory_transfers`
--
ALTER TABLE `inventory_transfers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `outbound_history`
--
ALTER TABLE `outbound_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `outbound_issues`
--
ALTER TABLE `outbound_issues`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sku_master`
--
ALTER TABLE `sku_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_db`
--
ALTER TABLE `users_db`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `warehouse_locations`
--
ALTER TABLE `warehouse_locations`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `company_master`
--
ALTER TABLE `company_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customers_master`
--
ALTER TABLE `customers_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `inbound_history`
--
ALTER TABLE `inbound_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `inbound_receipts`
--
ALTER TABLE `inbound_receipts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `inventory_transfers`
--
ALTER TABLE `inventory_transfers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `outbound_history`
--
ALTER TABLE `outbound_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `outbound_issues`
--
ALTER TABLE `outbound_issues`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sku_master`
--
ALTER TABLE `sku_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users_db`
--
ALTER TABLE `users_db`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `warehouse_locations`
--
ALTER TABLE `warehouse_locations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
