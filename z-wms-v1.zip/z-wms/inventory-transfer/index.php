<?php
session_start();
require '../inc/db.php'; // Adjust path if necessary

if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    header("Location: ../");
    exit();
}

$compcode = $_SESSION['compcode'];
$message = '';

// Fetch Draft Inventory Transfers
$draft_transfers = [];
$draft_sql = "SELECT id, transfer_number, from_sku_code, from_location_code, transfer_quantity, to_location_code, status
              FROM inventory_transfers
              WHERE compcode = ? AND status = 'draft'
              ORDER BY created_at DESC";
$draft_stmt = $conn->prepare($draft_sql);
if ($draft_stmt) {
    $draft_stmt->bind_param("s", $compcode);
    $draft_stmt->execute();
    $draft_result = $draft_stmt->get_result();
    while ($row = $draft_result->fetch_assoc()) {
        $draft_transfers[] = $row;
    }
    $draft_stmt->close();
} else {
    $message .= '<div class="error-message">Database error fetching draft transfers: ' . htmlspecialchars($conn->error) . '</div>';
}

// Display success/error message from session if redirected
if (isset($_SESSION['success_message'])) {
    $message = '<div class="success-message">' . htmlspecialchars($_SESSION['success_message']) . '</div>';
    unset($_SESSION['success_message']);
}
if (isset($_SESSION['error_message'])) {
    $message = '<div class="error-message">' . htmlspecialchars($_SESSION['error_message']) . '</div>';
    unset($_SESSION['error_message']);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Zynex WMS | Inventory Transfer</title>
    <link rel="stylesheet" href="../inc/global.css">
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <style>
        /* General Container Styles */
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .container h3 {
            color: var(--primary-color);
            margin-bottom: 15px;
        }

        /* Form Group Styles */
        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }

        .form-group input[type="text"],
        .form-group select,
        .form-group input[type="number"],
        .form-group input[type="date"] {
            width: calc(100% - 16px);
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }

        /* Button Styles */
        button,
        .form-group button,
        .action-buttons button {
            background-color: var(--btn-prim);
            color: var(--btn-text);
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
            margin-right: 10px;
        }

        .form-group button:hover,
        .action-buttons button:hover {
            background-color: var(--btn-hover);
        }

        .action-buttons {
            margin-top: 20px;
            text-align: right;
        }

        .action-buttons button.red-btn {
            background-color: #dc3545;
        }

        .action-buttons button.red-btn:hover {
            background-color: #c82333;
        }

        button:disabled {
            background-color: #cccccc;
            cursor: not-allowed;
        }

        /* Table Styles */
        .item-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .item-table th,
        .item-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
            font-size: 14px;
        }

        .item-table th {
            background-color: #f2f2f2;
            color: #555;
            font-weight: bold;
        }

        .item-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .item-table tr:hover {
            background-color: #f1f1f1;
        }

        /* Message Styles (for main page messages) */
        .error-message {
            color: #d9534f;
            background-color: #f2dede;
            border: 1px solid #ebccd1;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
        }

        .success-message {
            color: #5cb85c;
            background-color: #dff0d8;
            border: 1px solid #d6e9c6;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
        }

        /* Inventory Suggestions Autocomplete */
        #inventory_suggestions {
            margin-top: 5px;
            border: 1px solid #ccc;
            max-height: 200px;
            overflow-y: auto;
            background-color: #f9f9f9;
            padding: 5px;
            position: absolute;
            z-index: 1000;
            width: calc(100% - 40px); /* Adjust based on container padding */
        }

        #inventory_suggestions div {
            padding: 8px;
            border-bottom: 1px dotted #eee;
            cursor: pointer;
        }

        #inventory_suggestions div:last-child {
            border-bottom: none;
        }

        #inventory_suggestions div:hover {
            background-color: #e6e6e6;
        }

        /* Selected "From Data" Display */
        .from-data-display {
            background-color: #e9ecef;
            padding: 10px;
            border-radius: 5px;
            margin-top: 10px;
            border: 1px solid #ced4da;
        }
        .from-data-display div {
            margin-bottom: 5px;
        }

        /* Custom Confirmation Modal Styles */
        .modal {
            display: none; /* Hidden by default */
            position: fixed; /* Stay in place */
            z-index: 1001; /* Sit on top */
            left: 0;
            top: 0;
            width: 100%; /* Full width */
            height: 100%; /* Full height */
            overflow: auto; /* Enable scroll if needed */
            background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
            justify-content: center; /* Center horizontally */
            align-items: center; /* Center vertically */
        }

        .modal-content {
            background-color: #fefefe;
            margin: auto; /* For browsers that don't support flex centering */
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 500px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            position: relative;
            text-align: center;
        }

        .close-button {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }

        .close-button:hover,
        .close-button:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .modal-buttons {
            margin-top: 20px;
            display: flex;
            justify-content: center;
            gap: 15px;
        }

        .modal-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .modal-btn.green-btn {
            background-color: #28a745;
            color: white;
        }

        .modal-btn.green-btn:hover {
            background-color: #218838;
        }

        .modal-btn.red-btn {
            background-color: #dc3545;
            color: white;
        }

        .modal-btn.red-btn:hover {
            background-color: #c82333;
        }

        /* Inline message styles for field validation */
        .message-inline {
            font-size: 0.9em;
            margin-top: 5px;
            padding: 5px 8px;
            border-radius: 4px;
        }

        .message-inline.success-message {
            color: #28a745;
            background-color: #d4edda;
            border: 1px solid #c3e6cb;
        }

        .message-inline.error-message {
            color: #dc3545;
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>

<body>
    <?php require '../parts/nav.php'; ?>
    <div id="main" class="main">
        <h2>Inventory Transfer</h2>
        <?php echo $message; ?>

        <div class="container">
            <h3>Select Inventory to Transfer (From Data)</h3>
            <div class="form-group">
                <label for="inventory_search">Search SKU / Location / Batch:</label>
                <input type="text" id="inventory_search" placeholder="Start typing SKU, Location or Batch" />
                <div id="inventory_suggestions"></div>
            </div>

            <div class="from-data-display">
                <h4>Selected Item Details:</h4>
                <div id="from_sku_code"><strong>SKU:</strong> N/A</div>
                <div id="from_location_code"><strong>Location:</strong> N/A</div>
                <div id="from_batch_number"><strong>Batch/LOT No:</strong> N/A</div>
                <div id="from_mfd"><strong>MFD:</strong> N/A</div>
                <div id="from_exd"><strong>EXD:</strong> N/A</div>
                <div id="from_in_hand_qty"><strong>Available Quantity:</strong> N/A</div>
                <input type="hidden" id="selected_from_inventory_id" value="" />
            </div>
        </div>

        <div class="container">
            <h3>Transfer Details (To Data)</h3>
            <form id="transfer_form">
                <div class="form-group">
                    <label for="transfer_quantity">Quantity to Transfer:</label>
                    <input type="number" id="transfer_quantity" name="transfer_quantity" min="1" required />
                </div>
                <div class="form-group">
                    <label for="to_location_code">To Location Code:</label>
                    <input type="text" id="to_location_code" name="to_location_code" placeholder="Enter Destination Location" required />
                    <div id="to_location_status" class="message-inline"></div> <!-- New div for location validation status -->
                </div>
                <div class="form-group">
                    <label for="to_batch_number">To Batch/LOT No (Optional, defaults to From Batch):</label>
                    <input type="text" id="to_batch_number" name="to_batch_number" />
                </div>
                <div class="form-group">
                    <label for="to_mfd">To MFD (Optional, defaults to From MFD):</label>
                    <input type="date" id="to_mfd" name="to_mfd" />
                </div>
                <div class="form-group">
                    <label for="to_exd">To EXD (Optional, defaults to From EXD):</label>
                    <input type="date" id="to_exd" name="to_exd" />
                </div>
                <button type="submit" disabled>Add to Draft Transfers</button> <!-- Disabled by default -->
            </form>
        </div>

        <div class="container">
            <h3>Draft Inventory Transfers</h3>
            <table class="item-table">
                <thead>
                    <tr>
                        <th>Transfer No</th>
                        <th>From SKU</th>
                        <th>From Location</th>
                        <th>Transfer Qty</th>
                        <th>To Location</th>
                        <th>Status</th>
                        <th class="action-cell">Action</th>
                    </tr>
                </thead>
                <tbody id="draftTransfersTableBody">
                    <?php if (!empty($draft_transfers)): ?>
                        <?php foreach ($draft_transfers as $transfer): ?>
                            <tr data-transfer-id="<?= (int)$transfer['id'] ?>">
                                <td><?= htmlspecialchars($transfer['transfer_number']) ?></td>
                                <td><?= htmlspecialchars($transfer['from_sku_code']) ?></td>
                                <td><?= htmlspecialchars($transfer['from_location_code']) ?></td>
                                <td class="text-right"><?= (int)$transfer['transfer_quantity'] ?></td>
                                <td><?= htmlspecialchars($transfer['to_location_code']) ?></td>
                                <td><?= htmlspecialchars($transfer['status']) ?></td>
                                <td class="action-cell">
                                    <button class="confirm-transfer-btn" data-transfer-id="<?= (int)$transfer['id'] ?>">Confirm</button>
                                    <button class="delete-transfer-btn red-btn" data-transfer-id="<?= (int)$transfer['id'] ?>">Delete</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr id="no_draft_transfers_row">
                            <td colspan="7" class="text-center">No draft inventory transfers found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Custom Confirmation Modal -->
    <div id="customConfirmModal" class="modal">
        <div class="modal-content">
            <span class="close-button">&times;</span>
            <p id="confirmMessage"></p>
            <div class="modal-buttons">
                <button id="confirmYes" class="modal-btn green-btn">Yes</button>
                <button id="confirmNo" class="modal-btn red-btn">No</button>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            // Function to display main page messages (success/error)
            function displayMessage(type, message) {
                const messageDiv = $('#main');
                // Remove any existing messages before adding a new one
                messageDiv.find('.success-message, .error-message').remove();
                const html = `<div class="${type}-message">${message}</div>`;
                messageDiv.prepend(html);
                setTimeout(function() {
                    messageDiv.find(`.${type}-message`).fadeOut(500, function() {
                        $(this).remove();
                    });
                }, 5000); // Message disappears after 5 seconds
            }

            // Function to display inline field validation messages
            function displayFieldMessage(elementId, type, message) {
                const targetDiv = $(`#${elementId}`);
                targetDiv.removeClass('success-message error-message').empty(); // Clear previous messages and classes
                if (message) {
                    targetDiv.addClass(`${type}-message`).text(message);
                }
            }

            // Global flag for 'To Location Code' validation status
            let isToLocationValid = false;
            // Variable to store the callback for the custom confirmation modal
            let confirmCallback = null;

            // --- Custom Confirmation Modal Functions ---
            function showCustomConfirm(message, callback) {
                $('#confirmMessage').text(message);
                $('#customConfirmModal').css('display', 'flex'); // Use flex to center the modal
                confirmCallback = callback;
            }

            function hideCustomConfirm() {
                $('#customConfirmModal').hide();
                confirmCallback = null;
            }

            // Event listeners for the custom modal buttons
            $('#confirmYes').on('click', function() {
                if (confirmCallback) {
                    confirmCallback(true); // Call the stored callback with true (Yes)
                }
                hideCustomConfirm();
            });

            $('#confirmNo').on('click', function() {
                if (confirmCallback) {
                    confirmCallback(false); // Call the stored callback with false (No)
                }
                hideCustomConfirm();
            });

            // Close modal when clicking the 'x' button
            $('.close-button').on('click', function() {
                hideCustomConfirm();
            });

            // Close modal when clicking outside the modal content
            $(window).on('click', function(event) {
                if ($(event.target).is('#customConfirmModal')) {
                    hideCustomConfirm();
                }
            });


            // --- Form Validity Checker ---
            // This function checks all necessary conditions to enable/disable the submit button
            function checkFormValidity() {
                const fromInventoryId = $('#selected_from_inventory_id').val();
                const transferQuantity = parseInt($('#transfer_quantity').val());
                const availableQuantityText = $('#from_in_hand_qty').text();
                const availableQuantity = parseInt(availableQuantityText.replace('Available Quantity: ', ''));

                const isFromItemSelected = fromInventoryId !== '';
                const isQuantityValid = !isNaN(transferQuantity) && transferQuantity > 0 && transferQuantity <= availableQuantity;

                // Enable submit button only if all conditions are met
                if (isFromItemSelected && isQuantityValid && isToLocationValid) {
                    $('#transfer_form button[type="submit"]').prop('disabled', false);
                } else {
                    $('#transfer_form button[type="submit"]').prop('disabled', true);
                }
            }

            // --- From Data Selection (Inventory Search) ---
            $('#inventory_search').on('input', function() {
                const searchTerm = $(this).val();
                const suggestionsBox = $('#inventory_suggestions');
                suggestionsBox.empty(); // Clear previous suggestions
                if (searchTerm.length < 2) { // Require at least 2 characters for search
                    suggestionsBox.hide();
                    return;
                }

                $.ajax({
                    url: 'fetch_inventory_for_transfer.php',
                    method: 'GET',
                    data: {
                        search_term: searchTerm
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === 'success' && response.data.length > 0) {
                            response.data.forEach(item => {
                                suggestionsBox.append(
                                    `<div data-id="${item.id}"
                                          data-sku="${item.sku_code}"
                                          data-location="${item.location_code}"
                                          data-batch="${item.batch_number}"
                                          data-mfd="${item.mfd}"
                                          data-exd="${item.exd}"
                                          data-qty="${item.in_hand_qty}">
                                          SKU: ${item.sku_code} | Loc: ${item.location_code} | Batch: ${item.batch_number} | Qty: ${item.in_hand_qty}
                                    </div>`
                                );
                            });
                            suggestionsBox.show(); // Show suggestions
                        } else {
                            suggestionsBox.append('<div>No matching inventory found.</div>').show();
                        }
                    },
                    error: function(xhr, status, error) {
                        suggestionsBox.append('<div>Error fetching inventory.</div>').show();
                        console.error("AJAX error: ", status, error, xhr.responseText);
                    }
                });
            });

            // Handle selection from inventory suggestions
            $('#inventory_suggestions').on('click', 'div', function() {
                const selectedItem = $(this).data(); // Get all data- attributes
                $('#selected_from_inventory_id').val(selectedItem.id);
                $('#from_sku_code').html(`<strong>SKU:</strong> ${selectedItem.sku}`);
                $('#from_location_code').html(`<strong>Location:</strong> ${selectedItem.location}`);
                $('#from_batch_number').html(`<strong>Batch/LOT No:</strong> ${selectedItem.batch}`);
                $('#from_mfd').html(`<strong>MFD:</strong> ${selectedItem.mfd}`);
                $('#from_exd').html(`<strong>EXD:</strong> ${selectedItem.exd}`);
                $('#from_in_hand_qty').html(`<strong>Available Quantity:</strong> ${selectedItem.qty}`);

                // Pre-fill "To Data" with "From Data" as defaults
                $('#to_batch_number').val(selectedItem.batch);
                $('#to_mfd').val(selectedItem.mfd);
                $('#to_exd').val(selectedItem.exd);
                $('#transfer_quantity').val(selectedItem.qty);

                $('#inventory_search').val(`${selectedItem.sku} - ${selectedItem.location} - ${selectedItem.batch}`);
                $('#inventory_suggestions').empty().hide(); // Hide suggestions after selection

                checkFormValidity(); // Re-check form validity after selecting 'From' item
            });

            // Hide suggestions when clicking outside the search box or suggestions
            $(document).on('click', function(e) {
                if (!$(e.target).closest('#inventory_search, #inventory_suggestions').length) {
                    $('#inventory_suggestions').hide();
                }
            });

            // --- To Location Code Validation ---
            // Clear message and disable submit on input
            $('#to_location_code').on('input', function() {
                displayFieldMessage('to_location_status', '', ''); // Clear message on input
                isToLocationValid = false; // Reset validation status
                checkFormValidity(); // Disable submit button immediately
            });

            // Validate on blur (when user leaves the field)
            $('#to_location_code').on('blur', function() {
                const toLocationCode = $(this).val().trim();
                if (toLocationCode.length === 0) {
                    displayFieldMessage('to_location_status', 'error', 'To Location Code cannot be empty.');
                    isToLocationValid = false;
                    checkFormValidity();
                    return;
                }

                // AJAX call to validate location against warehouse_locations table
                $.ajax({
                    url: 'process_inventory_transfer.php', // This script will handle the validation
                    method: 'POST',
                    data: {
                        action: 'check_location', // New action for checking location
                        location_code: toLocationCode
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === 'success') {
                            displayFieldMessage('to_location_status', 'success', response.message);
                            isToLocationValid = true;
                        } else {
                            displayFieldMessage('to_location_status', 'error', response.message);
                            isToLocationValid = false;
                        }
                        checkFormValidity(); // Re-check form validity after location validation
                    },
                    error: function(xhr, status, error) {
                        displayFieldMessage('to_location_status', 'error', 'Error checking location. Please try again.');
                        isToLocationValid = false;
                        console.error("AJAX error checking location: ", status, error, xhr.responseText);
                        checkFormValidity();
                    }
                });
            });

            // Re-check form validity whenever quantity changes or an 'From' item is selected
            $('#transfer_quantity').on('input', checkFormValidity);


            // --- Add to Draft Transfer ---
            $('#transfer_form').on('submit', function(e) {
                e.preventDefault(); // Prevent default form submission

                const fromInventoryId = $('#selected_from_inventory_id').val();
                if (!fromInventoryId) {
                    displayMessage('error', 'Please select an inventory item to transfer from.');
                    return;
                }

                const transferQuantity = parseInt($('#transfer_quantity').val());
                const availableQuantityText = $('#from_in_hand_qty').text();
                const availableQuantity = parseInt(availableQuantityText.replace('Available Quantity: ', ''));

                if (isNaN(transferQuantity) || transferQuantity <= 0) {
                    displayMessage('error', 'Please enter a valid quantity to transfer.');
                    return;
                }
                if (transferQuantity > availableQuantity) {
                    displayMessage('error', `Transfer quantity (${transferQuantity}) cannot exceed available quantity (${availableQuantity}).`);
                    return;
                }

                // Ensure to_location_code is valid before proceeding
                if (!isToLocationValid) {
                    displayMessage('error', 'Please enter a valid "To Location Code" before adding to draft.');
                    return;
                }

                const formData = {
                    action: 'add_draft', // Action for the backend script
                    from_inventory_id: fromInventoryId,
                    transfer_quantity: transferQuantity,
                    to_location_code: $('#to_location_code').val(),
                    to_batch_number: $('#to_batch_number').val(),
                    to_mfd: $('#to_mfd').val(),
                    to_exd: $('#to_exd').val()
                };

                $.ajax({
                    url: 'process_inventory_transfer.php',
                    method: 'POST',
                    data: formData,
                    dataType: 'json',
                    success: function(response) {
                        displayMessage(response.status, response.message);
                        if (response.status === 'success') {
                            window.location.reload(); // Reload to show updated draft transfers
                        }
                    },
                    error: function(xhr, status, error) {
                        displayMessage('error', 'An error occurred: ' + (xhr.responseJSON ? xhr.responseJSON.message : error));
                        console.error("AJAX error: ", status, error, xhr.responseText);
                    }
                });
            });

            // --- Confirm Transfer ---
            $('#draftTransfersTableBody').on('click', '.confirm-transfer-btn', function() {
                const transferId = $(this).data('transfer-id');
                showCustomConfirm('Are you sure you want to CONFIRM this transfer? This will update inventory levels.', function(result) {
                    if (result) {
                        $.ajax({
                            url: 'process_inventory_transfer.php',
                            method: 'POST',
                            data: {
                                action: 'confirm_transfer',
                                transfer_id: transferId
                            },
                            dataType: 'json',
                            success: function(response) {
                                displayMessage(response.status, response.message);
                                if (response.status === 'success') {
                                    window.location.reload();
                                }
                            },
                            error: function(xhr, status, error) {
                                displayMessage('error', 'An error occurred during confirmation: ' + (xhr.responseJSON ? xhr.responseJSON.message : error));
                                console.error("AJAX error: ", status, error, xhr.responseText);
                            }
                        });
                    }
                });
            });

            // --- Delete Draft Transfer ---
            $('#draftTransfersTableBody').on('click', '.delete-transfer-btn', function() {
                const transferId = $(this).data('transfer-id');
                showCustomConfirm('Are you sure you want to DELETE this draft transfer?', function(result) {
                    if (result) {
                        $.ajax({
                            url: 'process_inventory_transfer.php',
                            method: 'POST',
                            data: {
                                action: 'delete_draft',
                                transfer_id: transferId
                            },
                            dataType: 'json',
                            success: function(response) {
                                displayMessage(response.status, response.message);
                                if (response.status === 'success') {
                                    window.location.reload();
                                }
                            },
                            error: function(xhr, status, error) {
                                displayMessage('error', 'An error occurred during deletion: ' + (xhr.responseJSON ? xhr.responseJSON.message : error));
                                console.error("AJAX error: ", status, error, xhr.responseText);
                            }
                        });
                    }
                });
            });

            // Initial check to set the submit button state on page load
            checkFormValidity();
        });
    </script>
</body>

</html>
