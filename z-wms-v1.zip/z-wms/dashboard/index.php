<?php
session_start();
require '../inc/db.php'; // assumes $conn or $mysqli is defined here

if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    header("Location: ../");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Zynex WMS | Dashboard</title>

    <link rel="stylesheet" href="../inc/global.css">
</head>

<body>

    <?php require '../parts/nav.php';?>

    <div id="main" class="main">
        <h1 style="text-align: center;">Z-WMS</h1>
        <h2 style="text-align: center;">Zynex Warehouse Management System</h2>

        <?php
        echo '<p>UserName: <b>'.$_SESSION['username'].'</b></p>';
        echo "<p>Company Code: <b>{$_SESSION['compcode']} | {$_SESSION['company_comp_name']}</b></p>";
        ?>
    </div>

</body>

</html>