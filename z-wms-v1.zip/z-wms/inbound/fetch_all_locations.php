<?php
session_start();
require '../inc/db.php';

header('Content-Type: application/json');

if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit();
}

$location_code_search = isset($_GET['location_code']) ? trim($_GET['location_code']) : '';

if (empty($location_code_search)) {
    echo json_encode(['status' => 'error', 'message' => 'Location code is required.']);
    exit();
}

// Fetch all locations that match the search term
$sql = "SELECT location_code, status FROM warehouse_locations WHERE location_code LIKE ? ORDER BY location_code ASC LIMIT 20";

$stmt = $conn->prepare($sql);
if ($stmt) {
    $search_param = '%' . $location_code_search . '%';
    $stmt->bind_param("s", $search_param); // Note: bind_param now only has one parameter
    $stmt->execute();
    $result = $stmt->get_result();
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    $stmt->close();
    echo json_encode(['status' => 'success', 'data' => $data]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $conn->error]);
}
?>