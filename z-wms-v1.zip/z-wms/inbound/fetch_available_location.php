<?php
session_start();
require '../inc/db.php'; // Assuming db.php contains your database connection ($conn)

header('Content-Type: application/json');

if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit();
}

$compcode = $_SESSION['compcode'];
// The request implies automatic allocation, so location_code_search might not be directly used for filtering
// but the original query had it, so we'll keep it as an optional parameter.
$location_code_search = isset($_GET['location_code']) ? trim($_GET['location_code']) : '';

// SQL query to fetch locations from warehouse_locations based on the provided logic:
// - Location is active (status = 1)
// - Location code matches the search parameter (if provided)
// - No existing inventory records with in_hand_qty >= 1 OR no inventory records at all (empty location)
// - Not currently used in any 'draft' inbound_receipts
// - Ordered by location_code ASC
// - Limited to 1 result for "best" (first available) location
$sql = "
    SELECT wl.location_code
    FROM warehouse_locations wl
    LEFT JOIN inventory i ON wl.location_code = i.location_code AND i.compcode = ?
    WHERE wl.status = 1
    AND wl.location_code LIKE ?
    AND NOT EXISTS (
        SELECT 1
        FROM inbound_receipts ir
        WHERE ir.status = 'draft'
        AND ir.location_code IS NOT NULL
        AND ir.location_code = wl.location_code
    )
    GROUP BY wl.location_code
    HAVING
        SUM(CASE WHEN i.in_hand_qty IS NOT NULL THEN i.in_hand_qty ELSE 0 END) < 1
        OR COUNT(i.location_code) = 0
    ORDER BY wl.location_code ASC
    LIMIT 1
";

$stmt = $conn->prepare($sql);
if ($stmt) {
    $search_param = '%' . $location_code_search . '%'; // Use % for broad search if no specific code is given
    $stmt->bind_param("ss", $compcode, $search_param);
    $stmt->execute();
    $result = $stmt->get_result();
    $location = null;
    if ($row = $result->fetch_assoc()) {
        $location = $row['location_code'];
    }
    $stmt->close();

    if ($location) {
        echo json_encode(['status' => 'success', 'location_code' => $location]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'No suitable location found.']);
    }
} else {
    error_log("Database error in fetch_available_location.php: " . $conn->error);
    echo json_encode(['status' => 'error', 'message' => 'Database error. Please try again later.']);
}
?>
