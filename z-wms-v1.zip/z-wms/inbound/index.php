<?php
session_start();
require '../inc/db.php'; // Adjust path if necessary

if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    header("Location: ../");
    exit();
}

$compcode = $_SESSION['compcode'];
$message = '';

// Handle Create New Receipt Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_receipt'])) {
    $receiving_type = trim($_POST['receiving_type']);
    $receiving_number = trim($_POST['receiving_number']); // Manual input
    $vehicle_details = trim($_POST['vehicle_details']); // Optional

    if (empty($receiving_type) || empty($receiving_number)) {
        $message = '<div class="error-message">Receiving Type and Receiving Number are required.</div>';
    } else {
        $conn->begin_transaction();
        try {
            // Auto-generate Record Number (e.g., COMPCODE-IN-YYYYMMDD-00001)
            $record_prefix = $compcode . '-IN-' . date('Ymd') . '-';

            // Find the highest existing record number for today for this compcode
            $max_record_sql = "SELECT record_number FROM inbound_receipts 
                               WHERE compcode = ? AND record_number LIKE ? 
                               ORDER BY record_number DESC LIMIT 1";
            $max_record_stmt = $conn->prepare($max_record_sql);
            if (!$max_record_stmt) {
                throw new Exception("Database error preparing record number query: " . $conn->error);
            }
            $record_like_param = $record_prefix . '%';
            $max_record_stmt->bind_param("ss", $compcode, $record_like_param);
            $max_record_stmt->execute();
            $max_record_result = $max_record_stmt->get_result();
            $last_record_number = '';
            if ($max_record_row = $max_record_result->fetch_assoc()) {
                $last_record_number = $max_record_row['record_number'];
            }
            $max_record_stmt->close();

            $next_sequence = 1;
            if (!empty($last_record_number)) {
                $parts = explode('-', $last_record_number);
                if (count($parts) > 0 && is_numeric($parts[count($parts) - 1])) {
                    $next_sequence = (int)$parts[count($parts) - 1] + 1;
                }
            }
            $system_record_number = $record_prefix . sprintf('%05d', $next_sequence);

            // Insert new inbound receipt header (sku_code is NULL for header)
            $insert_sql = "INSERT INTO inbound_receipts (compcode, record_number, grn_type, receiving_number, vehicle_number, receiving_date, status, sku_code) 
                           VALUES (?, ?, ?, ?, ?, CURDATE(), 'draft', NULL)"; // sku_code NULL for header
            $insert_stmt = $conn->prepare($insert_sql);
            if (!$insert_stmt) {
                throw new Exception("Database error preparing insert statement: " . $conn->error);
            }
            $insert_stmt->bind_param("sssss", $compcode, $system_record_number, $receiving_type, $receiving_number, $vehicle_details);

            if ($insert_stmt->execute()) {
                $new_receipt_id = $insert_stmt->insert_id;
                $insert_stmt->close();
                $conn->commit();
                $_SESSION['success_message'] = 'New inbound receipt created successfully! Record No: ' . htmlspecialchars($system_record_number);
                header("Location: receipt_details.php?receipt_id=" . $new_receipt_id);
                exit();
            } else {
                throw new Exception("Error creating new receipt: " . $insert_stmt->error);
            }
        } catch (Exception $e) {
            $conn->rollback();
            $message = '<div class="error-message">Failed to create receipt: ' . htmlspecialchars($e->getMessage()) . '</div>';
        }
    }
}

// Fetch Draft Inbound Receipts
$draft_receipts = [];
$draft_sql = "SELECT id, record_number, grn_type, receiving_number, receiving_date, vehicle_number 
              FROM inbound_receipts 
              WHERE compcode = ? AND status = 'draft' AND sku_code IS NULL 
              ORDER BY created_at DESC";
$draft_stmt = $conn->prepare($draft_sql);
if ($draft_stmt) {
    $draft_stmt->bind_param("s", $compcode);
    $draft_stmt->execute();
    $draft_result = $draft_stmt->get_result();
    while ($row = $draft_result->fetch_assoc()) {
        $draft_receipts[] = $row;
    }
    $draft_stmt->close();
} else {
    $message .= '<div class="error-message">Database error fetching draft receipts: ' . htmlspecialchars($conn->error) . '</div>';
}

// Display success message from session if redirected
if (isset($_SESSION['success_message'])) {
    $message = '<div class="success-message">' . htmlspecialchars($_SESSION['success_message']) . '</div>';
    unset($_SESSION['success_message']);
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Zynex WMS | Inbound Receipts</title>
    <link rel="stylesheet" href="../inc/global.css">
    <style>
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .form-container {
            max-width: 400px;
        }

        .table-container {
            max-width: 100%;
        }

        .container h3 {
            color: var(--primary-color);
            margin-bottom: 15px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }

        .form-group input[type="text"],
        .form-group select,
        .form-group textarea {
            width: calc(100% - 16px);
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .form-group button {
            background-color: var(--btn-prim);
            color: var(--btn-text);
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        .form-group button:hover {
            background-color: var(--btn-hover);
        }

        .draft-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .draft-table th,
        .draft-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
            font-size: 14px;
        }

        .draft-table th {
            background-color: #f2f2f2;
            color: #555;
            font-weight: bold;
        }

        .draft-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .draft-table tr:hover {
            background-color: #f1f1f1;
        }

        .action-link {
            color: var(--btn-prim);
            text-decoration: none;
            font-weight: bold;
        }

        .action-link:hover {
            text-decoration: underline;
        }

        .error-message {
            color: #d9534f;
            background-color: #f2dede;
            border: 1px solid #ebccd1;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
        }

        .success-message {
            color: #5cb85c;
            background-color: #dff0d8;
            border: 1px solid #d6e9c6;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
        }
    </style>
</head>

<body>
    <?php require '../parts/nav.php'; ?>
    <div id="main" class="main">
        <h2>Inbound Receipts</h2>

        <?php echo $message; ?>

        <div class="container form-container">
            <h3>Create New Inbound Receipt</h3>
            <form action="" method="POST">
                <div class="form-group">
                    <label for="receiving_type">Receiving Type (GDN):</label>
                    <select id="receiving_type" name="receiving_type" required>
                        <option value="">Select Type</option>
                        <option value="PO">PO - Purchase Order</option>
                        <option value="AD">AD - Adjustments</option>
                        <option value="TN">TN - Transfer Note</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="receiving_number">Receiving Number (Manual):</label>
                    <input type="text" id="receiving_number" name="receiving_number" required placeholder="Enter manual receiving number" />
                </div>
                <div class="form-group">
                    <label for="vehicle_details">Vehicle Details (Optional):</label>
                    <textarea id="vehicle_details" name="vehicle_details" rows="3" placeholder="Enter vehicle details"></textarea>
                </div>
                <div class="form-group">
                    <button type="submit" name="create_receipt">Create New Receipt</button>
                </div>
            </form>
        </div>

        <div class="container table-container">
            <h3>Draft Inbound Records</h3>
            <table class="draft-table">
                <thead>
                    <tr>
                        <th>Record No</th>
                        <th>Type</th>
                        <th>Receiving No</th>
                        <th>Date</th>
                        <th>Vehicle</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($draft_receipts)): ?>
                        <?php foreach ($draft_receipts as $receipt): ?>
                            <tr>
                                <td><?= htmlspecialchars($receipt['record_number']) ?></td>
                                <td><?= htmlspecialchars($receipt['grn_type']) ?></td>
                                <td><?= htmlspecialchars($receipt['receiving_number']) ?></td>
                                <td><?= htmlspecialchars($receipt['receiving_date']) ?></td>
                                <td><?= htmlspecialchars($receipt['vehicle_number'] ?: 'N/A') ?></td>
                                <td><a href="receipt_details.php?receipt_id=<?= (int)$receipt['id'] ?>" class="action-link">Manage Items</a></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6">No draft inbound records found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>

</html>