<?php
session_start();
require '../inc/db.php';

if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    header("Location: ../");
    exit();
}

$compcode = $_SESSION['compcode'];
$receipt_id = isset($_GET['receipt_id']) ? (int)$_GET['receipt_id'] : 0;
$grn_number_param = isset($_GET['grn_number']) ? $_GET['grn_number'] : ''; // Passed after confirmation

if ($receipt_id <= 0 || empty($grn_number_param)) {
    die("Invalid request: Missing Receipt ID or GRN Number.");
}

// Fetch Receipt Header Details (using the actual GRN number from inbound_receipts)
$header_sql = "SELECT id, record_number, grn_number, grn_type, receiving_number, vehicle_number, receiving_date, status, created_at
               FROM inbound_receipts
               WHERE id = ? AND compcode = ? AND grn_number = ? AND sku_code IS NULL AND status = 'confirmed'"; // Ensure it's the confirmed header row
$header_stmt = $conn->prepare($header_sql);
$receipt_details = null;
if ($header_stmt) {
    $header_stmt->bind_param("iss", $receipt_id, $compcode, $grn_number_param);
    $header_stmt->execute();
    $header_result = $header_stmt->get_result();
    if ($header_result->num_rows > 0) {
        $receipt_details = $header_result->fetch_assoc();
    }
    $header_stmt->close();
} else {
    die("Database error fetching receipt header: " . htmlspecialchars($conn->error));
}

if (!$receipt_details) {
    die("GRN not found, not confirmed, or unauthorized access.");
}

// Fetch confirmed items for this GRN
$items_sql = "SELECT ir.sku_code, sm.sku_description, ir.batch_number, ir.mfd, ir.exd, ir.location_code, ir.quantity 
              FROM inbound_receipts ir
              JOIN sku_master sm ON ir.sku_code = sm.sku_code AND ir.compcode = sm.compcode
              WHERE ir.grn_number = ? AND ir.compcode = ? AND ir.sku_code IS NOT NULL AND ir.status = 'confirmed'
              ORDER BY ir.created_at ASC";
$items_stmt = $conn->prepare($items_sql);
$receipt_items = [];
$total_received_qty = 0;
if ($items_stmt) {
    $items_stmt->bind_param("ss", $grn_number_param, $compcode);
    $items_stmt->execute();
    $items_result = $items_stmt->get_result();
    while ($row = $items_result->fetch_assoc()) {
        $receipt_items[] = $row;
        $total_received_qty += $row['quantity'];
    }
    $items_stmt->close();
} else {
    die("Error fetching receipt items for GRN: " . htmlspecialchars($conn->error));
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Goods Receiving Note (GRN)</title>
    <link rel="stylesheet" href="../inc/global.css">
    <style>
        body {
            font-size: 12px;
            background-color: #444;
        }

        .container {
            width: 800px;
            /* margin: 0 auto; */
            border: 1px solid #ccc;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color: #fff;
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        .header-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin-bottom: 20px;
        }

        .header-info div strong {
            display: inline-block;
            width: 150px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .text-right {
            text-align: right;
        }

        .text-center {
            text-align: center;
        }

        .signature-block {
            display: flex;
            justify-content: space-around;
            text-align: center;
            margin: 0px 5px;
        }

        .signature-block div {
            width: 80%;
            margin: 0px auto;
        }

        .signature-line {
            border-bottom: 1px dotted #444;
        }

        .signature-text {
            margin-bottom: 50px;
        }

        .no-print {
            position: fixed;
            bottom: 20px;
            right: 20px;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        @media print {
            .no-print {
                display: none;
            }

            body {
                margin: 0;
            }

            .container {
                width: 100%;
                border: none;
                box-shadow: none;
                padding: 0;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Goods Receiving Note (GRN)</h1>

        <div class="header-info">
            <div><strong>GRN Number:</strong> <?= htmlspecialchars($receipt_details['grn_number']) ?></div>
            <div><strong>Record Number:</strong> <?= htmlspecialchars($receipt_details['record_number']) ?></div>
            <div><strong>Receiving Type:</strong> <?= htmlspecialchars($receipt_details['grn_type']) ?></div>
            <div><strong>Receiving Number:</strong> <?= htmlspecialchars($receipt_details['receiving_number']) ?></div>
            <div><strong>Receiving Date:</strong> <?= htmlspecialchars($receipt_details['receiving_date']) ?></div>
            <div><strong>Vehicle Details:</strong> <?= htmlspecialchars($receipt_details['vehicle_number'] ?: 'N/A') ?></div>
            <div><strong>Printed By:</strong> <?= htmlspecialchars($_SESSION['username']) ?></div>
            <div><strong>Printed On:</strong> <?= date('Y-m-d H:i:s') ?></div>
        </div>

        <table>
            <thead>
                <tr>
                    <th>SKU Code</th>
                    <th>Description</th>
                    <th>Batch/LOT No</th>
                    <!-- <th>MFD</th> -->
                    <th>EXD</th>
                    <!-- <th>Location Code</th> -->
                    <th class="text-right">Quantity Received</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($receipt_items)): ?>
                    <?php foreach ($receipt_items as $item): ?>
                        <tr>
                            <td><?= htmlspecialchars($item['sku_code']) ?></td>
                            <td><?= htmlspecialchars($item['sku_description']) ?></td>
                            <td><?= htmlspecialchars($item['batch_number']) ?></td>
                            <!-- <td><?= htmlspecialchars($item['mfd']) ?></td> -->
                            <td><?= htmlspecialchars($item['exd']) ?></td>
                            <!-- <td><?= htmlspecialchars($item['location_code']) ?></td> -->
                            <td class="text-right"><?= (int)$item['quantity'] ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center">No items found for this GRN.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="4" class="text-right"><strong>Total Quantity Received:</strong></td>
                    <td class="text-right"><strong><?= (int)$total_received_qty ?></strong></td>
                </tr>
            </tfoot>
        </table>

        <div class="signature-block">
            <div>
                <p class="signature-text">Prepared By:</p>
                <div class="signature-line"></div>
                <p>(<?= htmlspecialchars($_SESSION['username']) ?>)</p>
            </div>
            <div>
                <p class="signature-text">Checked By (Warehouse):</p>
                <div class="signature-line"></div>
                <p>_________________________</p>
            </div>
            <div>
                <p class="signature-text">Received By:</p>
                <div class="signature-line"></div>
                <p>_________________________</p>
            </div>
        </div>
    </div>

    <button class="no-print" onclick="window.print()">Print GRN</button>
</body>

</html>