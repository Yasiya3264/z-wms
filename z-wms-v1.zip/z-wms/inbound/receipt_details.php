<?php
session_start();
require '../inc/db.php';

if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    header("Location: ../");
    exit();
}

$compcode = $_SESSION['compcode'];
$message = '';
$receipt_id = isset($_GET['receipt_id']) ? (int)$_GET['receipt_id'] : 0;
$receipt_details = null;
$receipt_items = []; // Items already added to this receipt

if ($receipt_id <= 0) {
    header("Location: index.php"); // Redirect if no valid receipt_id
    exit();
}

// Fetch Receipt Header Details
$header_sql = "SELECT id, record_number, grn_number, grn_type, receiving_number, vehicle_number, receiving_date, status, created_at
               FROM inbound_receipts
               WHERE id = ? AND compcode = ? AND sku_code IS NULL"; // Crucial: Fetch the header record
$header_stmt = $conn->prepare($header_sql);
if ($header_stmt) {
    $header_stmt->bind_param("is", $receipt_id, $compcode);
    $header_stmt->execute();
    $header_result = $header_stmt->get_result();
    if ($header_result->num_rows > 0) {
        $receipt_details = $header_result->fetch_assoc();
    } else {
        $message = '<div class="error-message">Receipt not found or unauthorized. It might already be confirmed.</div>';
        $receipt_id = 0; // Invalidate receipt_id to prevent further processing
    }
    $header_stmt->close();
} else {
    $message = '<div class="error-message">Database error fetching receipt header: ' . htmlspecialchars($conn->error) . '</div>';
}

if ($receipt_id > 0 && $receipt_details) { // Only proceed if receipt header details are successfully loaded
    $record_number_for_items = $receipt_details['record_number'];

    // Fetch current items for this receipt from inbound_receipts table
    $items_sql = "SELECT ir.id as item_id, ir.sku_code, sm.sku_description, ir.batch_number, ir.mfd, ir.exd, ir.location_code, ir.quantity
                  FROM inbound_receipts ir
                  LEFT JOIN sku_master sm ON ir.sku_code = sm.sku_code AND ir.compcode = sm.compcode
                  WHERE ir.record_number = ? AND ir.compcode = ? AND ir.sku_code IS NOT NULL
                  ORDER BY ir.created_at ASC";
    $items_stmt = $conn->prepare($items_sql);
    if ($items_stmt) {
        $items_stmt->bind_param("ss", $record_number_for_items, $compcode);
        $items_stmt->execute();
        $items_result = $items_stmt->get_result();
        while ($row = $items_result->fetch_assoc()) {
            $receipt_items[] = $row;
        }
        $items_stmt->close();
    } else {
        $message .= '<div class="error-message">Database error fetching receipt items: ' . htmlspecialchars($conn->error) . '</div>';
    }

    // Handle AJAX POST requests for adding/deleting items or confirming receipt
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
        // Prevent modifications if already confirmed using the 'status' column
        if ($receipt_details['status'] === 'confirmed') {
            echo json_encode(['status' => 'error', 'message' => 'This receipt has already been confirmed and cannot be modified.']);
            exit();
        }

        if ($_POST['action'] === 'add_sku_item') {
            $sku_code = trim($_POST['sku_code']);
            $batch_number = trim($_POST['batch_number']);
            $mfd = trim($_POST['mfd']);
            $exd = trim($_POST['exd']);
            $full_amount_received = (int)$_POST['full_amount_received']; // Changed to full_amount_received

            if (empty($sku_code) || empty($batch_number) || empty($mfd) || empty($exd) || $full_amount_received <= 0) {
                echo json_encode(['status' => 'error', 'message' => 'All SKU details (Code, Batch, MFD, EXD, Full Amount Received) are required.']);
                exit();
            }

            // Basic date validation
            if (!strtotime($mfd) || !strtotime($exd)) {
                echo json_encode(['status' => 'error', 'message' => 'Invalid MFD or EXD date format.']);
                exit();
            }

            $conn->begin_transaction();
            try {
                // 1. Fetch EPP for the SKU
                $epp_sql = "SELECT epp FROM sku_master WHERE compcode = ? AND sku_code = ?";
                $epp_stmt = $conn->prepare($epp_sql);
                if (!$epp_stmt) {
                    throw new Exception("Error preparing EPP fetch: " . $conn->error);
                }
                $epp_stmt->bind_param("ss", $compcode, $sku_code);
                $epp_stmt->execute();
                $epp_result = $epp_stmt->get_result();
                $sku_epp = 0;
                if ($row = $epp_result->fetch_assoc()) {
                    $sku_epp = (int)$row['epp'];
                }
                $epp_stmt->close();

                if ($sku_epp <= 0) {
                    throw new Exception("SKU EPP (Each Per Pallet) not found or is invalid for " . htmlspecialchars($sku_code) . ". Cannot allocate locations.");
                }

                // 2. Calculate quantities per pallet and number of allocations needed
                $remaining_quantity = $full_amount_received;
                $allocated_items_count = 0;

                while ($remaining_quantity > 0) {
                    $quantity_for_this_allocation = min($remaining_quantity, $sku_epp);

                    // 3. Find an available location using the provided SQL logic
                    $location_sql = "
                        SELECT wl.location_code
                        FROM warehouse_locations wl
                        LEFT JOIN inventory i ON wl.location_code = i.location_code AND i.compcode = ?
                        WHERE wl.status = 1
                        AND NOT EXISTS (
                            SELECT 1
                            FROM inbound_receipts ir
                            WHERE ir.status = 'draft'
                            AND ir.location_code IS NOT NULL
                            AND ir.location_code = wl.location_code
                        )
                        GROUP BY wl.location_code
                        HAVING
                            SUM(CASE WHEN i.in_hand_qty IS NOT NULL THEN i.in_hand_qty ELSE 0 END) < 1
                            OR COUNT(i.location_code) = 0
                        ORDER BY wl.location_code ASC
                        LIMIT 1
                    ";
                    $location_stmt = $conn->prepare($location_sql);
                    if (!$location_stmt) {
                        throw new Exception("Error preparing location fetch: " . $conn->error);
                    }
                    $location_stmt->bind_param("s", $compcode); // Only compcode is needed for this query
                    $location_stmt->execute();
                    $location_result = $location_stmt->get_result();
                    $allocated_location_code = null;
                    if ($row = $location_result->fetch_assoc()) {
                        $allocated_location_code = $row['location_code'];
                    }
                    $location_stmt->close();

                    if (empty($allocated_location_code)) {
                        throw new Exception("No suitable warehouse location found for allocation. Please add more locations or clear existing ones.");
                    }

                    // 4. Insert into inbound_receipts as a line item for this allocation
                    $insert_item_sql = "INSERT INTO inbound_receipts (compcode, record_number, grn_type, receiving_number, vehicle_number, receiving_date, status, sku_code, batch_number, mfd, exd, quantity, location_code)
                                       VALUES (?, ?, ?, ?, ?, CURDATE(), 'draft', ?, ?, ?, ?, ?, ?)";
                    $insert_item_stmt = $conn->prepare($insert_item_sql);
                    if (!$insert_item_stmt) {
                        throw new Exception("Error preparing inbound item insert: " . $conn->error);
                    }
                    $insert_item_stmt->bind_param(
                        "sssssssssis",
                        $compcode,
                        $record_number_for_items,
                        $receipt_details['grn_type'],
                        $receipt_details['receiving_number'],
                        $receipt_details['vehicle_number'],
                        $sku_code,
                        $batch_number,
                        $mfd,
                        $exd,
                        $quantity_for_this_allocation,
                        $allocated_location_code
                    );
                    if (!$insert_item_stmt->execute()) {
                        throw new Exception("Error inserting inbound item for SKU " . htmlspecialchars($sku_code) . " at location " . htmlspecialchars($allocated_location_code) . ": " . $insert_item_stmt->error);
                    }
                    $insert_item_stmt->close();

                    $remaining_quantity -= $quantity_for_this_allocation;
                    $allocated_items_count++;
                }

                $conn->commit();
                echo json_encode(['status' => 'success', 'message' => 'SKU item(s) added and allocated across ' . $allocated_items_count . ' locations successfully.']);
            } catch (Exception $e) {
                $conn->rollback();
                echo json_encode(['status' => 'error', 'message' => 'Transaction failed: ' . $e->getMessage()]);
            }
            exit();
        } elseif ($_POST['action'] === 'manual_add_sku_item') {
            // New logic for manual putaway
            $sku_code = trim($_POST['sku_code']);
            $batch_number = trim($_POST['batch_number']);
            $mfd = trim($_POST['mfd']);
            $exd = trim($_POST['exd']);
            $quantity = (int)$_POST['quantity'];
            $location_code = trim($_POST['location_code']);

            if (empty($sku_code) || empty($batch_number) || empty($mfd) || empty($exd) || $quantity <= 0 || empty($location_code)) {
                echo json_encode(['status' => 'error', 'message' => 'All details are required.']);
                exit();
            }

            $conn->begin_transaction();
            try {
                // Check if the selected location is valid (no need to check for empty)
                $check_location_sql = "
                    SELECT location_code
                    FROM warehouse_locations
                    WHERE location_code = ? AND status = 1
                ";
                $check_location_stmt = $conn->prepare($check_location_sql);
                $check_location_stmt->bind_param("s", $location_code);
                $check_location_stmt->execute();
                $check_location_result = $check_location_stmt->get_result();

                if ($check_location_result->num_rows === 0) {
                    throw new Exception("The selected location is not valid or is inactive.");
                }
                $check_location_stmt->close();

                // Insert into inbound_receipts as a line item for this allocation
                $insert_item_sql = "INSERT INTO inbound_receipts (compcode, record_number, grn_type, receiving_number, vehicle_number, receiving_date, status, sku_code, batch_number, mfd, exd, quantity, location_code)
                                   VALUES (?, ?, ?, ?, ?, CURDATE(), 'draft', ?, ?, ?, ?, ?, ?)";
                $insert_item_stmt = $conn->prepare($insert_item_sql);
                $insert_item_stmt->bind_param(
                    "sssssssssis",
                    $compcode,
                    $record_number_for_items,
                    $receipt_details['grn_type'],
                    $receipt_details['receiving_number'],
                    $receipt_details['vehicle_number'],
                    $sku_code,
                    $batch_number,
                    $mfd,
                    $exd,
                    $quantity,
                    $location_code
                );
                if (!$insert_item_stmt->execute()) {
                    throw new Exception("Error inserting inbound item for SKU " . htmlspecialchars($sku_code) . ": " . $insert_item_stmt->error);
                }
                $insert_item_stmt->close();

                $conn->commit();
                echo json_encode(['status' => 'success', 'message' => 'SKU item added to location ' . $location_code . ' successfully.']);
            } catch (Exception $e) {
                $conn->rollback();
                echo json_encode(['status' => 'error', 'message' => 'Transaction failed: ' . $e->getMessage()]);
            }
            exit();
        } elseif ($_POST['action'] === 'delete_item') {
            $item_id_to_delete = (int)$_POST['item_id'];

            $conn->begin_transaction();
            try {
                // Delete the item from inbound_receipts
                $delete_item_sql = "DELETE FROM inbound_receipts WHERE id = ? AND compcode = ? AND record_number = ? AND sku_code IS NOT NULL";
                $delete_item_stmt = $conn->prepare($delete_item_sql);
                if (!$delete_item_stmt) {
                    throw new Exception("Error preparing item deletion statement: " . $conn->error);
                }
                $delete_item_stmt->bind_param("iss", $item_id_to_delete, $compcode, $record_number_for_items);
                if (!$delete_item_stmt->execute()) {
                    throw new Exception("Error deleting inbound item: " . $delete_item_stmt->error);
                }

                if ($delete_item_stmt->affected_rows === 0) {
                    throw new Exception("Item not found or already deleted.");
                }
                $delete_item_stmt->close();

                $conn->commit();
                echo json_encode(['status' => 'success', 'message' => 'SKU item removed successfully.']);
            } catch (Exception $e) {
                $conn->rollback();
                echo json_encode(['status' => 'error', 'message' => 'Deletion failed: ' . $e->getMessage()]);
            }
            exit();
        } elseif ($_POST['action'] === 'confirm_receiving') {
            $conn->begin_transaction();
            try {
                // Get all items associated with this record_number
                $confirm_items_sql = "SELECT sku_code, batch_number, mfd, exd, location_code, quantity
                                      FROM inbound_receipts
                                      WHERE record_number = ? AND compcode = ? AND sku_code IS NOT NULL AND quantity > 0";
                $confirm_items_stmt = $conn->prepare($confirm_items_sql);
                if (!$confirm_items_stmt) {
                    throw new Exception("Error preparing confirmation item fetch: " . $conn->error);
                }
                $confirm_items_stmt->bind_param("ss", $record_number_for_items, $compcode);
                $confirm_items_stmt->execute();
                $confirm_result = $confirm_items_stmt->get_result();

                if ($confirm_result->num_rows === 0) {
                    throw new Exception("No items found with quantity > 0 to confirm for this receipt.");
                }

                // --- New GRN Number Generation Logic ---
                // Format: [compcode]-[grn_type]-00001
                $grn_prefix = $compcode . '-' . $receipt_details['grn_type'] . '-';

                // Find the highest existing GRN number for this type/compcode
                // The LIKE pattern should now be [compcode]-[type]- followed by 5 digits
                $max_grn_sql = "SELECT grn_number FROM inbound_receipts
                               WHERE compcode = ? AND grn_number LIKE ? AND sku_code IS NULL AND status = 'confirmed'
                               ORDER BY grn_number DESC LIMIT 1";
                $max_grn_stmt = $conn->prepare($max_grn_sql);
                if (!$max_grn_stmt) {
                    throw new Exception("Error preparing max GRN query: " . $conn->error);
                }
                // The LIKE parameter should match the exact format: [compcode]-[type]- followed by 5 digits
                $grn_like_param = $grn_prefix . '_____'; // 5 underscores for 5 digits
                $max_grn_stmt->bind_param("ss", $compcode, $grn_like_param);
                $max_grn_stmt->execute();
                $max_grn_result = $max_grn_stmt->get_result();
                $last_grn_number = '';
                if ($max_grn_row = $max_grn_result->fetch_assoc()) {
                    $last_grn_number = $max_grn_row['grn_number'];
                }
                $max_grn_stmt->close();

                $next_grn_sequence = 1;
                if (!empty($last_grn_number)) {
                    // Use regex to extract the numeric sequence from the end of the string
                    // This regex specifically looks for 5 digits at the end after a hyphen
                    if (preg_match('/-(\d{5})$/', $last_grn_number, $matches)) {
                        $next_grn_sequence = (int)$matches[1] + 1;
                    }
                }
                // The sprintf now just pads the sequence number to 5 digits
                $final_grn_number = $grn_prefix . sprintf('%05d', $next_grn_sequence); // 5 digits, padded

                while ($item = $confirm_result->fetch_assoc()) {
                    // 1. Update/Insert into Inventory
                    // Check if SKU, Batch, Location exists in inventory for compcode
                    $check_inv_sql = "SELECT id FROM inventory WHERE compcode = ? AND sku_code = ? AND batch_number = ? AND location_code = ?";
                    $check_inv_stmt = $conn->prepare($check_inv_sql);
                    if (!$check_inv_stmt) {
                        throw new Exception("Error preparing inventory check: " . $conn->error);
                    }
                    $check_inv_stmt->bind_param("ssss", $compcode, $item['sku_code'], $item['batch_number'], $item['location_code']);
                    $check_inv_stmt->execute();
                    $inv_exists_result = $check_inv_stmt->get_result();
                    $check_inv_stmt->close();

                    if ($inv_exists_result->num_rows > 0) {
                        // Update existing inventory record
                        $update_inv_sql = "UPDATE inventory SET in_hand_qty = in_hand_qty + ?, exd = ?, mfd = ? WHERE compcode = ? AND sku_code = ? AND batch_number = ? AND location_code = ?";
                        $update_inv_stmt = $conn->prepare($update_inv_sql);
                        if (!$update_inv_stmt) {
                            throw new Exception("Error preparing inventory update: " . $conn->error);
                        }
                        $update_inv_stmt->bind_param("issssss", $item['quantity'], $item['exd'], $item['mfd'], $compcode, $item['sku_code'], $item['batch_number'], $item['location_code']);
                        if (!$update_inv_stmt->execute()) {
                            throw new Exception("Error updating inventory for SKU " . htmlspecialchars($item['sku_code']) . ": " . $update_inv_stmt->error);
                        }
                        $update_inv_stmt->close();
                    } else {
                        // Insert new inventory record
                        $insert_inv_sql = "INSERT INTO inventory (compcode, sku_code, location_code, batch_number, mfd, exd, grn_number, received_date, in_hand_qty, allocated_qty) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0)";
                        $insert_inv_stmt = $conn->prepare($insert_inv_sql);
                        if (!$insert_inv_stmt) {
                            throw new Exception("Error preparing inventory insert: " . $conn->error);
                        }
                        $insert_inv_stmt->bind_param("ssssssssi", $compcode, $item['sku_code'], $item['location_code'], $item['batch_number'], $item['mfd'], $item['exd'], $final_grn_number, $receipt_details['receiving_date'], $item['quantity']);
                        if (!$insert_inv_stmt->execute()) {
                            throw new Exception("Error inserting new inventory for SKU " . htmlspecialchars($item['sku_code']) . ": " . $insert_inv_stmt->error);
                        }
                        $insert_inv_stmt->close();

                        // Update warehouse_locations.is_used if it's currently 0 or NULL for this location
                        $update_location_used_sql = "UPDATE warehouse_locations SET is_used = 1 WHERE location_code = ? AND (is_used = 0 OR is_used IS NULL)";
                        $update_location_used_stmt = $conn->prepare($update_location_used_sql);
                        if (!$update_location_used_stmt) {
                            throw new Exception("Error preparing location update: " . $conn->error);
                        }
                        $update_location_used_stmt->bind_param("s", $item['location_code']);
                        $update_location_used_stmt->execute();
                        $update_location_used_stmt->close();
                    }

                    // 2. Insert into Inbound History
                    $insert_history_sql = "INSERT INTO inbound_history (compcode, record_number, grn_number, receiving_type, receiving_number, receiving_date, vehicle_number, sku_code, mfd, exd, quantity, status)
                                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'confirmed')";
                    $insert_history_stmt = $conn->prepare($insert_history_sql);
                    if (!$insert_history_stmt) {
                        throw new Exception("Error preparing inbound history insert: " . $conn->error);
                    }
                    $insert_history_stmt->bind_param(
                        "sssssssssss",
                        $compcode,
                        $record_number_for_items,
                        $final_grn_number,
                        $receipt_details['grn_type'],
                        $receipt_details['receiving_number'],
                        $receipt_details['receiving_date'],
                        $receipt_details['vehicle_number'],
                        $item['sku_code'],
                        $item['mfd'],
                        $item['exd'],
                        $item['quantity']
                    );
                    if (!$insert_history_stmt->execute()) {
                        throw new Exception("Error inserting into inbound history for SKU " . htmlspecialchars($item['sku_code']) . ": " . $insert_history_stmt->error);
                    }
                    $insert_history_stmt->close();
                }
                $confirm_items_stmt->close();

                // Update the main inbound_receipts header record with the final GRN number
                // and set its status to 'confirmed'
                $update_header_sql = "UPDATE inbound_receipts SET grn_number = ?, status = 'confirmed' WHERE id = ? AND compcode = ? AND sku_code IS NULL";
                $update_header_stmt = $conn->prepare($update_header_sql);
                if (!$update_header_stmt) {
                    throw new Exception("Error preparing GRN update for header: " . $conn->error);
                }
                $update_header_stmt->bind_param("sis", $final_grn_number, $receipt_id, $compcode);
                if (!$update_header_stmt->execute()) {
                    throw new Exception("Error updating GRN number and status for receipt header: " . $update_header_stmt->error);
                }
                $update_header_stmt->close();

                // Update all line items with the new GRN number and set status to 'confirmed'
                $update_items_sql = "UPDATE inbound_receipts SET grn_number = ?, status = 'confirmed' WHERE record_number = ? AND compcode = ? AND sku_code IS NOT NULL";
                $update_items_stmt = $conn->prepare($update_items_sql);
                if (!$update_items_stmt) {
                    throw new Exception("Error preparing GRN update for line items: " . $conn->error);
                }
                $update_items_stmt->bind_param("sss", $final_grn_number, $record_number_for_items, $compcode);
                if (!$update_items_stmt->execute()) {
                    throw new Exception("Error updating GRN number and status for line items: " . $update_items_stmt->error);
                }
                $update_items_stmt->close();


                $conn->commit();
                echo json_encode(['status' => 'success', 'message' => 'Receiving confirmed! GRN Number: ' . $final_grn_number, 'grn_number' => $final_grn_number, 'receipt_id' => $receipt_id]);
            } catch (Exception $e) {
                $conn->rollback();
                echo json_encode(['status' => 'error', 'message' => 'Confirmation failed: ' . $e->getMessage()]);
            }
            exit();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Zynex WMS | Receipt Details</title>
    <link rel="stylesheet" href="../inc/global.css">
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <style>
        .details-container,
        .form-container,
        .table-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .details-container h3,
        .form-container h3,
        .table-container h3 {
            color: var(--primary-color);
            margin-bottom: 15px;
        }

        .details-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px 20px;
            margin-bottom: 20px;
        }

        .details-grid div strong {
            display: inline-block;
            width: 150px;
            /* Align labels */
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }

        .form-group input[type="text"],
        .form-group select,
        .form-group input[type="number"],
        .form-group input[type="date"] {
            width: calc(100% - 16px);
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button,
        .form-group button,
        .action-buttons button {
            background-color: var(--btn-prim);
            color: var(--btn-text);
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
            margin-right: 10px;
        }

        .form-group button:hover,
        .action-buttons button:hover {
            background-color: var(--btn-hover);
        }

        .action-buttons {
            margin-top: 20px;
            text-align: right;
        }

        .action-buttons button.red-btn {
            background-color: #dc3545;
        }

        .action-buttons button.red-btn:hover {
            background-color: #c82333;
        }

        .item-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .item-table th,
        .item-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
            font-size: 14px;
        }

        .item-table th {
            background-color: #f2f2f2;
            color: #555;
            font-weight: bold;
        }

        .item-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .item-table tr:hover {
            background-color: #f1f1f1;
        }

        .error-message {
            color: #d9534f;
            background-color: #f2dede;
            border: 1px solid #ebccd1;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
        }

        .success-message {
            color: #5cb85c;
            background-color: #dff0d8;
            border: 1px solid #d6e9c6;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
        }

        #sku_suggestions,
        #location_suggestions_manual {
            margin-top: 5px;
            border: 1px solid #ccc;
            max-height: 200px;
            overflow-y: auto;
            background-color: #f9f9f9;
            padding: 5px;
            position: absolute;
            /* Crucial for overlay */
            z-index: 1000;
            /* Ensure it's above other elements */
            width: 80%;
            /* Match input width */
        }

        #sku_suggestions div,
        #location_suggestions_manual div {
            padding: 8px;
            border-bottom: 1px dotted #eee;
            cursor: pointer;
        }

        #sku_suggestions div:last-child,
        #location_suggestions_manual div:last-child {
            border-bottom: none;
        }

        #sku_suggestions div:hover,
        #location_suggestions_manual div:hover {
            background-color: #e6e6e6;
        }

        .read-only {
            background-color: #f0f0f0;
            cursor: not-allowed;
        }

        .action-cell {
            white-space: nowrap;
            /* Prevent buttons from wrapping */
        }
    </style>
</head>

<body>
    <?php require '../parts/nav.php'; ?>
    <div id="main" class="main">
        <h2>Inbound Receipt Details</h2>
        <?php echo $message; ?>

        <?php if ($receipt_details): ?>
            <div class="details-container">
                <h3>Receipt Header</h3>
                <div class="details-grid">
                    <div><strong>Record No:</strong> <?= htmlspecialchars($receipt_details['record_number']) ?></div>
                    <div><strong>Receiving No:</strong> <?= htmlspecialchars($receipt_details['receiving_number']) ?></div>
                    <div><strong>Receiving Type:</strong> <?= htmlspecialchars($receipt_details['grn_type']) ?></div>
                    <div><strong>Receiving Date:</strong> <?= htmlspecialchars($receipt_details['receiving_date']) ?></div>
                    <div><strong>Vehicle Details:</strong> <?= htmlspecialchars($receipt_details['vehicle_number'] ?: 'N/A') ?></div>
                    <div><strong>Created At:</strong> <?= htmlspecialchars($receipt_details['created_at']) ?></div>
                    <div><strong>Status:</strong> <?= ($receipt_details['status'] === 'confirmed') ? '<span style="color: green; font-weight: bold;">CONFIRMED</span>' : '<span style="color: orange; font-weight: bold;">DRAFT</span>' ?></div>
                    <?php if ($receipt_details['status'] === 'confirmed' && !empty($receipt_details['grn_number'])): ?>
                        <div><strong>GRN No:</strong> <?= htmlspecialchars($receipt_details['grn_number']) ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <div id="add_sku_form_container" class="form-container">
                <h3>Automatic Putaway</h3>
                <form id="add_sku_form">
                    <div class="form-group">
                        <label for="sku_code_auto">SKU Code:</label>
                        <input type="text" id="sku_code_auto" name="sku_code" placeholder="Start typing SKU Code" required />
                        <div id="sku_suggestions_auto"></div>
                    </div>
                    <div class="form-group">
                        <label for="batch_number_auto">Batch/LOT No:</label>
                        <input type="text" id="batch_number_auto" name="batch_number" required />
                    </div>
                    <div class="form-group">
                        <label for="mfd_auto">MFD:</label>
                        <input type="date" id="mfd_auto" name="mfd" required />
                    </div>
                    <div class="form-group">
                        <label for="exd_auto">EXD:</label>
                        <input type="date" id="exd_auto" name="exd" required />
                    </div>
                    <div class="form-group">
                        <label for="full_amount_received">Full Amount Received:</label>
                        <input type="number" id="full_amount_received" name="full_amount_received" min="1" required />
                    </div>
                    <button type="submit">Add Item & Allocate Automatically</button>
                </form>
            </div>

            <div id="manual_putaway_form_container" class="form-container">
                <h3>Manual Putaway</h3>
                <form id="manual_add_sku_form">
                    <div class="form-group">
                        <label for="sku_code_manual">SKU Code:</label>
                        <input type="text" id="sku_code_manual" name="sku_code" placeholder="Start typing SKU Code" required />
                        <div id="sku_suggestions_manual"></div>
                    </div>
                    <div class="form-group">
                        <label for="batch_number_manual">Batch/LOT No:</label>
                        <input type="text" id="batch_number_manual" name="batch_number" required />
                    </div>
                    <div class="form-group">
                        <label for="mfd_manual">MFD:</label>
                        <input type="date" id="mfd_manual" name="mfd" required />
                    </div>
                    <div class="form-group">
                        <label for="exd_manual">EXD:</label>
                        <input type="date" id="exd_manual" name="exd" required />
                    </div>
                    <div class="form-group">
                        <label for="quantity_manual">Quantity:</label>
                        <input type="number" id="quantity_manual" name="quantity" min="1" required />
                    </div>
                    <div class="form-group">
                        <label for="location_code_manual">Warehouse Location:</label>
                        <input type="text" id="location_code_manual" name="location_code" required autocomplete="off" placeholder="Start typing location code" />
                        <div id="location_suggestions_manual" class="suggestions-box"></div>
                    </div>
                    <button type="submit">Add Item & Save</button>
                </form>
            </div>

            <div class="table-container">
                <h3>Receipt Items</h3>
                <table class="item-table">
                    <thead>
                        <tr>
                            <th>SKU Code</th>
                            <th>Description</th>
                            <th>Batch No</th>
                            <th>MFD</th>
                            <th>EXD</th>
                            <th>Location</th>
                            <th class="text-right">Quantity</th>
                            <th class="action-cell">Action</th>
                        </tr>
                    </thead>
                    <tbody id="receiptItemsTableBody">
                        <?php if (!empty($receipt_items)): ?>
                            <?php foreach ($receipt_items as $item): ?>
                                <tr data-item-id="<?= (int)$item['item_id'] ?>">
                                    <td><?= htmlspecialchars($item['sku_code']) ?></td>
                                    <td><?= htmlspecialchars($item['sku_description']) ?></td>
                                    <td><?= htmlspecialchars($item['batch_number']) ?></td>
                                    <td><?= htmlspecialchars($item['mfd']) ?></td>
                                    <td><?= htmlspecialchars($item['exd']) ?></td>
                                    <td><?= htmlspecialchars($item['location_code']) ?></td>
                                    <td class="text-right"><?= (int)$item['quantity'] ?></td>
                                    <td class="action-cell">
                                        <button class="delete-item-btn red-btn" data-item-id="<?= (int)$item['item_id'] ?>">Delete</button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr id="no_items_row">
                                <td colspan="8" class="text-center">No items added to this receipt yet.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <div class="action-buttons">
                    <button id="printLpnBtn">Print LPNs</button>
                    <?php if ($receipt_details['status'] === 'confirmed'): ?>
                        <button id="printGrnBtn" data-grn-number="<?= htmlspecialchars($receipt_details['grn_number']) ?>">Print GRN</button>
                    <?php else: ?>
                        <button id="confirmReceivingBtn">Confirm Receiving</button>
                    <?php endif; ?>
                </div>
            </div>

        <?php endif; ?>
    </div>

    <script>
        $(document).ready(function() {
            const receiptId = <?= (int)$receipt_id ?>;
            const isConfirmed = <?= ($receipt_details['status'] === 'confirmed') ? 'true' : 'false' ?>;

            function displayMessage(type, message) {
                const messageDiv = $('#main');
                const html = `<div class="${type}-message">${message}</div>`;
                messageDiv.prepend(html);
                setTimeout(function() {
                    messageDiv.find(`.${type}-message`).fadeOut(500, function() {
                        $(this).remove();
                    });
                }, 5000);
            }

            // SKU Search Autocomplete/Selection for AUTO form
            $('#sku_code_auto').on('input', function() {
                const sku_code_search = $(this).val();
                const skuSuggestions = $('#sku_suggestions_auto');
                skuSuggestions.empty();
                if (sku_code_search.length < 2) {
                    return;
                }

                $.ajax({
                    url: 'fetch_skus_for_inbound.php',
                    method: 'GET',
                    data: {
                        sku_code: sku_code_search
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === 'success' && response.data.length > 0) {
                            response.data.forEach(item => {
                                skuSuggestions.append(
                                    `<div data-sku="${item.sku_code}">${item.sku_code} - ${item.sku_description} (EPP: ${item.epp})</div>`
                                );
                            });
                            skuSuggestions.show();
                        } else {
                            skuSuggestions.append('<div>No SKU found.</div>').show();
                        }
                    },
                    error: function(xhr, status, error) {
                        skuSuggestions.append('<div>Error fetching SKUs.</div>').show();
                        console.error("AJAX error: ", status, error, xhr.responseText);
                    }
                });
            });

            $('#sku_suggestions_auto').on('click', 'div', function() {
                const selectedSku = $(this).data('sku');
                $('#sku_code_auto').val(selectedSku);
                $('#sku_suggestions_auto').empty().hide();
            });

            // SKU Search Autocomplete/Selection for MANUAL form
            $('#sku_code_manual').on('input', function() {
                const sku_code_search = $(this).val();
                const skuSuggestions = $('#sku_suggestions_manual');
                skuSuggestions.empty();
                if (sku_code_search.length < 2) {
                    return;
                }

                $.ajax({
                    url: 'fetch_skus_for_inbound.php',
                    method: 'GET',
                    data: {
                        sku_code: sku_code_search
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === 'success' && response.data.length > 0) {
                            response.data.forEach(item => {
                                skuSuggestions.append(
                                    `<div data-sku="${item.sku_code}">${item.sku_code} - ${item.sku_description}</div>`
                                );
                            });
                            skuSuggestions.show();
                        } else {
                            skuSuggestions.append('<div>No SKU found.</div>').show();
                        }
                    },
                    error: function(xhr, status, error) {
                        skuSuggestions.append('<div>Error fetching SKUs.</div>').show();
                        console.error("AJAX error: ", status, error, xhr.responseText);
                    }
                });
            });

            $('#sku_suggestions_manual').on('click', 'div', function() {
                const selectedSku = $(this).data('sku');
                $('#sku_code_manual').val(selectedSku);
                $('#sku_suggestions_manual').empty().hide();
            });

            // NEW: Location Search Autocomplete/Selection for MANUAL form
            $('#location_code_manual').on('input', function() {
                const location_code_search = $(this).val();
                const locationSuggestions = $('#location_suggestions_manual');
                locationSuggestions.empty();
                if (location_code_search.length < 2) {
                    return;
                }

                $.ajax({
                    url: 'fetch_all_locations.php', // Call the new file
                    method: 'GET',
                    data: {
                        location_code: location_code_search
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === 'success' && response.data.length > 0) {
                            response.data.forEach(item => {
                                locationSuggestions.append(
                                    `<div data-location="${item.location_code}">${item.location_code}</div>`
                                );
                            });
                            locationSuggestions.show();
                        } else {
                            locationSuggestions.append('<div>No locations found.</div>').show();
                        }
                    },
                    error: function(xhr, status, error) {
                        displayMessage('error', 'An error occurred fetching locations. Please check the console for details.');
                        console.error("AJAX error: ", status, error, xhr.responseText);
                    }
                });
            });

            $('#location_suggestions_manual').on('click', 'div', function() {
                const selectedLocation = $(this).data('location');
                $('#location_code_manual').val(selectedLocation);
                $('#location_suggestions_manual').empty().hide();
            });

            // Hide suggestions when clicking outside
            $(document).on('click', function(e) {
                if (!$(e.target).closest('#sku_code_auto, #sku_suggestions_auto, #sku_code_manual, #sku_suggestions_manual, #location_code_manual, #location_suggestions_manual').length) {
                    $('#sku_suggestions_auto').hide();
                    $('#sku_suggestions_manual').hide();
                    $('#location_suggestions_manual').hide();
                }
            });


            // Handle Add Item Form Submission (Automatic Putaway)
            $('#add_sku_form').on('submit', function(e) {
                e.preventDefault();

                const sku_code = $('#sku_code_auto').val();
                const batch_number = $('#batch_number_auto').val();
                const mfd = $('#mfd_auto').val();
                const exd = $('#exd_auto').val();
                const full_amount_received = parseInt($('#full_amount_received').val());

                if (!sku_code || !batch_number || !mfd || !exd || isNaN(full_amount_received) || full_amount_received <= 0) {
                    displayMessage('error', 'Please fill all required fields correctly.');
                    return;
                }

                $.ajax({
                    url: window.location.href, // Post to the same page
                    method: 'POST',
                    data: {
                        action: 'add_sku_item',
                        receipt_id: receiptId,
                        sku_code: sku_code,
                        batch_number: batch_number,
                        mfd: mfd,
                        exd: exd,
                        full_amount_received: full_amount_received // Changed to full_amount_received
                    },
                    dataType: 'json',
                    success: function(response) {
                        displayMessage(response.status, response.message);
                        if (response.status === 'success') {
                            window.location.reload(); // Reload to show updated items
                        }
                    },
                    error: function(xhr, status, error) {
                        displayMessage('error', 'An error occurred: ' + (xhr.responseJSON ? xhr.responseJSON.message : error));
                        console.error("AJAX error: ", status, error, xhr.responseText);
                    }
                });
            });

            // Handle Add Item Form Submission (Manual Putaway)
            $('#manual_add_sku_form').on('submit', function(e) {
                e.preventDefault();

                const sku_code = $('#sku_code_manual').val();
                const batch_number = $('#batch_number_manual').val();
                const mfd = $('#mfd_manual').val();
                const exd = $('#exd_manual').val();
                const quantity = parseInt($('#quantity_manual').val());
                const location_code = $('#location_code_manual').val();

                if (!sku_code || !batch_number || !mfd || !exd || isNaN(quantity) || quantity <= 0 || !location_code) {
                    displayMessage('error', 'Please fill all fields correctly for manual putaway.');
                    return;
                }

                $.ajax({
                    url: window.location.href, // Post to the same page
                    method: 'POST',
                    data: {
                        action: 'manual_add_sku_item',
                        receipt_id: receiptId,
                        sku_code: sku_code,
                        batch_number: batch_number,
                        mfd: mfd,
                        exd: exd,
                        quantity: quantity,
                        location_code: location_code
                    },
                    dataType: 'json',
                    success: function(response) {
                        displayMessage(response.status, response.message);
                        if (response.status === 'success') {
                            window.location.reload(); // Reload to show updated items
                        }
                    },
                    error: function(xhr, status, error) {
                        displayMessage('error', 'An error occurred: ' + (xhr.responseJSON ? xhr.responseJSON.message : error));
                        console.error("AJAX error: ", status, error, xhr.responseText);
                    }
                });
            });

            // Handle Delete Item Button
            $('#receiptItemsTableBody').on('click', '.delete-item-btn', function() {
                // Replace confirm with a custom modal if needed, but for now, keep it.
                if (!confirm('Are you sure you want to remove this item?')) {
                    return;
                }

                const itemId = $(this).data('item-id');
                $.ajax({
                    url: window.location.href,
                    method: 'POST',
                    data: {
                        action: 'delete_item',
                        receipt_id: receiptId,
                        item_id: itemId
                    },
                    dataType: 'json',
                    success: function(response) {
                        displayMessage(response.status, response.message);
                        if (response.status === 'success') {
                            window.location.reload();
                        }
                    },
                    error: function(xhr, status, error) {
                        displayMessage('error', 'An error occurred: ' + (xhr.responseJSON ? xhr.responseJSON.message : error));
                    }
                });
            });

            // Handle Confirm Receiving Button
            $('#confirmReceivingBtn').on('click', function() {
                if ($('#receiptItemsTableBody tr').length === 0 || $('#receiptItemsTableBody tr#no_items_row').length > 0) {
                    displayMessage('error', 'No items to confirm receiving for.');
                    return;
                }
                // Replace confirm with a custom modal if needed, but for now, keep it.
                if (!confirm('Are you sure you want to confirm this receiving? This action will update inventory and cannot be undone.')) {
                    return;
                }

                $.ajax({
                    url: window.location.href,
                    method: 'POST',
                    data: {
                        action: 'confirm_receiving',
                        receipt_id: receiptId
                    },
                    dataType: 'json',
                    success: function(response) {
                        displayMessage(response.status, response.message);
                        if (response.status === 'success') {
                            window.location.reload(); // Reload to show confirmed state and GRN button
                        }
                    },
                    error: function(xhr, status, error) {
                        displayMessage('error', 'An error occurred during receiving confirmation: ' + (xhr.responseJSON ? xhr.responseJSON.message : error));
                        console.error("AJAX error: ", status, error, xhr.responseText);
                    }
                });
            });

            // Handle Print LPNs Button
            $('#printLpnBtn').on('click', function() {
                if ($('#receiptItemsTableBody tr').length === 0 || $('#receiptItemsTableBody tr#no_items_row').length > 0) {
                    displayMessage('error', 'No items to print LPNs for.');
                    return;
                }
                // Open new window for LPN printing, passing receipt_id
                // The print_lpn.php will fetch all items for this receipt_id and generate LPNs
                window.open('print_lpn.php?receipt_id=' + receiptId, '_blank');
            });

            // Handle Print GRN Button (for already confirmed receipts)
            $('#printGrnBtn').on('click', function() {
                const grnNumber = $(this).data('grn-number');
                window.open('print_grn.php?receipt_id=' + receiptId + '&grn_number=' + grnNumber, '_blank');
            });

            // Initial state adjustments if the receipt is already confirmed
            if (isConfirmed) {
                $('#add_sku_form_container, #manual_putaway_form_container').hide();
                $('.delete-item-btn').prop('disabled', true).hide();
                // Remove action column header for confirmed receipts
                $('#receiptItemsTableBody').closest('table').find('thead th:last-child').remove();
            }
        });
    </script>
</body>

</html>