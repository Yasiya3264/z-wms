<?php
session_start();
require '../inc/db.php'; // Adjust path if necessary

if (empty($_SESSION['username']) || empty($_SESSION['compcode'])) {
    header("Location: ../");
    exit();
}

$compcode = $_SESSION['compcode'];
$message = '';

// Get date filter parameters from GET request
$filter_start_date = isset($_GET['start_date']) ? $_GET['start_date'] : '';
$filter_end_date = isset($_GET['end_date']) ? $_GET['end_date'] : '';

// Fetch Confirmed Inventory Transfer Records, joining with sku_master for smallest_cbm
$transfer_history_records = [];
$total_quantity_transferred = 0;
$total_cbm_transferred = 0;

$history_sql = "SELECT
                    it.id,
                    it.transfer_number,
                    it.from_sku_code,
                    sm.sku_description, -- Join to get SKU description
                    sm.smallest_cbm, -- Fetch smallest_cbm from sku_master
                    it.from_location_code,
                    it.from_batch_number,
                    it.from_mfd,
                    it.from_exd,
                    it.transfer_quantity,
                    it.to_location_code,
                    it.to_batch_number,
                    it.to_mfd,
                    it.to_exd,
                    it.created_by,
                    it.created_at
                FROM
                    inventory_transfers it
                LEFT JOIN
                    sku_master sm ON it.from_sku_code = sm.sku_code AND it.compcode = sm.compcode
                WHERE
                    it.compcode = ? AND it.status = 'confirmed'";

// Add date range filter to SQL query if dates are provided
if (!empty($filter_start_date) && !empty($filter_end_date)) {
    $history_sql .= " AND it.created_at BETWEEN ? AND ?";
} elseif (!empty($filter_start_date)) {
    $history_sql .= " AND it.created_at >= ?";
} elseif (!empty($filter_end_date)) {
    $history_sql .= " AND it.created_at <= ?";
}

$history_sql .= " ORDER BY it.created_at DESC";

$history_stmt = $conn->prepare($history_sql);
if ($history_stmt) {
    $param_types = "s";
    $params = [$compcode];

    if (!empty($filter_start_date) && !empty($filter_end_date)) {
        $param_types .= "ss";
        $params[] = $filter_start_date;
        $params[] = $filter_end_date;
    } elseif (!empty($filter_start_date)) {
        $param_types .= "s";
        $params[] = $filter_start_date;
    } elseif (!empty($filter_end_date)) {
        $param_types .= "s";
        $params[] = $filter_end_date;
    }

    // Fix for bind_param: arguments must be passed by reference
    $bind_params = [];
    $bind_params[] = &$param_types;
    for ($i = 0; $i < count($params); $i++) {
        $bind_params[] = &$params[$i];
    }

    call_user_func_array([$history_stmt, 'bind_param'], $bind_params);

    $history_stmt->execute();
    $history_result = $history_stmt->get_result();
    while ($row = $history_result->fetch_assoc()) {
        $transfer_history_records[] = $row;
        $total_quantity_transferred += (int)$row['transfer_quantity'];
        // Calculate CBM for each item and add to total
        $item_cbm = (float)$row['transfer_quantity'] * (float)($row['smallest_cbm'] ?? 0); // Use null coalescing
        $total_cbm_transferred += $item_cbm;
    }
    $history_stmt->close();
} else {
    $message .= '<div class="error-message">Database error fetching transfer history: ' . htmlspecialchars($conn->error) . '</div>';
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Zynex WMS | Transfer History</title>
    <link rel="stylesheet" href="../inc/global.css">
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <style>
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .container h3 {
            color: var(--primary-color);
            margin-bottom: 15px;
        }

        .filter-group {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 20px;
            padding: 15px;
            background-color: #f8f9fa;
            border-radius: 8px;
            border: 1px solid #e9ecef;
        }

        .filter-group label {
            align-self: center;
            font-weight: bold;
            color: #333;
        }

        .filter-group input[type="text"],
        .filter-group input[type="date"] {
            flex: 1;
            min-width: 150px;
            padding: 8px;
            border: 1px solid #ced4da;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .filter-group button {
            padding: 8px 15px;
            background-color: var(--btn-prim);
            color: var(--btn-text);
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .filter-group button:hover {
            background-color: var(--btn-hover);
        }

        .history-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .history-table th,
        .history-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
            font-size: 14px;
        }

        .history-table th {
            background-color: #f2f2f2;
            color: #555;
            font-weight: bold;
        }

        .history-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .history-table tr:hover {
            background-color: #f1f1f1;
        }

        .history-table tfoot td {
            font-weight: bold;
            background-color: #e9ecef;
        }

        .text-right {
            text-align: right;
        }

        .text-center {
            text-align: center;
        }

        .error-message {
            color: #d9534f;
            background-color: #f2dede;
            border: 1px solid #ebccd1;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
        }
    </style>
</head>

<body>
    <?php require '../parts/nav.php'; ?>
    <div id="main" class="main">
        <h2>Inventory Transfer History</h2>
        <?php echo $message; ?>

        <div class="container">
            <h3>Confirmed Inventory Transfers</h3>

            <!-- Date Range Filter Form (Server-Side) -->
            <form method="GET" action="" class="filter-group">
                <label for="start_date">Date From:</label>
                <input type="date" id="start_date" name="start_date" value="<?= htmlspecialchars($filter_start_date) ?>" />
                <label for="end_date">Date To:</label>
                <input type="date" id="end_date" name="end_date" value="<?= htmlspecialchars($filter_end_date) ?>" />
                <button type="submit">Apply Date Filter</button>
                <button type="button" id="clear_date_filters_btn">Clear Date Filters</button>
            </form>

            <!-- Client-Side Text Filters -->
            <div class="filter-group">
                <input type="text" id="filter_transfer_no" placeholder="Filter by Transfer No" />
                <input type="text" id="filter_from_sku" placeholder="Filter by From SKU" />
                <input type="text" id="filter_from_location" placeholder="Filter by From Location" />
                <input type="text" id="filter_to_location" placeholder="Filter by To Location" />
                <button id="clear_text_filters_btn">Clear Text Filters</button>
            </div>

            <table class="history-table">
                <thead>
                    <tr>
                        <th>Transfer No</th>
                        <th>From SKU</th>
                        <th>SKU Description</th>
                        <th>From Location</th>
                        <th>From Batch</th>
                        <th>From MFD</th>
                        <th>From EXD</th>
                        <th class="text-right">Quantity</th>
                        <th>To Location</th>
                        <th>To Batch</th>
                        <th>To MFD</th>
                        <th>To EXD</th>
                        <th>Transferred By</th>
                        <th>Transferred At</th>
                    </tr>
                </thead>
                <tbody id="historyTableBody">
                    <?php if (!empty($transfer_history_records)): ?>
                        <?php foreach ($transfer_history_records as $record): ?>
                            <tr
                                data-transfer-no="<?= htmlspecialchars($record['transfer_number'] ?: '') ?>"
                                data-from-sku="<?= htmlspecialchars($record['from_sku_code'] ?: '') ?>"
                                data-from-location="<?= htmlspecialchars($record['from_location_code'] ?: '') ?>"
                                data-to-location="<?= htmlspecialchars($record['to_location_code'] ?: '') ?>"
                                data-quantity="<?= (int)$record['transfer_quantity'] ?>"
                                data-cbm="<?= (float)$record['transfer_quantity'] * (float)($record['smallest_cbm'] ?? 0) ?>">
                                <td><?= htmlspecialchars($record['transfer_number']) ?></td>
                                <td><?= htmlspecialchars($record['from_sku_code']) ?></td>
                                <td><?= htmlspecialchars($record['sku_description'] ?: 'N/A') ?></td>
                                <td><?= htmlspecialchars($record['from_location_code']) ?></td>
                                <td><?= htmlspecialchars($record['from_batch_number'] ?: 'N/A') ?></td>
                                <td><?= htmlspecialchars($record['from_mfd'] ?: 'N/A') ?></td>
                                <td><?= htmlspecialchars($record['from_exd'] ?: 'N/A') ?></td>
                                <td class="text-right"><?= (int)$record['transfer_quantity'] ?></td>
                                <td><?= htmlspecialchars($record['to_location_code']) ?></td>
                                <td><?= htmlspecialchars($record['to_batch_number'] ?: 'N/A') ?></td>
                                <td><?= htmlspecialchars($record['to_mfd'] ?: 'N/A') ?></td>
                                <td><?= htmlspecialchars($record['to_exd'] ?: 'N/A') ?></td>
                                <td><?= htmlspecialchars($record['created_by'] ?: 'N/A') ?></td>
                                <td><?= htmlspecialchars($record['created_at']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr id="no_records_row">
                            <td colspan="14" class="text-center">No confirmed inventory transfers found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="7" class="text-right"><strong>Total Quantity:</strong></td>
                        <td class="text-right" id="totalQuantityFooter"><strong><?= (int)$total_quantity_transferred ?></strong></td>
                        <td colspan="6"></td>
                    </tr>
                    <tr>
                        <td colspan="7" class="text-right"><strong>Total CBM:</strong></td>
                        <td class="text-right" id="totalCBMFooter"><strong><?= number_format($total_cbm_transferred, 3) ?></strong></td>
                        <td colspan="6"></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            const $historyTableBody = $('#historyTableBody');
            const $totalQuantityFooter = $('#totalQuantityFooter');
            const $totalCBMFooter = $('#totalCBMFooter');

            // Function to update totals based on visible rows
            function updateTotals() {
                let currentTotalQuantity = 0;
                let currentTotalCBM = 0;
                let visibleRowsCount = 0;

                $historyTableBody.find('tr').each(function() {
                    // Skip the "no records" row if it's present
                    if ($(this).attr('id') === 'no_records_row') {
                        return true; // Continue to the next iteration
                    }

                    if ($(this).css('display') !== 'none') {
                        currentTotalQuantity += parseInt($(this).data('quantity'));
                        currentTotalCBM += parseFloat($(this).data('cbm'));
                        visibleRowsCount++;
                    }
                });

                $totalQuantityFooter.text(currentTotalQuantity);
                $totalCBMFooter.text(currentTotalCBM.toFixed(3)); // Format to 3 decimal places

                // Handle "No records found" row dynamically for client-side filters
                let $noRecordsRow = $('#no_records_row');
                if (visibleRowsCount === 0) {
                    if ($noRecordsRow.length === 0) {
                        // Create and append if it doesn't exist
                        $historyTableBody.append('<tr id="no_records_row"><td colspan="14" class="text-center">No confirmed inventory transfers found matching filters.</td></tr>');
                    } else {
                        // Just show it if it exists
                        $noRecordsRow.show();
                    }
                } else {
                    // Hide it if there are visible rows
                    if ($noRecordsRow.length > 0) {
                        $noRecordsRow.hide();
                    }
                }
            }

            // Function to apply client-side text filters
            function applyTextFilters() {
                const filterTransferNo = $('#filter_transfer_no').val().toLowerCase();
                const filterFromSku = $('#filter_from_sku').val().toLowerCase();
                const filterFromLocation = $('#filter_from_location').val().toLowerCase();
                const filterToLocation = $('#filter_to_location').val().toLowerCase();

                $historyTableBody.find('tr').each(function() {
                    const $row = $(this);
                    // Ensure the row is not the "no records" row before processing its data
                    if ($row.attr('id') === 'no_records_row') {
                        return true; // Continue to the next iteration
                    }

                    const rowTransferNo = $row.data('transfer-no').toLowerCase();
                    const rowFromSku = $row.data('from-sku').toLowerCase();
                    const rowFromLocation = $row.data('from-location').toLowerCase();
                    const rowToLocation = $row.data('to-location').toLowerCase();

                    let showRow = true;

                    // Filter by Transfer No
                    if (filterTransferNo && !rowTransferNo.includes(filterTransferNo)) {
                        showRow = false;
                    }

                    // Filter by From SKU
                    if (filterFromSku && !rowFromSku.includes(filterFromSku)) {
                        showRow = false;
                    }

                    // Filter by From Location
                    if (filterFromLocation && !rowFromLocation.includes(filterFromLocation)) {
                        showRow = false;
                    }

                    // Filter by To Location
                    if (filterToLocation && !rowToLocation.includes(filterToLocation)) {
                        showRow = false;
                    }

                    if (showRow) {
                        $row.show();
                    } else {
                        $row.hide();
                    }
                });
                updateTotals(); // Recalculate totals after filtering
            }

            // Attach event listeners to client-side filter inputs
            $('#filter_transfer_no, #filter_from_sku, #filter_from_location, #filter_to_location').on('input', applyTextFilters);

            // Clear text filters button
            $('#clear_text_filters_btn').on('click', function() {
                $('#filter_transfer_no').val('');
                $('#filter_from_sku').val('');
                $('#filter_from_location').val('');
                $('#filter_to_location').val('');
                applyTextFilters(); // Apply filters to show all rows
            });

            // Clear date filters button
            $('#clear_date_filters_btn').on('click', function() {
                window.location.href = window.location.pathname; // Reload page without date parameters
            });

            // Initial total calculation and text filter application on page load
            applyTextFilters();
        });
    </script>
</body>

</html>